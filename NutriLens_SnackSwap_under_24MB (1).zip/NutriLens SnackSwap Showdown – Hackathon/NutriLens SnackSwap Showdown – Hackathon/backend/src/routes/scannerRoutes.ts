import { Router } from 'express';
import { lookupBarcode } from '../controllers/scannerController';

const router = Router();

router.post('/lookup', lookupBarcode);

export default router;

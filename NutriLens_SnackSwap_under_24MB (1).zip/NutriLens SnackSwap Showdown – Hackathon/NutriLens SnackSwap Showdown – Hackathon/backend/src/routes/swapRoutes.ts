import { Router } from 'express';
import { compareSnacks, logSwap, getSwapHistory } from '../controllers/swapController';

const router = Router();

// Support both /:id/:alternativeId and /compare/:id/:alternativeId
router.get('/:id/:alternativeId', compareSnacks);
router.get('/compare/:id/:alternativeId', compareSnacks);
router.post('/log', logSwap);
router.get('/history', getSwapHistory);

export default router;

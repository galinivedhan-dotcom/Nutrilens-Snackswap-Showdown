import { Router } from 'express';
import { getAllSnacks, getSnackById } from '../controllers/snackController';
import { getAlternatives } from '../controllers/swapController';

const router = Router();

router.get('/', getAllSnacks);
router.get('/:id', getSnackById);
router.get('/:id/swaps', getAlternatives);

export default router;

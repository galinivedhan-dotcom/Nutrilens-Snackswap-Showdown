import { Router } from 'express';
import { getWeeklyChallenge, toggleChallengeDay } from '../controllers/challengeController';

const router = Router();

router.get('/weekly', getWeeklyChallenge);
router.post('/:day/toggle', toggleChallengeDay);

export default router;

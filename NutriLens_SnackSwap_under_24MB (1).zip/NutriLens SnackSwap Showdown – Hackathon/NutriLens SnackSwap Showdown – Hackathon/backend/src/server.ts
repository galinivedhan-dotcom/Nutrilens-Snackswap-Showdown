import express from 'express';
import cors from 'cors';
import path from 'path';
import fs from 'fs';
import { initDatabase } from './database/db';
import snackRoutes from './routes/snackRoutes';
import swapRoutes from './routes/swapRoutes';
import dashboardRoutes from './routes/dashboardRoutes';
import challengeRoutes from './routes/challengeRoutes';
import scannerRoutes from './routes/scannerRoutes';

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// Initialize SQLite database and seed initial data
initDatabase();

// Mount API Routes
app.use('/api/snacks', snackRoutes);
app.use('/api/swaps', swapRoutes);
app.use('/api/compare', swapRoutes); // Also support /api/compare/:id/:altId
app.use('/api/dashboard', dashboardRoutes);
app.use('/api/challenges', challengeRoutes);
app.use('/api/scanner', scannerRoutes);

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'healthy',
    service: 'NutriLens API',
    version: '1.0.0',
    timestamp: new Date().toISOString()
  });
});

// Serve frontend dist if it exists
const frontendDist = path.join(__dirname, '../../frontend/dist');
if (fs.existsSync(frontendDist)) {
  app.use(express.static(frontendDist));
  app.get('*', (req, res, next) => {
    if (req.path.startsWith('/api')) return next();
    res.sendFile(path.join(frontendDist, 'index.html'));
  });
}

app.listen(PORT, () => {
  console.log(`🚀 NutriLens full-stack app running on http://localhost:${PORT}`);
});

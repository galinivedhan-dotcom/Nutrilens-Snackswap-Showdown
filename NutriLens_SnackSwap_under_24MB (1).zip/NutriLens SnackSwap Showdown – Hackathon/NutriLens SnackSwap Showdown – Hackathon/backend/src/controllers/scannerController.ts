import { Request, Response } from 'express';
import { db } from '../database/db';
import { computeNutriScore } from '../algorithms/nutriScore';
import { rankAlternatives, SnackItem } from '../algorithms/recommendation';

// Pre-cached verified barcode lookup catalog for Indian and global snacks
const BARCODE_CATALOG: Record<string, any> = {
  '8901491101837': {
    barcode: '8901491101837',
    name: "Lay's India's Magic Masala Potato Chips",
    brand: "Lay's (PepsiCo)",
    category: "Chips & Crisps",
    servingSizeGrams: 50,
    servingSizeDescription: "1 pouch (50g)",
    image: "https://images.unsplash.com/photo-1566478989037-eec170784d0b?w=600&auto=format&fit=crop&q=80",
    nutrition: {
      calories: 544,
      totalFat: 34.2,
      saturatedFat: 12.0,
      carbohydrates: 52.8,
      sugar: 2.1,
      protein: 6.4,
      fiber: 4.1,
      sodium: 740,
      fruitVegetablesLegumesPercent: 0
    },
    tasteTexture: "Crispy, Spicy Masala, Salty"
  },
  '8901491000628': {
    barcode: '8901491000628',
    name: "Kurkure Masala Munch",
    brand: "Kurkure (PepsiCo)",
    category: "Chips & Crisps",
    servingSizeGrams: 45,
    servingSizeDescription: "1 pouch (45g)",
    image: "https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?w=600&auto=format&fit=crop&q=80",
    nutrition: {
      calories: 558,
      totalFat: 35.4,
      saturatedFat: 14.8,
      carbohydrates: 53.6,
      sugar: 1.8,
      protein: 5.8,
      fiber: 3.2,
      sodium: 890,
      fruitVegetablesLegumesPercent: 0
    },
    tasteTexture: "Crunchy, Tangy, Spicy"
  },
  '7622210886638': {
    barcode: '7622210886638',
    name: "Oreo Vanilla Cream Biscuits",
    brand: "Cadbury / Mondelez",
    category: "Biscuits & Bakery",
    servingSizeGrams: 46,
    servingSizeDescription: "4 cookies (46g)",
    image: "https://images.unsplash.com/photo-1558961363-fa8fdf82db35?w=600&auto=format&fit=crop&q=80",
    nutrition: {
      calories: 480,
      totalFat: 20.0,
      saturatedFat: 9.8,
      carbohydrates: 70.0,
      sugar: 38.0,
      protein: 5.0,
      fiber: 2.8,
      sodium: 430,
      fruitVegetablesLegumesPercent: 0
    },
    tasteTexture: "Crunchy cocoa wafer, Sweet cream"
  },
  '5449000000996': {
    barcode: '5449000000996',
    name: "Coca-Cola Original Taste",
    brand: "The Coca-Cola Company",
    category: "Beverages",
    servingSizeGrams: 300,
    servingSizeDescription: "1 can (300ml)",
    image: "https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=600&auto=format&fit=crop&q=80",
    nutrition: {
      calories: 42,
      totalFat: 0,
      saturatedFat: 0,
      carbohydrates: 10.6,
      sugar: 10.6,
      protein: 0,
      fiber: 0,
      sodium: 11,
      fruitVegetablesLegumesPercent: 0
    },
    isBeverage: true,
    tasteTexture: "Fizzy, Chilled, Sweet"
  },
  '8901058852329': {
    barcode: '8901058852329',
    name: "Maggi 2-Minute Masala Noodles",
    brand: "Nestlé",
    category: "Noodles & Quick Bites",
    servingSizeGrams: 70,
    servingSizeDescription: "1 pack (70g)",
    image: "https://images.unsplash.com/photo-1612927601601-6638404737ce?w=600&auto=format&fit=crop&q=80",
    nutrition: {
      calories: 427,
      totalFat: 15.7,
      saturatedFat: 6.8,
      carbohydrates: 63.5,
      sugar: 2.2,
      protein: 8.0,
      fiber: 3.6,
      sodium: 1232,
      fruitVegetablesLegumesPercent: 0
    },
    tasteTexture: "Slurpy, Spicy, Savory"
  }
};

export async function lookupBarcode(req: Request, res: Response) {
  try {
    const { barcode } = req.body;
    if (!barcode || typeof barcode !== 'string') {
      return res.status(400).json({ success: false, message: 'Valid barcode string is required' });
    }

    const cleanBarcode = barcode.trim();
    let product: any = null;
    let source = 'Local Catalog';

    // 1. Check local catalog
    if (BARCODE_CATALOG[cleanBarcode]) {
      product = BARCODE_CATALOG[cleanBarcode];
    } else {
      // 2. Try fetching from Open Food Facts API (with timeout)
      try {
        const offUrl = `https://world.openfoodfacts.org/api/v0/product/${cleanBarcode}.json`;
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 3500);

        const response = await fetch(offUrl, { signal: controller.signal });
        clearTimeout(timeout);

        if (response.ok) {
          const json = await response.json() as any;
          if (json.status === 1 && json.product) {
            const p = json.product;
            const nutriments = p.nutriments || {};
            source = 'Open Food Facts API';

            product = {
              barcode: cleanBarcode,
              name: p.product_name || p.product_name_en || 'Scanned Product',
              brand: p.brands || 'Unknown Brand',
              category: p.categories_tags?.[0]?.replace('en:', '') || 'Packaged Snack',
              servingSizeGrams: 50,
              servingSizeDescription: p.serving_size || '50g',
              image: p.image_url || p.image_front_url || 'https://images.unsplash.com/photo-1566478989037-eec170784d0b?w=600&auto=format&fit=crop&q=80',
              nutrition: {
                calories: nutriments['energy-kcal_100g'] || nutriments['energy-kcal'] || 400,
                totalFat: nutriments.fat_100g || nutriments.fat || 15,
                saturatedFat: nutriments['saturated-fat_100g'] || nutriments['saturated-fat'] || 5,
                carbohydrates: nutriments.carbohydrates_100g || nutriments.carbohydrates || 50,
                sugar: nutriments.sugars_100g || nutriments.sugars || 5,
                protein: nutriments.proteins_100g || nutriments.proteins || 6,
                fiber: nutriments.fiber_100g || nutriments.fiber || 2,
                sodium: Math.round((nutriments.sodium_100g || (nutriments.salt_100g ? nutriments.salt_100g * 400 : 300))),
                fruitVegetablesLegumesPercent: nutriments['fruits-vegetables-nuts-estimate-from-ingredients_100g'] || 0
              },
              isBeverage: p.categories_tags?.some((t: string) => t.includes('beverage') || t.includes('drink')) || false,
              tasteTexture: 'Crunchy, Savory'
            };
          }
        }
      } catch (e) {
        console.warn('Open Food Facts API fetch failed or timed out:', e);
      }
    }

    if (!product) {
      // Return a smart fallback sample from catalog if unknown code
      product = BARCODE_CATALOG['8901491101837']; // Default to Lay's
      source = 'Demo Catalog (Simulated Match)';
    }

    // Compute NutriLens Health Score & Grade
    const scoreResult = computeNutriScore(product.nutrition, product.isBeverage);

    // Find healthy Indian alternatives
    const altRows = db.prepare(`
      SELECT s.*, 
        n.calories, n.totalFat, n.saturatedFat, n.carbohydrates, n.sugar, n.protein, n.fiber, n.sodium, n.fruitVegetablesLegumesPercent
      FROM snacks s
      LEFT JOIN nutritional_profiles n ON s.id = n.snackId
      WHERE s.isHealthyAlternative = 1
    `).all() as any[];

    const candidates: SnackItem[] = altRows.map(r => ({
      id: r.id,
      name: r.name,
      category: r.category,
      description: r.description,
      image: r.image,
      isHealthyAlternative: true,
      servingSizeDescription: r.servingSizeDescription,
      servingSizeGrams: r.servingSizeGrams,
      priceINR: r.priceINR,
      tasteTexture: r.tasteTexture,
      flavorNotes: r.flavorNotes,
      preparationMethod: r.preparationMethod,
      hostelFriendly: Boolean(r.hostelFriendly),
      prepTimeMinutes: r.prepTimeMinutes,
      allergens: r.allergens,
      healthScore: r.healthScore,
      healthGrade: r.healthGrade,
      trafficLight: r.trafficLight,
      gradeMeaning: r.gradeMeaning,
      isBeverage: Boolean(r.isBeverage),
      swapReasons: r.swapReasons,
      nutrition: {
        calories: r.calories,
        totalFat: r.totalFat,
        saturatedFat: r.saturatedFat,
        carbohydrates: r.carbohydrates,
        sugar: r.sugar,
        protein: r.protein,
        fiber: r.fiber,
        sodium: r.sodium
      }
    }));

    const mockSnackItem: SnackItem = {
      id: 9999,
      name: product.name,
      category: product.category,
      description: `Scanned barcode: ${cleanBarcode}`,
      image: product.image,
      isHealthyAlternative: false,
      servingSizeDescription: product.servingSizeDescription,
      servingSizeGrams: product.servingSizeGrams,
      priceINR: 20,
      tasteTexture: product.tasteTexture,
      flavorNotes: '',
      preparationMethod: 'Packaged Food',
      hostelFriendly: true,
      prepTimeMinutes: 0,
      allergens: '[]',
      healthScore: scoreResult.finalScore,
      healthGrade: scoreResult.grade,
      trafficLight: scoreResult.trafficLight,
      gradeMeaning: scoreResult.meaning,
      isBeverage: Boolean(product.isBeverage),
      nutrition: product.nutrition
    };

    const rankedAlternatives = rankAlternatives(mockSnackItem, candidates).slice(0, 3);

    res.json({
      success: true,
      source,
      scannedProduct: {
        ...product,
        healthGrade: scoreResult.grade,
        healthScore: scoreResult.finalScore,
        trafficLight: scoreResult.trafficLight,
        gradeMeaning: scoreResult.meaning,
        scoringBreakdown: scoreResult.breakdown,
        warnings: scoreResult.warnings,
        highlights: scoreResult.highlights
      },
      recommendedSwaps: rankedAlternatives
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
}

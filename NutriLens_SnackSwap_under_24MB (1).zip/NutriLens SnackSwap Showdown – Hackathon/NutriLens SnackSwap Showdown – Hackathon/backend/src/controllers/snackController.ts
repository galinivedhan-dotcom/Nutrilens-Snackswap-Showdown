import { Request, Response } from 'express';
import { db } from '../database/db';

export function getAllSnacks(req: Request, res: Response) {
  try {
    const { q, category, healthy, hostel } = req.query;

    let query = `
      SELECT s.*, 
        n.calories, n.totalFat, n.saturatedFat, n.carbohydrates, n.sugar, n.protein, n.fiber, n.sodium, n.fruitVegetablesLegumesPercent
      FROM snacks s
      LEFT JOIN nutritional_profiles n ON s.id = n.snackId
      WHERE 1=1
    `;
    const params: any[] = [];

    if (q && typeof q === 'string' && q.trim()) {
      query += ` AND (s.name LIKE ? OR s.tasteTexture LIKE ? OR s.description LIKE ?)`;
      const term = `%${q.trim()}%`;
      params.push(term, term, term);
    }

    if (category && typeof category === 'string' && category !== 'All') {
      query += ` AND s.category = ?`;
      params.push(category);
    }

    if (healthy !== undefined) {
      query += ` AND s.isHealthyAlternative = ?`;
      params.push(healthy === 'true' || healthy === '1' ? 1 : 0);
    }

    if (hostel === 'true' || hostel === '1') {
      query += ` AND s.hostelFriendly = 1`;
    }

    query += ` ORDER BY s.id ASC`;

    const rows = db.prepare(query).all(...params) as any[];

    const snacks = rows.map(r => ({
      id: r.id,
      name: r.name,
      category: r.category,
      description: r.description,
      image: r.image,
      isHealthyAlternative: Boolean(r.isHealthyAlternative),
      servingSizeDescription: r.servingSizeDescription,
      servingSizeGrams: r.servingSizeGrams,
      priceINR: r.priceINR,
      tasteTexture: r.tasteTexture,
      flavorNotes: r.flavorNotes,
      preparationMethod: r.preparationMethod,
      hostelFriendly: Boolean(r.hostelFriendly),
      prepTimeMinutes: r.prepTimeMinutes,
      allergens: JSON.parse(r.allergens || '[]'),
      dataSource: r.dataSource,
      lastVerified: r.lastVerified,
      healthScore: r.healthScore,
      healthGrade: r.healthGrade,
      trafficLight: r.trafficLight,
      gradeMeaning: r.gradeMeaning,
      isBeverage: Boolean(r.isBeverage),
      swapReasons: r.swapReasons,
      nutrition: {
        calories: r.calories,
        totalFat: r.totalFat,
        saturatedFat: r.saturatedFat,
        carbohydrates: r.carbohydrates,
        sugar: r.sugar,
        protein: r.protein,
        fiber: r.fiber,
        sodium: r.sodium,
        fruitVegetablesLegumesPercent: r.fruitVegetablesLegumesPercent
      }
    }));

    res.json({ success: true, count: snacks.length, data: snacks });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
}

export function getSnackById(req: Request, res: Response) {
  try {
    const id = parseInt(req.params.id, 10);
    if (isNaN(id)) {
      return res.status(400).json({ success: false, message: 'Invalid snack ID' });
    }

    const row = db.prepare(`
      SELECT s.*, 
        n.calories, n.totalFat, n.saturatedFat, n.carbohydrates, n.sugar, n.protein, n.fiber, n.sodium, n.fruitVegetablesLegumesPercent,
        b.energyPoints, b.sugarPoints, b.satFatPoints, b.sodiumPoints, b.fiberPoints, b.proteinPoints, b.fvnlPoints, b.pointsN, b.pointsP, b.finalScore
      FROM snacks s
      LEFT JOIN nutritional_profiles n ON s.id = n.snackId
      LEFT JOIN scoring_breakdown b ON s.id = b.snackId
      WHERE s.id = ?
    `).get(id) as any;

    if (!row) {
      return res.status(404).json({ success: false, message: 'Snack not found' });
    }

    const warnings = [];
    if (row.sodium >= 500) warnings.push({ type: 'sodium', text: 'High Sodium (>500mg/100g)' });
    if (row.saturatedFat >= 5.0) warnings.push({ type: 'satFat', text: 'High Saturated Fat (>5g/100g)' });
    if (row.sugar >= 12.0) warnings.push({ type: 'sugar', text: 'High Sugar (>12g/100g)' });
    if (row.calories >= 450) warnings.push({ type: 'calories', text: 'High Caloric Density (>450 kcal/100g)' });

    const highlights = [];
    if (row.protein >= 10.0) highlights.push({ type: 'protein', text: 'High Protein (>10g/100g)' });
    if (row.fiber >= 5.0) highlights.push({ type: 'fiber', text: 'Rich in Dietary Fiber (>5g/100g)' });
    if (row.sugar <= 3.0) highlights.push({ type: 'sugar', text: 'Low Sugar (<3g/100g)' });
    if (row.saturatedFat <= 1.5) highlights.push({ type: 'satFat', text: 'Low Saturated Fat (<1.5g/100g)' });

    const snack = {
      id: row.id,
      name: row.name,
      category: row.category,
      description: row.description,
      image: row.image,
      isHealthyAlternative: Boolean(row.isHealthyAlternative),
      servingSizeDescription: row.servingSizeDescription,
      servingSizeGrams: row.servingSizeGrams,
      priceINR: row.priceINR,
      tasteTexture: row.tasteTexture,
      flavorNotes: row.flavorNotes,
      preparationMethod: row.preparationMethod,
      hostelFriendly: Boolean(row.hostelFriendly),
      prepTimeMinutes: row.prepTimeMinutes,
      allergens: JSON.parse(row.allergens || '[]'),
      dataSource: row.dataSource,
      lastVerified: row.lastVerified,
      healthScore: row.healthScore,
      healthGrade: row.healthGrade,
      trafficLight: row.trafficLight,
      gradeMeaning: row.gradeMeaning,
      isBeverage: Boolean(row.isBeverage),
      swapReasons: row.swapReasons,
      nutrition: {
        calories: row.calories,
        totalFat: row.totalFat,
        saturatedFat: row.saturatedFat,
        carbohydrates: row.carbohydrates,
        sugar: row.sugar,
        protein: row.protein,
        fiber: row.fiber,
        sodium: row.sodium,
        fruitVegetablesLegumesPercent: row.fruitVegetablesLegumesPercent
      },
      scoringBreakdown: {
        energyPoints: row.energyPoints || 0,
        sugarPoints: row.sugarPoints || 0,
        satFatPoints: row.satFatPoints || 0,
        sodiumPoints: row.sodiumPoints || 0,
        fiberPoints: row.fiberPoints || 0,
        proteinPoints: row.proteinPoints || 0,
        fvnlPoints: row.fvnlPoints || 0,
        pointsN: row.pointsN || 0,
        pointsP: row.pointsP || 0,
        finalScore: row.finalScore || row.healthScore
      },
      warnings,
      highlights
    };

    res.json({ success: true, data: snack });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
}

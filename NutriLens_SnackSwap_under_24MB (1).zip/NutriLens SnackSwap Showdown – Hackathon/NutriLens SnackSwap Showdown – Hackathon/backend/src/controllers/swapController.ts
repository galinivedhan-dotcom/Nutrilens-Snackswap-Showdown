import { Request, Response } from 'express';
import { db } from '../database/db';
import { rankAlternatives, SnackItem } from '../algorithms/recommendation';

function getSnackWithNutrition(id: number): SnackItem | null {
  const row = db.prepare(`
    SELECT s.*, 
      n.calories, n.totalFat, n.saturatedFat, n.carbohydrates, n.sugar, n.protein, n.fiber, n.sodium, n.fruitVegetablesLegumesPercent
    FROM snacks s
    LEFT JOIN nutritional_profiles n ON s.id = n.snackId
    WHERE s.id = ?
  `).get(id) as any;

  if (!row) return null;

  return {
    id: row.id,
    name: row.name,
    category: row.category,
    description: row.description,
    image: row.image,
    isHealthyAlternative: Boolean(row.isHealthyAlternative),
    servingSizeDescription: row.servingSizeDescription,
    servingSizeGrams: row.servingSizeGrams,
    priceINR: row.priceINR,
    tasteTexture: row.tasteTexture,
    flavorNotes: row.flavorNotes,
    preparationMethod: row.preparationMethod,
    hostelFriendly: Boolean(row.hostelFriendly),
    prepTimeMinutes: row.prepTimeMinutes,
    allergens: row.allergens,
    healthScore: row.healthScore,
    healthGrade: row.healthGrade,
    trafficLight: row.trafficLight,
    gradeMeaning: row.gradeMeaning,
    isBeverage: Boolean(row.isBeverage),
    swapReasons: row.swapReasons,
    nutrition: {
      calories: row.calories,
      totalFat: row.totalFat,
      saturatedFat: row.saturatedFat,
      carbohydrates: row.carbohydrates,
      sugar: row.sugar,
      protein: row.protein,
      fiber: row.fiber,
      sodium: row.sodium
    }
  };
}

export function getAlternatives(req: Request, res: Response) {
  try {
    const id = parseInt(req.params.id, 10);
    const originalSnack = getSnackWithNutrition(id);
    if (!originalSnack) {
      return res.status(404).json({ success: false, message: 'Original snack not found' });
    }

    // Fetch all healthy alternatives
    const altRows = db.prepare(`
      SELECT s.*, 
        n.calories, n.totalFat, n.saturatedFat, n.carbohydrates, n.sugar, n.protein, n.fiber, n.sodium, n.fruitVegetablesLegumesPercent
      FROM snacks s
      LEFT JOIN nutritional_profiles n ON s.id = n.snackId
      WHERE s.isHealthyAlternative = 1 AND s.id != ?
    `).all(id) as any[];

    const candidates: SnackItem[] = altRows.map(r => ({
      id: r.id,
      name: r.name,
      category: r.category,
      description: r.description,
      image: r.image,
      isHealthyAlternative: true,
      servingSizeDescription: r.servingSizeDescription,
      servingSizeGrams: r.servingSizeGrams,
      priceINR: r.priceINR,
      tasteTexture: r.tasteTexture,
      flavorNotes: r.flavorNotes,
      preparationMethod: r.preparationMethod,
      hostelFriendly: Boolean(r.hostelFriendly),
      prepTimeMinutes: r.prepTimeMinutes,
      allergens: r.allergens,
      healthScore: r.healthScore,
      healthGrade: r.healthGrade,
      trafficLight: r.trafficLight,
      gradeMeaning: r.gradeMeaning,
      isBeverage: Boolean(r.isBeverage),
      swapReasons: r.swapReasons,
      nutrition: {
        calories: r.calories,
        totalFat: r.totalFat,
        saturatedFat: r.saturatedFat,
        carbohydrates: r.carbohydrates,
        sugar: r.sugar,
        protein: r.protein,
        fiber: r.fiber,
        sodium: r.sodium
      }
    }));

    const ranked = rankAlternatives(originalSnack, candidates);
    // Take top 3 recommendations
    const top3 = ranked.slice(0, 3);

    res.json({
      success: true,
      originalSnack,
      recommendations: top3
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
}

export function compareSnacks(req: Request, res: Response) {
  try {
    const originalId = parseInt(req.params.id, 10);
    const alternativeId = parseInt(req.params.alternativeId, 10);

    const original = getSnackWithNutrition(originalId);
    const alternative = getSnackWithNutrition(alternativeId);

    if (!original || !alternative) {
      return res.status(404).json({ success: false, message: 'One or both snacks not found' });
    }

    // Comparison baseline: 100g standard comparison
    const origN = original.nutrition;
    const altN = alternative.nutrition;

    const diff100g = {
      calories: Math.round((origN.calories - altN.calories) * 10) / 10,
      totalFat: Math.round((origN.totalFat - altN.totalFat) * 10) / 10,
      saturatedFat: Math.round((origN.saturatedFat - altN.saturatedFat) * 10) / 10,
      carbohydrates: Math.round((origN.carbohydrates - altN.carbohydrates) * 10) / 10,
      sugar: Math.round((origN.sugar - altN.sugar) * 10) / 10,
      protein: Math.round((altN.protein - origN.protein) * 10) / 10, // protein gain
      fiber: Math.round((altN.fiber - origN.fiber) * 10) / 10,       // fiber gain
      sodium: Math.round(origN.sodium - altN.sodium)
    };

    // Percentage reductions
    const calcReduction = (origVal: number, altVal: number) => {
      if (origVal <= 0) return 0;
      const red = ((origVal - altVal) / origVal) * 100;
      return Math.round(red * 10) / 10;
    };

    const percentageReductions = {
      calories: calcReduction(origN.calories, altN.calories),
      totalFat: calcReduction(origN.totalFat, altN.totalFat),
      saturatedFat: calcReduction(origN.saturatedFat, altN.saturatedFat),
      sugar: calcReduction(origN.sugar, altN.sugar),
      sodium: calcReduction(origN.sodium, altN.sodium)
    };

    // Realistic standard serving comparison
    const origServingFactor = (original.servingSizeGrams || 50) / 100;
    const altServingFactor = (alternative.servingSizeGrams || 50) / 100;

    const origServing = {
      calories: Math.round(origN.calories * origServingFactor * 10) / 10,
      totalFat: Math.round(origN.totalFat * origServingFactor * 10) / 10,
      saturatedFat: Math.round(origN.saturatedFat * origServingFactor * 10) / 10,
      sugar: Math.round(origN.sugar * origServingFactor * 10) / 10,
      protein: Math.round(origN.protein * origServingFactor * 10) / 10,
      fiber: Math.round(origN.fiber * origServingFactor * 10) / 10,
      sodium: Math.round(origN.sodium * origServingFactor)
    };

    const altServing = {
      calories: Math.round(altN.calories * altServingFactor * 10) / 10,
      totalFat: Math.round(altN.totalFat * altServingFactor * 10) / 10,
      saturatedFat: Math.round(altN.saturatedFat * altServingFactor * 10) / 10,
      sugar: Math.round(altN.sugar * altServingFactor * 10) / 10,
      protein: Math.round(altN.protein * altServingFactor * 10) / 10,
      fiber: Math.round(altN.fiber * altServingFactor * 10) / 10,
      sodium: Math.round(altN.sodium * altServingFactor)
    };

    const diffServing = {
      calories: Math.round((origServing.calories - altServing.calories) * 10) / 10,
      totalFat: Math.round((origServing.totalFat - altServing.totalFat) * 10) / 10,
      saturatedFat: Math.round((origServing.saturatedFat - altServing.saturatedFat) * 10) / 10,
      sugar: Math.round((origServing.sugar - altServing.sugar) * 10) / 10,
      protein: Math.round((altServing.protein - origServing.protein) * 10) / 10,
      fiber: Math.round((altServing.fiber - origServing.fiber) * 10) / 10,
      sodium: Math.round(origServing.sodium - altServing.sodium)
    };

    // Exercise Equivalency (Duration (min) = kcal / activityRate)
    // Walking: ~3.7 kcal/min, Jogging: ~9.0 kcal/min, Cycling: ~6.5 kcal/min
    const exerciseEquivalents = {
      original: {
        walkingMinutes: Math.round(origServing.calories / 3.7),
        joggingMinutes: Math.round(origServing.calories / 9.0),
        cyclingMinutes: Math.round(origServing.calories / 6.5)
      },
      alternative: {
        walkingMinutes: Math.round(altServing.calories / 3.7),
        joggingMinutes: Math.round(altServing.calories / 9.0),
        cyclingMinutes: Math.round(altServing.calories / 6.5)
      },
      savedWorkoutMinutes: {
        walking: Math.max(0, Math.round((origServing.calories - altServing.calories) / 3.7)),
        jogging: Math.max(0, Math.round((origServing.calories - altServing.calories) / 9.0)),
        cycling: Math.max(0, Math.round((origServing.calories - altServing.calories) / 6.5))
      }
    };

    res.json({
      success: true,
      original,
      alternative,
      diff100g,
      diffServing,
      origServing,
      altServing,
      percentageReductions,
      exerciseEquivalents
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
}

export function logSwap(req: Request, res: Response) {
  try {
    const { originalSnackId, alternativeSnackId, quantityGrams, userId = 1 } = req.body;

    if (!originalSnackId || !alternativeSnackId) {
      return res.status(400).json({ success: false, message: 'Both original and alternative snack IDs are required' });
    }

    const original = getSnackWithNutrition(Number(originalSnackId));
    const alternative = getSnackWithNutrition(Number(alternativeSnackId));

    if (!original || !alternative) {
      return res.status(404).json({ success: false, message: 'Snack records not found' });
    }

    const qty = Number(quantityGrams) || original.servingSizeGrams || 50;
    const factor = qty / 100;

    const caloriesSaved = Math.round((original.nutrition.calories - alternative.nutrition.calories) * factor * 10) / 10;
    const sugarSaved = Math.round((original.nutrition.sugar - alternative.nutrition.sugar) * factor * 10) / 10;
    const sodiumSaved = Math.round((original.nutrition.sodium - alternative.nutrition.sodium) * factor);
    const satFatSaved = Math.round((original.nutrition.saturatedFat - alternative.nutrition.saturatedFat) * factor * 10) / 10;
    const proteinGained = Math.round((alternative.nutrition.protein - original.nutrition.protein) * factor * 10) / 10;
    const fiberGained = Math.round((alternative.nutrition.fiber - original.nutrition.fiber) * factor * 10) / 10;

    const timestamp = new Date().toISOString();

    const result = db.prepare(`
      INSERT INTO user_swap_logs (
        userId, originalSnackId, alternativeSnackId, quantityGrams,
        caloriesSaved, sugarSaved, sodiumSaved, satFatSaved, proteinGained, fiberGained, timestamp
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      userId,
      original.id,
      alternative.id,
      qty,
      caloriesSaved,
      sugarSaved,
      sodiumSaved,
      satFatSaved,
      proteinGained,
      fiberGained,
      timestamp
    );

    // Return the logged record
    res.json({
      success: true,
      message: 'Snack swap logged successfully! 🎉',
      logId: result.lastInsertRowid,
      swap: {
        originalName: original.name,
        alternativeName: alternative.name,
        quantityGrams: qty,
        caloriesSaved,
        sugarSaved,
        sodiumSaved,
        satFatSaved,
        proteinGained,
        fiberGained,
        timestamp
      }
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
}

export function getSwapHistory(req: Request, res: Response) {
  try {
    const rows = db.prepare(`
      SELECT 
        l.id as logId,
        l.quantityGrams,
        l.caloriesSaved,
        l.sugarSaved,
        l.sodiumSaved,
        l.satFatSaved,
        l.proteinGained,
        l.fiberGained,
        l.timestamp,
        orig.id as origId,
        orig.name as origName,
        orig.image as origImage,
        orig.healthGrade as origGrade,
        alt.id as altId,
        alt.name as altName,
        alt.image as altImage,
        alt.healthGrade as altGrade
      FROM user_swap_logs l
      JOIN snacks orig ON l.originalSnackId = orig.id
      JOIN snacks alt ON l.alternativeSnackId = alt.id
      ORDER BY l.timestamp DESC
    `).all() as any[];

    res.json({ success: true, count: rows.length, data: rows });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
}

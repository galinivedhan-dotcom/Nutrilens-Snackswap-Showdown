import { Request, Response } from 'express';
import { db } from '../database/db';

export function getDashboardStats(req: Request, res: Response) {
  try {
    // 1. Cumulative aggregates
    const totals = db.prepare(`
      SELECT 
        COUNT(*) as totalSwaps,
        COALESCE(SUM(caloriesSaved), 0) as totalCaloriesSaved,
        COALESCE(SUM(sugarSaved), 0) as totalSugarSaved,
        COALESCE(SUM(sodiumSaved), 0) as totalSodiumSaved,
        COALESCE(SUM(satFatSaved), 0) as totalSatFatSaved,
        COALESCE(SUM(proteinGained), 0) as totalProteinGained,
        COALESCE(SUM(fiberGained), 0) as totalFiberGained
      FROM user_swap_logs
    `).get() as any;

    // 2. Recent swaps (last 5)
    const recentSwaps = db.prepare(`
      SELECT 
        l.id as logId,
        l.quantityGrams,
        l.caloriesSaved,
        l.sugarSaved,
        l.sodiumSaved,
        l.timestamp,
        orig.name as origName,
        orig.healthGrade as origGrade,
        alt.name as altName,
        alt.healthGrade as altGrade
      FROM user_swap_logs l
      JOIN snacks orig ON l.originalSnackId = orig.id
      JOIN snacks alt ON l.alternativeSnackId = alt.id
      ORDER BY l.timestamp DESC
      LIMIT 5
    `).all() as any[];

    // 3. Challenge progress
    const challengeStats = db.prepare(`
      SELECT 
        COUNT(*) as totalDays,
        SUM(isCompleted) as completedDays
      FROM challenges
    `).get() as any;

    // 4. Activity equivalents
    const totalCal = Number(totals.totalCaloriesSaved) || 0;
    const activityEquivalents = {
      walkingMinutes: Math.round(totalCal / 3.7),
      joggingMinutes: Math.round(totalCal / 9.0),
      cyclingMinutes: Math.round(totalCal / 6.5)
    };

    // 5. Daily timeline data for Chart.js
    const logs = db.prepare(`
      SELECT 
        DATE(timestamp) as swapDate,
        COUNT(*) as count,
        SUM(caloriesSaved) as calories,
        SUM(sugarSaved) as sugar,
        SUM(sodiumSaved) as sodium
      FROM user_swap_logs
      GROUP BY DATE(timestamp)
      ORDER BY swapDate ASC
    `).all() as any[];

    // 6. Category breakdown of swaps
    const categoryBreakdown = db.prepare(`
      SELECT 
        orig.category,
        COUNT(*) as count
      FROM user_swap_logs l
      JOIN snacks orig ON l.originalSnackId = orig.id
      GROUP BY orig.category
      ORDER BY count DESC
    `).all() as any[];

    res.json({
      success: true,
      stats: {
        totalSwaps: totals.totalSwaps,
        totalCaloriesSaved: Math.round(totals.totalCaloriesSaved * 10) / 10,
        totalSugarSaved: Math.round(totals.totalSugarSaved * 10) / 10,
        totalSodiumSaved: Math.round(totals.totalSodiumSaved),
        totalSatFatSaved: Math.round(totals.totalSatFatSaved * 10) / 10,
        totalProteinGained: Math.round(totals.totalProteinGained * 10) / 10,
        totalFiberGained: Math.round(totals.totalFiberGained * 10) / 10,
        activityEquivalents,
        challengeProgress: {
          totalDays: challengeStats.totalDays || 7,
          completedDays: challengeStats.completedDays || 0
        }
      },
      recentSwaps,
      dailyTimeline: logs,
      categoryBreakdown
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
}

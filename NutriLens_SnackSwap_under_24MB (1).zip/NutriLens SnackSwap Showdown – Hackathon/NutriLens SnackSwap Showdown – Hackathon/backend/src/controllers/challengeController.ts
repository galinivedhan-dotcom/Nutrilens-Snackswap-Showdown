import { Request, Response } from 'express';
import { db } from '../database/db';

export function getWeeklyChallenge(req: Request, res: Response) {
  try {
    const days = db.prepare(`SELECT * FROM challenges ORDER BY dayNumber ASC`).all() as any[];
    const completedCount = days.filter(d => d.isCompleted === 1).length;

    // Badges state
    const badges = days.map(d => ({
      dayNumber: d.dayNumber,
      badgeName: d.badgeName,
      badgeIcon: d.badgeIcon,
      unlocked: d.isCompleted === 1,
      unlockedAt: d.completedAt
    }));

    res.json({
      success: true,
      challengeTitle: 'NutriLens 7-Day SnackSwap Challenge',
      subtitle: 'Swap one junk snack each day, level up your nutrition, and earn the Master Swapper Badge!',
      progress: {
        completedDays: completedCount,
        totalDays: 7,
        percentage: Math.round((completedCount / 7) * 100),
        streakDays: completedCount
      },
      days: days.map(d => ({
        ...d,
        isCompleted: Boolean(d.isCompleted)
      })),
      badges
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
}

export function toggleChallengeDay(req: Request, res: Response) {
  try {
    const dayNumber = parseInt(req.params.day, 10);
    const day = db.prepare(`SELECT * FROM challenges WHERE dayNumber = ?`).get(dayNumber) as any;

    if (!day) {
      return res.status(404).json({ success: false, message: 'Challenge day not found' });
    }

    const nextState = day.isCompleted === 1 ? 0 : 1;
    const completedAt = nextState === 1 ? new Date().toISOString() : null;

    db.prepare(`
      UPDATE challenges
      SET isCompleted = ?, completedAt = ?
      WHERE dayNumber = ?
    `).run(nextState, completedAt, dayNumber);

    res.json({
      success: true,
      message: nextState === 1 ? `🎉 Day ${dayNumber} completed! Badge Unlocked: ${day.badgeName}` : `Day ${dayNumber} marked uncompleted`,
      dayNumber,
      isCompleted: nextState === 1,
      badgeUnlocked: nextState === 1 ? day.badgeName : null
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
}

import { DatabaseSync } from 'node:sqlite';
import path from 'node:path';
import fs from 'node:fs';

const dbPath = path.join(__dirname, '../../nutrilens.sqlite');
export const db = new DatabaseSync(dbPath);

export function initDatabase() {
  // 1. Snacks Table
  db.exec(`
    CREATE TABLE IF NOT EXISTS snacks (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      category TEXT NOT NULL,
      description TEXT,
      image TEXT,
      isHealthyAlternative INTEGER NOT NULL DEFAULT 0,
      servingSizeDescription TEXT,
      servingSizeGrams REAL DEFAULT 50,
      priceINR REAL DEFAULT 20,
      tasteTexture TEXT,
      flavorNotes TEXT,
      preparationMethod TEXT,
      hostelFriendly INTEGER DEFAULT 1,
      prepTimeMinutes INTEGER DEFAULT 0,
      allergens TEXT,
      dataSource TEXT,
      lastVerified TEXT,
      healthScore REAL,
      healthGrade TEXT,
      trafficLight TEXT,
      gradeMeaning TEXT,
      isBeverage INTEGER DEFAULT 0,
      swapReasons TEXT
    );
  `);

  // 2. Nutritional Profiles Table (per 100g / 100ml)
  db.exec(`
    CREATE TABLE IF NOT EXISTS nutritional_profiles (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      snackId INTEGER UNIQUE NOT NULL,
      calories REAL NOT NULL,
      totalFat REAL NOT NULL,
      saturatedFat REAL NOT NULL,
      carbohydrates REAL NOT NULL,
      sugar REAL NOT NULL,
      protein REAL NOT NULL,
      fiber REAL NOT NULL,
      sodium REAL NOT NULL,
      fruitVegetablesLegumesPercent REAL DEFAULT 0,
      FOREIGN KEY (snackId) REFERENCES snacks(id) ON DELETE CASCADE
    );
  `);

  // 3. Scoring Breakdown Table
  db.exec(`
    CREATE TABLE IF NOT EXISTS scoring_breakdown (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      snackId INTEGER UNIQUE NOT NULL,
      energyPoints INTEGER DEFAULT 0,
      sugarPoints INTEGER DEFAULT 0,
      satFatPoints INTEGER DEFAULT 0,
      sodiumPoints INTEGER DEFAULT 0,
      fiberPoints INTEGER DEFAULT 0,
      proteinPoints INTEGER DEFAULT 0,
      fvnlPoints INTEGER DEFAULT 0,
      pointsN INTEGER DEFAULT 0,
      pointsP INTEGER DEFAULT 0,
      finalScore REAL DEFAULT 0,
      FOREIGN KEY (snackId) REFERENCES snacks(id) ON DELETE CASCADE
    );
  `);

  // 4. Swap Rules Table (recommendation associations)
  db.exec(`
    CREATE TABLE IF NOT EXISTS swap_rules (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      originalSnackId INTEGER NOT NULL,
      alternativeSnackId INTEGER NOT NULL,
      tasteMatch TEXT,
      textureMatch TEXT,
      priority INTEGER DEFAULT 1,
      reason TEXT,
      FOREIGN KEY (originalSnackId) REFERENCES snacks(id) ON DELETE CASCADE,
      FOREIGN KEY (alternativeSnackId) REFERENCES snacks(id) ON DELETE CASCADE
    );
  `);

  // 5. User Swap Logs Table
  db.exec(`
    CREATE TABLE IF NOT EXISTS user_swap_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      userId INTEGER DEFAULT 1,
      originalSnackId INTEGER NOT NULL,
      alternativeSnackId INTEGER NOT NULL,
      quantityGrams REAL NOT NULL,
      caloriesSaved REAL NOT NULL,
      sugarSaved REAL NOT NULL,
      sodiumSaved REAL NOT NULL,
      satFatSaved REAL NOT NULL,
      proteinGained REAL NOT NULL,
      fiberGained REAL NOT NULL,
      timestamp TEXT NOT NULL,
      FOREIGN KEY (originalSnackId) REFERENCES snacks(id),
      FOREIGN KEY (alternativeSnackId) REFERENCES snacks(id)
    );
  `);

  // 6. Weekly Challenges Table
  db.exec(`
    CREATE TABLE IF NOT EXISTS challenges (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      dayNumber INTEGER UNIQUE NOT NULL,
      title TEXT NOT NULL,
      targetSwapCategory TEXT NOT NULL,
      description TEXT NOT NULL,
      badgeName TEXT NOT NULL,
      badgeIcon TEXT NOT NULL,
      isCompleted INTEGER DEFAULT 0,
      completedAt TEXT
    );
  `);

  // 7. Users Table
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT NOT NULL,
      email TEXT NOT NULL,
      createdAt TEXT NOT NULL
    );
  `);

  seedIfEmpty();
}

function seedIfEmpty() {
  const countRow = db.prepare('SELECT COUNT(*) as count FROM snacks').get() as { count: number };
  if (countRow.count > 0) {
    return;
  }

  console.log('Seeding database from dataset/snacks.json...');
  const jsonPath = path.join(__dirname, '../../../dataset/snacks.json');
  if (!fs.existsSync(jsonPath)) {
    console.error('Dataset file not found at:', jsonPath);
    return;
  }

  const snacksData = JSON.parse(fs.readFileSync(jsonPath, 'utf-8'));

  const insertSnack = db.prepare(`
    INSERT INTO snacks (
      id, name, category, description, image, isHealthyAlternative,
      servingSizeDescription, servingSizeGrams, priceINR, tasteTexture,
      flavorNotes, preparationMethod, hostelFriendly, prepTimeMinutes,
      allergens, dataSource, lastVerified, healthScore, healthGrade,
      trafficLight, gradeMeaning, isBeverage, swapReasons
    ) VALUES (
      ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
    )
  `);

  const insertNutrition = db.prepare(`
    INSERT INTO nutritional_profiles (
      snackId, calories, totalFat, saturatedFat, carbohydrates, sugar, protein, fiber, sodium, fruitVegetablesLegumesPercent
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const insertBreakdown = db.prepare(`
    INSERT INTO scoring_breakdown (
      snackId, energyPoints, sugarPoints, satFatPoints, sodiumPoints, fiberPoints, proteinPoints, fvnlPoints, pointsN, pointsP, finalScore
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const insertSwapRule = db.prepare(`
    INSERT INTO swap_rules (
      originalSnackId, alternativeSnackId, tasteMatch, textureMatch, priority, reason
    ) VALUES (?, ?, ?, ?, ?, ?)
  `);

  for (const s of snacksData) {
    insertSnack.run(
      s.id,
      s.name,
      s.category,
      s.description || '',
      s.image || '',
      s.isHealthyAlternative ? 1 : 0,
      s.servingSizeDescription || '50g',
      s.servingSizeGrams || 50,
      s.priceINR || 20,
      s.tasteTexture || '',
      s.flavorNotes || '',
      s.preparationMethod || '',
      s.hostelFriendly ? 1 : 0,
      s.prepTimeMinutes || 0,
      JSON.stringify(s.allergens || []),
      s.dataSource || 'NutriLens Database',
      s.lastVerified || '2026-11-01',
      s.healthScore,
      s.healthGrade,
      s.trafficLight,
      s.gradeMeaning,
      s.isBeverage ? 1 : 0,
      s.swapReasons || ''
    );

    insertNutrition.run(
      s.id,
      s.nutrition.calories,
      s.nutrition.totalFat,
      s.nutrition.saturatedFat,
      s.nutrition.carbohydrates,
      s.nutrition.sugar,
      s.nutrition.protein,
      s.nutrition.fiber,
      s.nutrition.sodium,
      s.nutrition.fruitVegetablesLegumesPercent || 0
    );

    if (s.scoringBreakdown) {
      insertBreakdown.run(
        s.id,
        s.scoringBreakdown.energyPoints || 0,
        s.scoringBreakdown.sugarPoints || 0,
        s.scoringBreakdown.satFatPoints || 0,
        s.scoringBreakdown.sodiumPoints || 0,
        s.scoringBreakdown.fiberPoints || 0,
        s.scoringBreakdown.proteinPoints || 0,
        s.scoringBreakdown.fvnlPoints || 0,
        s.scoringBreakdown.energyPoints + s.scoringBreakdown.sugarPoints + s.scoringBreakdown.satFatPoints + s.scoringBreakdown.sodiumPoints,
        s.scoringBreakdown.fiberPoints + s.scoringBreakdown.proteinPoints + s.scoringBreakdown.fvnlPoints,
        s.healthScore
      );
    }
  }

  // Insert swap rules after all snacks are in the database
  for (const s of snacksData) {
    if (s.suggestedAlternativeIds && Array.isArray(s.suggestedAlternativeIds)) {
      s.suggestedAlternativeIds.forEach((altId: number, idx: number) => {
        insertSwapRule.run(
          s.id,
          altId,
          'High Taste Match',
          'Crispy & Satisfying',
          idx + 1,
          'Recommended healthy swap'
        );
      });
    }
  }

  // Seed default 7-day challenge
  const insertChallenge = db.prepare(`
    INSERT INTO challenges (
      dayNumber, title, targetSwapCategory, description, badgeName, badgeIcon, isCompleted, completedAt
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const challengeList = [
    { day: 1, title: 'Crispy Crunch Swap', cat: 'Chips & Crisps', desc: 'Swap deep-fried potato chips or wafers for air-roasted makhana or roasted chana.', badge: 'Crunch Master', icon: 'zap' },
    { day: 2, title: 'Zero Sugar Soda Day', cat: 'Beverages', desc: 'Replace sugary soda or energy drink with fresh mint nimbu pani or masala buttermilk.', badge: 'Sugar Buster', icon: 'droplet' },
    { day: 3, title: 'Protein Power Kick', cat: 'Street Food & Fried', desc: 'Swap fried samosa or pakora for baked paneer cutlet or roasted soya crisps.', badge: 'Protein Hero', icon: 'shield' },
    { day: 4, title: 'Hostel No-Cook Swap', cat: 'Hostel Hacks', desc: 'Prepare a 3-minute no-cook snack like fruit chaat or roasted kala chana in your hostel room.', badge: 'Hostel Alchemist', icon: 'home' },
    { day: 5, title: 'Sweet Tooth Rehab', cat: 'Chocolates & Sweets', desc: 'Swap milk chocolates or candy for homemade oat date bites or dark cocoa bites.', badge: 'Sweet Wisdom', icon: 'heart' },
    { day: 6, title: 'Sodium Slasher', cat: 'Noodles & Quick Bites', desc: 'Swap instant fried ramen for vegetable whole-wheat atta noodles to cut sodium by 60%.', badge: 'Sodium Slasher', icon: 'activity' },
    { day: 7, title: 'Master Swapper Finale', cat: 'All', desc: 'Log at least 2 healthy swaps today to earn the Grand Showdown Trophy!', badge: '7-Day Champion', icon: 'award' }
  ];

  for (const c of challengeList) {
    insertChallenge.run(c.day, c.title, c.cat, c.desc, c.badge, c.icon, 0, null);
  }

  // Default User
  db.prepare(`
    INSERT INTO users (username, email, createdAt)
    VALUES ('College Swapper', 'student@nutrilens.app', ?)
  `).run(new Date().toISOString());

  // Seed initial demo swaps so the dashboard immediately shows meaningful, realistic data!
  const insertSwapLog = db.prepare(`
    INSERT INTO user_swap_logs (
      userId, originalSnackId, alternativeSnackId, quantityGrams, caloriesSaved, sugarSaved, sodiumSaved, satFatSaved, proteinGained, fiberGained, timestamp
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const initialSwaps = [
    { orig: 1, alt: 21, qty: 50, cal: 87, sug: -0.15, sod: 205, sat: 5.4, prot: 1.6, fib: 1.6, daysAgo: 4 },
    { orig: 3, alt: 23, qty: 300, cal: 102, sug: 30.6, sod: -99, sat: 0, prot: 0.6, fib: 0.9, daysAgo: 3 },
    { orig: 6, alt: 26, qty: 40, cal: 83.6, sug: 0.4, sod: 256, sat: 5.52, prot: 4.04, fib: 4.16, daysAgo: 2 },
    { orig: 5, alt: 25, qty: 70, cal: 80.5, sug: -0.21, sod: 560, sat: 5.32, prot: 2.24, fib: 3.71, daysAgo: 1 },
    { orig: 8, alt: 28, qty: 45, cal: 6.75, sug: 15.07, sod: 26.55, sat: -1.12, prot: 0.54, fib: 3.64, daysAgo: 0 }
  ];

  for (const s of initialSwaps) {
    const d = new Date();
    d.setDate(d.getDate() - s.daysAgo);
    insertSwapLog.run(1, s.orig, s.alt, s.qty, s.cal, s.sug, s.sod, s.sat, s.prot, s.fib, d.toISOString());
  }

  console.log('Seeded database with snacks, challenges, and initial demo swap activity successfully.');
}

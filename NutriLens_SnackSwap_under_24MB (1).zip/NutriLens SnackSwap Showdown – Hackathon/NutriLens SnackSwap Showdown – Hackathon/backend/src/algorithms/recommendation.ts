export interface SnackItem {
  id: number;
  name: string;
  category: string;
  description: string;
  image: string;
  isHealthyAlternative: number | boolean;
  servingSizeDescription: string;
  servingSizeGrams: number;
  priceINR: number;
  tasteTexture: string;
  flavorNotes: string;
  preparationMethod: string;
  hostelFriendly: number | boolean;
  prepTimeMinutes: number;
  allergens: string;
  healthScore: number;
  healthGrade: string;
  trafficLight: string;
  gradeMeaning: string;
  isBeverage: number | boolean;
  swapReasons?: string;
  nutrition: {
    calories: number;
    totalFat: number;
    saturatedFat: number;
    carbohydrates: number;
    sugar: number;
    protein: number;
    fiber: number;
    sodium: number;
  };
}

// Compute Euclidean distance in normalized nutritional space
export function calculateNutritionalEuclideanDistance(a: SnackItem['nutrition'], b: SnackItem['nutrition']): number {
  // Normalization bounds:
  // Calories: 0 - 700 kcal
  // Saturated Fat: 0 - 25 g
  // Sugar: 0 - 80 g
  // Sodium: 0 - 1500 mg
  // Protein: 0 - 30 g
  // Fiber: 0 - 20 g
  const norm = (val: number, max: number) => Math.min(Math.max(val / max, 0), 1);

  const dCal = norm(a.calories, 700) - norm(b.calories, 700);
  const dSatFat = norm(a.saturatedFat, 25) - norm(b.saturatedFat, 25);
  const dSugar = norm(a.sugar, 80) - norm(b.sugar, 80);
  const dSodium = norm(a.sodium, 1500) - norm(b.sodium, 1500);
  const dProtein = norm(a.protein, 30) - norm(b.protein, 30);
  const dFiber = norm(a.fiber, 20) - norm(b.fiber, 20);

  // Euclidean distance with weights emphasizing saturated fat, sodium, and sugar
  const distance = Math.sqrt(
    1.2 * (dCal * dCal) +
    2.0 * (dSatFat * dSatFat) +
    2.0 * (dSugar * dSugar) +
    2.0 * (dSodium * dSodium) +
    1.5 * (dProtein * dProtein) +
    1.5 * (dFiber * dFiber)
  );

  return distance;
}

// Match keywords in taste and texture
export function calculateTasteSimilarity(snackTaste: string, altTaste: string): number {
  const keywords = ['crispy', 'crunchy', 'salty', 'savory', 'sweet', 'spicy', 'tangy', 'slurpy', 'chilled', 'creamy', 'chewy', 'fizzy'];
  const sLower = (snackTaste || '').toLowerCase();
  const aLower = (altTaste || '').toLowerCase();

  let matches = 0;
  for (const kw of keywords) {
    if (sLower.includes(kw) && aLower.includes(kw)) {
      matches += 1;
    }
  }
  return matches;
}

export interface RecommendationResult {
  snack: SnackItem;
  similarityScore: number;
  nutritionalDistance: number;
  tasteMatchQuality: string;
  textureMatchQuality: string;
  priceComparisonINR: number; // diff from original
  caloriesSavedPer100g: number;
  sugarSavedPer100g: number;
  sodiumSavedPer100g: number;
  satFatSavedPer100g: number;
  proteinGainedPer100g: number;
  fiberGainedPer100g: number;
  whySuggested: string;
}

export function rankAlternatives(originalSnack: SnackItem, healthyCandidates: SnackItem[]): RecommendationResult[] {
  const ranked = healthyCandidates.map(alt => {
    // 1. Nutritional Euclidean distance
    const dist = calculateNutritionalEuclideanDistance(originalSnack.nutrition, alt.nutrition);

    // 2. Health grade improvement bonus
    // Grade points: A: 5, B: 4, C: 3, D: 2, E: 1
    const gradeWeight: Record<string, number> = { A: 5, B: 4, C: 3, D: 2, E: 1 };
    const origGradeScore = gradeWeight[originalSnack.healthGrade] || 2;
    const altGradeScore = gradeWeight[alt.healthGrade] || 4;
    const gradeImprovement = altGradeScore - origGradeScore;

    // 3. Taste & texture matching
    const tasteMatches = calculateTasteSimilarity(originalSnack.tasteTexture, alt.tasteTexture);

    // 4. Category matching bonus
    const categoryMatch = originalSnack.category === alt.category ? 2.5 : 0;

    // 5. Beverage / solid matching check (never recommend solid for soda or vice versa)
    const beverageMismatch = (originalSnack.isBeverage ? 1 : 0) !== (alt.isBeverage ? 1 : 0);

    // 6. Affordability factor
    const isAffordable = alt.priceINR <= originalSnack.priceINR || alt.priceINR <= 30;

    // 7. Hostel convenience bonus
    const hostelBonus = alt.hostelFriendly ? 1.0 : 0;

    // Composite ranking score (Higher is better)
    let score = (10 - dist * 4) + (gradeImprovement * 2.0) + (tasteMatches * 2.5) + categoryMatch + hostelBonus;
    if (isAffordable) score += 1.5;
    if (beverageMismatch) score -= 50; // hard constraint against mismatched liquid/solid

    // Calculations
    const caloriesSaved = originalSnack.nutrition.calories - alt.nutrition.calories;
    const sugarSaved = originalSnack.nutrition.sugar - alt.nutrition.sugar;
    const sodiumSaved = originalSnack.nutrition.sodium - alt.nutrition.sodium;
    const satFatSaved = originalSnack.nutrition.saturatedFat - alt.nutrition.saturatedFat;
    const proteinGained = alt.nutrition.protein - originalSnack.nutrition.protein;
    const fiberGained = alt.nutrition.fiber - originalSnack.nutrition.fiber;

    let whySuggested = alt.swapReasons || `Cuts down saturated fat & sodium while providing superior whole-food nutrition.`;
    if (tasteMatches > 0) {
      whySuggested = `Matches your crave for ${originalSnack.tasteTexture.split(',')[0]} texture while boosting fiber & reducing bad fats.`;
    }

    return {
      snack: alt,
      similarityScore: Math.round(score * 10) / 10,
      nutritionalDistance: Math.round(dist * 100) / 100,
      tasteMatchQuality: tasteMatches > 0 ? 'High' : 'Moderate',
      textureMatchQuality: tasteMatches > 0 ? 'Direct Match' : 'Healthy Spin',
      priceComparisonINR: alt.priceINR - originalSnack.priceINR,
      caloriesSavedPer100g: Math.round(caloriesSaved * 10) / 10,
      sugarSavedPer100g: Math.round(sugarSaved * 10) / 10,
      sodiumSavedPer100g: Math.round(sodiumSaved),
      satFatSavedPer100g: Math.round(satFatSaved * 10) / 10,
      proteinGainedPer100g: Math.round(proteinGained * 10) / 10,
      fiberGainedPer100g: Math.round(fiberGained * 10) / 10,
      whySuggested
    };
  });

  // Sort descending by similarityScore
  return ranked.sort((a, b) => b.similarityScore - a.similarityScore);
}

export interface NutritionData {
  calories: number;
  totalFat: number;
  saturatedFat: number;
  carbohydrates: number;
  sugar: number;
  protein: number;
  fiber: number;
  sodium: number;
  fruitVegetablesLegumesPercent?: number;
}

export interface NutriScoreResult {
  pointsN: number;
  pointsP: number;
  finalScore: number;
  grade: 'A' | 'B' | 'C' | 'D' | 'E';
  trafficLight: 'green' | 'light-green' | 'yellow' | 'orange' | 'red';
  meaning: string;
  breakdown: {
    energyPoints: number;
    sugarPoints: number;
    satFatPoints: number;
    sodiumPoints: number;
    fiberPoints: number;
    proteinPoints: number;
    fvnlPoints: number;
  };
  warnings: Array<{ type: string; text: string }>;
  highlights: Array<{ type: string; text: string }>;
}

export function computeNutriScore(nutrient: NutritionData, isBeverage = false, isWater = false): NutriScoreResult {
  if (isWater) {
    return {
      pointsN: 0,
      pointsP: 5,
      finalScore: -15,
      grade: 'A',
      trafficLight: 'green',
      meaning: 'Best nutritional profile',
      breakdown: { energyPoints: 0, sugarPoints: 0, satFatPoints: 0, sodiumPoints: 0, fiberPoints: 0, proteinPoints: 0, fvnlPoints: 5 },
      warnings: [],
      highlights: [{ type: 'hydration', text: 'Pure hydration, 0 calories' }]
    };
  }

  const energyKj = nutrient.calories * 4.184;

  // Energy points (0-10)
  let energyPoints = 0;
  if (!isBeverage) {
    const energyThresholds = [335, 670, 1005, 1340, 1675, 2010, 2345, 2680, 3015, 3350];
    for (let i = 0; i < energyThresholds.length; i++) {
      if (energyKj > energyThresholds[i]) energyPoints = i + 1;
    }
  } else {
    const bevEnergyThresholds = [0, 30, 60, 90, 120, 150, 180, 210, 240, 270];
    for (let i = 0; i < bevEnergyThresholds.length; i++) {
      if (energyKj > bevEnergyThresholds[i]) energyPoints = i + 1;
    }
  }

  // Sugar points (0-15 solid, 0-10 beverage)
  let sugarPoints = 0;
  if (!isBeverage) {
    const sugarThresholds = [3.4, 6.8, 10, 13.5, 17, 20, 24, 27, 31, 34, 38, 41, 45, 48, 52];
    for (let i = 0; i < sugarThresholds.length; i++) {
      if (nutrient.sugar > sugarThresholds[i]) sugarPoints = i + 1;
    }
  } else {
    const bevSugarThresholds = [0, 1.5, 3.0, 4.5, 6.0, 7.5, 9.0, 10.5, 12.0, 13.5];
    for (let i = 0; i < bevSugarThresholds.length; i++) {
      if (nutrient.sugar > bevSugarThresholds[i]) sugarPoints = i + 1;
    }
  }

  // Saturated Fat points (0-10)
  let satFatPoints = 0;
  const satFatThresholds = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
  for (let i = 0; i < satFatThresholds.length; i++) {
    if (nutrient.saturatedFat > satFatThresholds[i]) satFatPoints = i + 1;
  }

  // Sodium points (0-10)
  let sodiumPoints = 0;
  const sodiumThresholds = [90, 180, 270, 360, 450, 540, 630, 720, 810, 900];
  for (let i = 0; i < sodiumThresholds.length; i++) {
    if (nutrient.sodium > sodiumThresholds[i]) sodiumPoints = i + 1;
  }

  const pointsN = energyPoints + sugarPoints + satFatPoints + sodiumPoints;

  // FVNL Points (0-5)
  const fvnl = nutrient.fruitVegetablesLegumesPercent || 0;
  let fvnlPoints = 0;
  if (fvnl > 80) fvnlPoints = 5;
  else if (fvnl > 60) fvnlPoints = 2;
  else if (fvnl > 40) fvnlPoints = 1;

  // Fiber points (0-5)
  let fiberPoints = 0;
  const fiberThresholds = [0.9, 1.9, 2.8, 3.7, 4.7];
  for (let i = 0; i < fiberThresholds.length; i++) {
    if (nutrient.fiber > fiberThresholds[i]) fiberPoints = i + 1;
  }

  // Protein points (0-5)
  let proteinPoints = 0;
  const proteinThresholds = [1.6, 3.2, 4.8, 6.4, 8.0];
  for (let i = 0; i < proteinThresholds.length; i++) {
    if (nutrient.protein > proteinThresholds[i]) proteinPoints = i + 1;
  }

  let finalScore = 0;
  if (!isBeverage) {
    if (pointsN < 11 || fvnlPoints >= 5) {
      finalScore = pointsN - (fiberPoints + proteinPoints + fvnlPoints);
    } else {
      finalScore = pointsN - (fiberPoints + fvnlPoints);
    }
  } else {
    finalScore = pointsN - fvnlPoints;
  }

  let grade: 'A' | 'B' | 'C' | 'D' | 'E' = 'C';
  let trafficLight: 'green' | 'light-green' | 'yellow' | 'orange' | 'red' = 'yellow';
  let meaning = 'Moderate nutritional profile';

  if (!isBeverage) {
    if (finalScore <= -1) {
      grade = 'A';
      trafficLight = 'green';
      meaning = 'Best nutritional profile';
    } else if (finalScore <= 2) {
      grade = 'B';
      trafficLight = 'light-green';
      meaning = 'Good nutritional profile';
    } else if (finalScore <= 10) {
      grade = 'C';
      trafficLight = 'yellow';
      meaning = 'Moderate nutritional profile';
    } else if (finalScore <= 18) {
      grade = 'D';
      trafficLight = 'orange';
      meaning = 'Less favorable nutritional profile';
    } else {
      grade = 'E';
      trafficLight = 'red';
      meaning = 'Least favorable nutritional profile';
    }
  } else {
    if (finalScore <= 1) {
      grade = 'B';
      trafficLight = 'light-green';
      meaning = 'Good beverage profile';
    } else if (finalScore <= 5) {
      grade = 'C';
      trafficLight = 'yellow';
      meaning = 'Moderate beverage profile';
    } else if (finalScore <= 9) {
      grade = 'D';
      trafficLight = 'orange';
      meaning = 'High sugar/calorie beverage';
    } else {
      grade = 'E';
      trafficLight = 'red';
      meaning = 'Least favorable beverage profile';
    }
  }

  const warnings: Array<{ type: string; text: string }> = [];
  if (nutrient.sodium >= 500) warnings.push({ type: 'sodium', text: 'High Sodium (>500mg/100g)' });
  if (nutrient.saturatedFat >= 5.0) warnings.push({ type: 'satFat', text: 'High Saturated Fat (>5g/100g)' });
  if (nutrient.sugar >= 12.0) warnings.push({ type: 'sugar', text: 'High Sugar (>12g/100g)' });
  if (nutrient.calories >= 450) warnings.push({ type: 'calories', text: 'High Caloric Density (>450 kcal/100g)' });

  const highlights: Array<{ type: string; text: string }> = [];
  if (nutrient.protein >= 10.0) highlights.push({ type: 'protein', text: 'High Protein (>10g/100g)' });
  if (nutrient.fiber >= 5.0) highlights.push({ type: 'fiber', text: 'Rich in Fiber (>5g/100g)' });
  if (nutrient.sugar <= 3.0) highlights.push({ type: 'sugar', text: 'Low Sugar (<3g/100g)' });
  if (nutrient.saturatedFat <= 1.5) highlights.push({ type: 'satFat', text: 'Low Saturated Fat (<1.5g/100g)' });

  return {
    pointsN,
    pointsP: fiberPoints + proteinPoints + fvnlPoints,
    finalScore,
    grade,
    trafficLight,
    meaning,
    breakdown: {
      energyPoints,
      sugarPoints,
      satFatPoints,
      sodiumPoints,
      fiberPoints,
      proteinPoints,
      fvnlPoints
    },
    warnings,
    highlights
  };
}

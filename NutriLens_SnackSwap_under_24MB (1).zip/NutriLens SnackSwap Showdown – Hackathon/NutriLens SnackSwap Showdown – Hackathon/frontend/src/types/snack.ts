export interface Nutrition {
  calories: number;
  totalFat: number;
  saturatedFat: number;
  carbohydrates: number;
  sugar: number;
  protein: number;
  fiber: number;
  sodium: number;
  fruitVegetablesLegumesPercent?: number;
}

export interface ScoringBreakdown {
  energyPoints: number;
  sugarPoints: number;
  satFatPoints: number;
  sodiumPoints: number;
  fiberPoints: number;
  proteinPoints: number;
  fvnlPoints: number;
  pointsN: number;
  pointsP: number;
  finalScore: number;
}

export interface Snack {
  id: number;
  name: string;
  category: string;
  description: string;
  image: string;
  isHealthyAlternative: boolean;
  servingSizeDescription: string;
  servingSizeGrams: number;
  priceINR: number;
  tasteTexture: string;
  flavorNotes: string;
  preparationMethod: string;
  hostelFriendly: boolean;
  prepTimeMinutes: number;
  allergens: string[];
  dataSource: string;
  lastVerified: string;
  healthScore: number;
  healthGrade: 'A' | 'B' | 'C' | 'D' | 'E';
  trafficLight: 'green' | 'light-green' | 'yellow' | 'orange' | 'red';
  gradeMeaning: string;
  isBeverage: boolean;
  swapReasons?: string;
  nutrition: Nutrition;
  scoringBreakdown?: ScoringBreakdown;
  warnings?: Array<{ type: string; text: string }>;
  highlights?: Array<{ type: string; text: string }>;
}

export interface Recommendation {
  snack: Snack;
  similarityScore: number;
  nutritionalDistance: number;
  tasteMatchQuality: string;
  textureMatchQuality: string;
  priceComparisonINR: number;
  caloriesSavedPer100g: number;
  sugarSavedPer100g: number;
  sodiumSavedPer100g: number;
  satFatSavedPer100g: number;
  proteinGainedPer100g: number;
  fiberGainedPer100g: number;
  whySuggested: string;
}

export interface ComparisonResult {
  original: Snack;
  alternative: Snack;
  diff100g: {
    calories: number;
    totalFat: number;
    saturatedFat: number;
    carbohydrates: number;
    sugar: number;
    protein: number;
    fiber: number;
    sodium: number;
  };
  diffServing: {
    calories: number;
    totalFat: number;
    saturatedFat: number;
    sugar: number;
    protein: number;
    fiber: number;
    sodium: number;
  };
  origServing: Nutrition;
  altServing: Nutrition;
  percentageReductions: {
    calories: number;
    totalFat: number;
    saturatedFat: number;
    sugar: number;
    sodium: number;
  };
  exerciseEquivalents: {
    original: { walkingMinutes: number; joggingMinutes: number; cyclingMinutes: number };
    alternative: { walkingMinutes: number; joggingMinutes: number; cyclingMinutes: number };
    savedWorkoutMinutes: { walking: number; jogging: number; cycling: number };
  };
}

export interface SwapLogItem {
  logId: number;
  quantityGrams: number;
  caloriesSaved: number;
  sugarSaved: number;
  sodiumSaved: number;
  satFatSaved?: number;
  proteinGained?: number;
  fiberGained?: number;
  timestamp: string;
  origId?: number;
  origName: string;
  origImage?: string;
  origGrade: string;
  altId?: number;
  altName: string;
  altImage?: string;
  altGrade: string;
}

export interface DashboardStats {
  totalSwaps: number;
  totalCaloriesSaved: number;
  totalSugarSaved: number;
  totalSodiumSaved: number;
  totalSatFatSaved: number;
  totalProteinGained: number;
  totalFiberGained: number;
  activityEquivalents: {
    walkingMinutes: number;
    joggingMinutes: number;
    cyclingMinutes: number;
  };
  challengeProgress: {
    totalDays: number;
    completedDays: number;
  };
}

export interface ChallengeDay {
  id: number;
  dayNumber: number;
  title: string;
  targetSwapCategory: string;
  description: string;
  badgeName: string;
  badgeIcon: string;
  isCompleted: boolean;
  completedAt?: string | null;
}

import { Snack, ComparisonResult, Recommendation, DashboardStats, SwapLogItem, ChallengeDay } from '../types/snack';

const BASE_URL = '/api';

export async function fetchAllSnacks(params?: { q?: string; category?: string; healthy?: boolean; hostel?: boolean }): Promise<Snack[]> {
  const query = new URLSearchParams();
  if (params?.q) query.set('q', params.q);
  if (params?.category && params.category !== 'All') query.set('category', params.category);
  if (params?.healthy !== undefined) query.set('healthy', String(params.healthy));
  if (params?.hostel) query.set('hostel', 'true');

  const res = await fetch(`${BASE_URL}/snacks?${query.toString()}`);
  if (!res.ok) throw new Error('Failed to fetch snacks');
  const data = await res.json();
  return data.data;
}

export async function fetchSnackById(id: number | string): Promise<Snack> {
  const res = await fetch(`${BASE_URL}/snacks/${id}`);
  if (!res.ok) throw new Error(`Failed to fetch snack #${id}`);
  const data = await res.json();
  return data.data;
}

export async function fetchAlternatives(id: number | string): Promise<{ originalSnack: Snack; recommendations: Recommendation[] }> {
  const res = await fetch(`${BASE_URL}/snacks/${id}/swaps`);
  if (!res.ok) throw new Error(`Failed to fetch alternatives for snack #${id}`);
  return await res.json();
}

export async function fetchComparison(originalId: number | string, alternativeId: number | string): Promise<ComparisonResult> {
  const res = await fetch(`${BASE_URL}/compare/${originalId}/${alternativeId}`);
  if (!res.ok) throw new Error('Failed to fetch comparison');
  return await res.json();
}

export async function logSnackSwap(originalSnackId: number, alternativeSnackId: number, quantityGrams: number) {
  const res = await fetch(`${BASE_URL}/swaps/log`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ originalSnackId, alternativeSnackId, quantityGrams })
  });
  if (!res.ok) throw new Error('Failed to log swap');
  return await res.json();
}

export async function fetchSwapHistory(): Promise<SwapLogItem[]> {
  const res = await fetch(`${BASE_URL}/swaps/history`);
  if (!res.ok) throw new Error('Failed to fetch swap history');
  const data = await res.json();
  return data.data;
}

export async function fetchDashboardData(): Promise<{
  stats: DashboardStats;
  recentSwaps: SwapLogItem[];
  dailyTimeline: any[];
  categoryBreakdown: any[];
}> {
  const res = await fetch(`${BASE_URL}/dashboard`);
  if (!res.ok) throw new Error('Failed to fetch dashboard data');
  return await res.json();
}

export async function fetchWeeklyChallenge(): Promise<{
  challengeTitle: string;
  subtitle: string;
  progress: { completedDays: number; totalDays: number; percentage: number; streakDays: number };
  days: ChallengeDay[];
  badges: any[];
}> {
  const res = await fetch(`${BASE_URL}/challenges/weekly`);
  if (!res.ok) throw new Error('Failed to fetch challenge');
  return await res.json();
}

export async function toggleChallengeDayApi(dayNumber: number): Promise<any> {
  const res = await fetch(`${BASE_URL}/challenges/${dayNumber}/toggle`, {
    method: 'POST'
  });
  if (!res.ok) throw new Error(`Failed to toggle day ${dayNumber}`);
  return await res.json();
}

export async function lookupBarcodeApi(barcode: string): Promise<any> {
  const res = await fetch(`${BASE_URL}/scanner/lookup`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ barcode })
  });
  if (!res.ok) throw new Error('Failed to scan barcode');
  return await res.json();
}

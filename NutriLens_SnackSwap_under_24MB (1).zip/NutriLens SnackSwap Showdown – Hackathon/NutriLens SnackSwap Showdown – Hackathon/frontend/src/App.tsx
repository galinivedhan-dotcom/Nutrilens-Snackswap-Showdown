import React, { useEffect } from 'react';
import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { Home } from './pages/Home';
import { Explore } from './pages/Explore';
import { SnackDetails } from './pages/SnackDetails';
import { Recommendations } from './pages/Recommendations';
import { Compare } from './pages/Compare';
import { Dashboard } from './pages/Dashboard';
import { MySwaps } from './pages/MySwaps';
import { HostelHacks } from './pages/HostelHacks';
import { Challenge } from './pages/Challenge';
import { Scanner } from './pages/Scanner';

// Scroll to top on route change
function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
}

export function App() {
  return (
    <BrowserRouter>
      <ScrollToTop />
      <div className="flex flex-col min-h-screen bg-[#0B132B] text-slate-100 font-sans selection:bg-emerald-500 selection:text-slate-950">
        <Navbar />
        <main className="flex-1">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/explore" element={<Explore />} />
            <Route path="/snack/:id" element={<SnackDetails />} />
            <Route path="/recommendations/:id" element={<Recommendations />} />
            <Route path="/compare" element={<Compare />} />
            <Route path="/compare/:id" element={<Compare />} />
            <Route path="/compare/:id/:alternativeId" element={<Compare />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/my-swaps" element={<MySwaps />} />
            <Route path="/hostel-hacks" element={<HostelHacks />} />
            <Route path="/challenge" element={<Challenge />} />
            <Route path="/scanner" element={<Scanner />} />
            <Route path="*" element={<Home />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </BrowserRouter>
  );
}

export default App;

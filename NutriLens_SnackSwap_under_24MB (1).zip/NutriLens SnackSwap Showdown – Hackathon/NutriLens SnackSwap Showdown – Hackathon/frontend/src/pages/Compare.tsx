import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { ComparisonResult, Snack } from '../types/snack';
import { fetchComparison, logSnackSwap, fetchAllSnacks } from '../services/api';
import { HealthGradeBadge } from '../components/HealthGradeBadge';
import { ExerciseCalculator } from '../components/ExerciseCalculator';
import confetti from 'canvas-confetti';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  RadialLinearScale,
  PointElement,
  LineElement,
  Filler,
  Tooltip,
  Legend,
} from 'chart.js';
import { Bar, Radar } from 'react-chartjs-2';
import { 
  Scale, 
  ArrowRight, 
  Sparkles, 
  Check, 
  Flame, 
  TrendingDown, 
  TrendingUp, 
  ArrowLeftRight,
  ShieldCheck,
  Share2
} from 'lucide-react';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  RadialLinearScale,
  PointElement,
  LineElement,
  Filler,
  Tooltip,
  Legend
);

export const Compare: React.FC = () => {
  const { id = '1', alternativeId = '21' } = useParams<{ id: string; alternativeId: string }>();
  const navigate = useNavigate();

  const [comparison, setComparison] = useState<ComparisonResult | null>(null);
  const [loading, setLoading] = useState(true);
  const [allSnacks, setAllSnacks] = useState<Snack[]>([]);
  const [useServing, setUseServing] = useState(false);
  const [customServingGrams, setCustomServingGrams] = useState(50);
  const [loggingSwap, setLoggingSwap] = useState(false);
  const [swapLoggedSuccess, setSwapLoggedSuccess] = useState(false);

  // Load comparison data
  useEffect(() => {
    setLoading(true);
    fetchComparison(id, alternativeId)
      .then((data) => {
        setComparison(data);
        setCustomServingGrams(data.original.servingSizeGrams || 50);
      })
      .catch(console.error)
      .finally(() => setLoading(false));

    fetchAllSnacks().then(setAllSnacks).catch(console.error);
  }, [id, alternativeId]);

  const handleSwapLog = async () => {
    if (!comparison) return;
    setLoggingSwap(true);
    try {
      const qty = useServing ? customServingGrams : 100;
      await logSnackSwap(comparison.original.id, comparison.alternative.id, qty);

      // Trigger Confetti!
      confetti({
        particleCount: 100,
        spread: 80,
        origin: { y: 0.5 }
      });

      setSwapLoggedSuccess(true);
    } catch (err) {
      console.error('Error logging swap:', err);
    } finally {
      setLoggingSwap(false);
    }
  };

  if (loading) {
    return (
      <div className="py-24 text-center">
        <div className="w-10 h-10 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
        <p className="text-sm text-slate-400">Loading side-by-side nutrition showdown...</p>
      </div>
    );
  }

  if (!comparison) {
    return (
      <div className="max-w-xl mx-auto py-20 text-center">
        <h2 className="text-xl font-bold text-white">Comparison snacks not found</h2>
        <Link to="/explore" className="text-emerald-400 hover:underline mt-3 inline-block text-sm">
          Return to Explore
        </Link>
      </div>
    );
  }

  const orig = comparison.original;
  const alt = comparison.alternative;

  // Selected baseline: 100g or serving
  const factorOrig = useServing ? (customServingGrams / 100) : 1;
  const factorAlt = useServing ? (customServingGrams / 100) : 1;

  const currentOrig = {
    calories: Math.round(orig.nutrition.calories * factorOrig * 10) / 10,
    totalFat: Math.round(orig.nutrition.totalFat * factorOrig * 10) / 10,
    saturatedFat: Math.round(orig.nutrition.saturatedFat * factorOrig * 10) / 10,
    sugar: Math.round(orig.nutrition.sugar * factorOrig * 10) / 10,
    protein: Math.round(orig.nutrition.protein * factorOrig * 10) / 10,
    fiber: Math.round(orig.nutrition.fiber * factorOrig * 10) / 10,
    sodium: Math.round(orig.nutrition.sodium * factorOrig)
  };

  const currentAlt = {
    calories: Math.round(alt.nutrition.calories * factorAlt * 10) / 10,
    totalFat: Math.round(alt.nutrition.totalFat * factorAlt * 10) / 10,
    saturatedFat: Math.round(alt.nutrition.saturatedFat * factorAlt * 10) / 10,
    sugar: Math.round(alt.nutrition.sugar * factorAlt * 10) / 10,
    protein: Math.round(alt.nutrition.protein * factorAlt * 10) / 10,
    fiber: Math.round(alt.nutrition.fiber * factorAlt * 10) / 10,
    sodium: Math.round(alt.nutrition.sodium * factorAlt)
  };

  const calDiff = Math.round((currentOrig.calories - currentAlt.calories) * 10) / 10;
  const satFatDiff = Math.round((currentOrig.saturatedFat - currentAlt.saturatedFat) * 10) / 10;
  const sugarDiff = Math.round((currentOrig.sugar - currentAlt.sugar) * 10) / 10;
  const sodiumDiff = Math.round(currentOrig.sodium - currentAlt.sodium);
  const proteinDiff = Math.round((currentAlt.protein - currentOrig.protein) * 10) / 10;
  const fiberDiff = Math.round((currentAlt.fiber - currentOrig.fiber) * 10) / 10;

  // Chart 1: Bar Chart Data
  const barChartData = {
    labels: ['Total Fat (g)', 'Saturated Fat (g)', 'Sugar (g)', 'Protein (g)', 'Fiber (g)'],
    datasets: [
      {
        label: orig.name,
        data: [currentOrig.totalFat, currentOrig.saturatedFat, currentOrig.sugar, currentOrig.protein, currentOrig.fiber],
        backgroundColor: 'rgba(239, 68, 68, 0.75)',
        borderColor: '#EF4444',
        borderWidth: 1.5,
        borderRadius: 6
      },
      {
        label: alt.name,
        data: [currentAlt.totalFat, currentAlt.saturatedFat, currentAlt.sugar, currentAlt.protein, currentAlt.fiber],
        backgroundColor: 'rgba(16, 185, 129, 0.75)',
        borderColor: '#10B981',
        borderWidth: 1.5,
        borderRadius: 6
      }
    ]
  };

  // Chart 2: Radar Chart (Macronutrient Balance)
  const radarChartData = {
    labels: ['Protein Density', 'Dietary Fiber', 'Sodium Control (Inverse)', 'Fat Quality', 'Sugar Control (Inverse)'],
    datasets: [
      {
        label: orig.name,
        data: [
          Math.min(currentOrig.protein * 4, 100),
          Math.min(currentOrig.fiber * 6, 100),
          Math.max(100 - (currentOrig.sodium / 10), 0),
          Math.max(100 - (currentOrig.saturatedFat * 8), 0),
          Math.max(100 - (currentOrig.sugar * 3), 0)
        ],
        backgroundColor: 'rgba(239, 68, 68, 0.2)',
        borderColor: '#EF4444',
        borderWidth: 2,
        pointBackgroundColor: '#EF4444'
      },
      {
        label: alt.name,
        data: [
          Math.min(currentAlt.protein * 4, 100),
          Math.min(currentAlt.fiber * 6, 100),
          Math.max(100 - (currentAlt.sodium / 10), 0),
          Math.max(100 - (currentAlt.saturatedFat * 8), 0),
          Math.max(100 - (currentAlt.sugar * 3), 0)
        ],
        backgroundColor: 'rgba(16, 185, 129, 0.25)',
        borderColor: '#10B981',
        borderWidth: 2,
        pointBackgroundColor: '#10B981'
      }
    ]
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Page Title & Snack Switchers */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center space-x-2">
            <span className="text-xs uppercase font-extrabold tracking-widest text-emerald-400">
              Module 5: Side-by-Side Showdown
            </span>
            <span className="text-xs bg-slate-800 text-slate-300 px-2 py-0.5 rounded-full border border-slate-700">
              Main Hackathon Demo
            </span>
          </div>
          <h1 className="text-3xl font-extrabold text-white mt-1">
            {orig.name} <span className="text-slate-500 font-light">vs</span> {alt.name}
          </h1>
        </div>

        {/* Serving Size Selector Toggle */}
        <div className="flex items-center space-x-2 bg-slate-900 p-1.5 rounded-xl border border-slate-800 self-start md:self-auto">
          <button
            onClick={() => setUseServing(false)}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all ${
              !useServing
                ? 'bg-emerald-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Per 100g (Standard Baseline)
          </button>
          <button
            onClick={() => setUseServing(true)}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all ${
              useServing
                ? 'bg-emerald-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Per Serving ({customServingGrams}g)
          </button>
        </div>
      </div>

      {/* Quick Snack Selector Dropdowns */}
      <div className="p-3 bg-slate-900/60 rounded-xl border border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center space-x-2">
          <span className="text-slate-400 font-medium">Original Snack:</span>
          <select
            value={orig.id}
            onChange={(e) => navigate(`/compare/${e.target.value}/${alt.id}`)}
            className="bg-slate-950 text-white border border-slate-700 rounded-lg px-2.5 py-1 focus:outline-none focus:border-emerald-500"
          >
            {allSnacks.filter(s => !s.isHealthyAlternative).map(s => (
              <option key={s.id} value={s.id}>{s.name} (Grade {s.healthGrade})</option>
            ))}
          </select>
        </div>

        <ArrowLeftRight className="w-4 h-4 text-emerald-400 hidden sm:block" />

        <div className="flex items-center space-x-2">
          <span className="text-slate-400 font-medium">Healthy Swap:</span>
          <select
            value={alt.id}
            onChange={(e) => navigate(`/compare/${orig.id}/${e.target.value}`)}
            className="bg-slate-950 text-white border border-slate-700 rounded-lg px-2.5 py-1 focus:outline-none focus:border-emerald-500"
          >
            {allSnacks.filter(s => s.isHealthyAlternative).map(s => (
              <option key={s.id} value={s.id}>{s.name} (Grade {s.healthGrade})</option>
            ))}
          </select>
        </div>
      </div>

      {/* Head-to-Head Hero Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Original Snack (Left) */}
        <div className="glass-card rounded-2xl p-6 border border-rose-500/30 bg-gradient-to-br from-rose-950/20 to-slate-900/60">
          <div className="flex items-center justify-between mb-4">
            <span className="text-[10px] uppercase font-black tracking-widest text-rose-400 px-2 py-0.5 rounded bg-rose-500/20 border border-rose-500/30">
              Original Craving
            </span>
            <HealthGradeBadge grade={orig.healthGrade} score={orig.healthScore} size="md" />
          </div>

          <div className="flex items-center space-x-4 mb-4">
            <img
              src={orig.image}
              alt={orig.name}
              className="w-20 h-20 rounded-2xl object-cover border border-slate-700 shadow-md"
            />
            <div>
              <h3 className="text-xl font-extrabold text-white">{orig.name}</h3>
              <p className="text-xs text-slate-400">{orig.category} · ₹{orig.priceINR}</p>
              <span className="text-xs font-black text-rose-400 mt-1 block">
                {currentOrig.calories} kcal / {useServing ? `${customServingGrams}g` : '100g'}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2 text-center text-xs bg-slate-950/60 p-3 rounded-xl border border-slate-800">
            <div>
              <span className="text-slate-400 text-[10px] block">Sat. Fat</span>
              <span className="font-bold text-rose-300">{currentOrig.saturatedFat}g</span>
            </div>
            <div>
              <span className="text-slate-400 text-[10px] block">Sugar</span>
              <span className="font-bold text-rose-300">{currentOrig.sugar}g</span>
            </div>
            <div>
              <span className="text-slate-400 text-[10px] block">Sodium</span>
              <span className="font-bold text-rose-300">{currentOrig.sodium}mg</span>
            </div>
          </div>
        </div>

        {/* Alternative Snack (Right) */}
        <div className="glass-card rounded-2xl p-6 border border-emerald-500/40 bg-gradient-to-br from-emerald-950/20 to-slate-900/60 relative overflow-hidden">
          <div className="flex items-center justify-between mb-4">
            <span className="text-[10px] uppercase font-black tracking-widest text-emerald-400 px-2 py-0.5 rounded bg-emerald-500/20 border border-emerald-500/30 flex items-center space-x-1">
              <Sparkles className="w-3 h-3" />
              <span>Recommended Swap</span>
            </span>
            <HealthGradeBadge grade={alt.healthGrade} score={alt.healthScore} size="md" />
          </div>

          <div className="flex items-center space-x-4 mb-4">
            <img
              src={alt.image}
              alt={alt.name}
              className="w-20 h-20 rounded-2xl object-cover border border-emerald-500/40 shadow-md"
            />
            <div>
              <h3 className="text-xl font-extrabold text-white">{alt.name}</h3>
              <p className="text-xs text-slate-400">{alt.category} · ₹{alt.priceINR}</p>
              <span className="text-xs font-black text-emerald-400 mt-1 block">
                {currentAlt.calories} kcal / {useServing ? `${customServingGrams}g` : '100g'}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2 text-center text-xs bg-slate-950/60 p-3 rounded-xl border border-slate-800">
            <div>
              <span className="text-slate-400 text-[10px] block">Sat. Fat</span>
              <span className="font-bold text-emerald-300">{currentAlt.saturatedFat}g</span>
            </div>
            <div>
              <span className="text-slate-400 text-[10px] block">Sugar</span>
              <span className="font-bold text-emerald-300">{currentAlt.sugar}g</span>
            </div>
            <div>
              <span className="text-slate-400 text-[10px] block">Sodium</span>
              <span className="font-bold text-emerald-300">{currentAlt.sodium}mg</span>
            </div>
          </div>
        </div>
      </div>

      {/* Difference Stat Badges */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {/* Calories difference */}
        <div className="glass-card rounded-2xl p-4 border border-slate-800 text-center">
          <span className="text-xs text-slate-400 block font-medium">Calories Difference</span>
          <div className="flex items-center justify-center space-x-1 mt-1">
            <TrendingDown className="w-4 h-4 text-emerald-400" />
            <span className="text-2xl font-black text-emerald-400">
              {calDiff > 0 ? `-${calDiff}` : `+${Math.abs(calDiff)}`}
            </span>
          </div>
          <span className="text-[11px] text-slate-500">kcal saved</span>
        </div>

        {/* Saturated Fat Reduction */}
        <div className="glass-card rounded-2xl p-4 border border-slate-800 text-center">
          <span className="text-xs text-slate-400 block font-medium">Saturated Fat Cut</span>
          <div className="flex items-center justify-center space-x-1 mt-1">
            <TrendingDown className="w-4 h-4 text-emerald-400" />
            <span className="text-2xl font-black text-emerald-400">
              {satFatDiff > 0 ? `-${satFatDiff}g` : `+${Math.abs(satFatDiff)}g`}
            </span>
          </div>
          <span className="text-[11px] text-emerald-500 font-bold">
            {comparison.percentageReductions.saturatedFat}% reduction!
          </span>
        </div>

        {/* Sodium Avoided */}
        <div className="glass-card rounded-2xl p-4 border border-slate-800 text-center">
          <span className="text-xs text-slate-400 block font-medium">Sodium Avoided</span>
          <div className="flex items-center justify-center space-x-1 mt-1">
            <TrendingDown className="w-4 h-4 text-emerald-400" />
            <span className="text-2xl font-black text-emerald-400">
              {sodiumDiff > 0 ? `-${sodiumDiff}` : `+${Math.abs(sodiumDiff)}`}
            </span>
          </div>
          <span className="text-[11px] text-slate-500">mg sodium</span>
        </div>

        {/* Protein Gain */}
        <div className="glass-card rounded-2xl p-4 border border-slate-800 text-center">
          <span className="text-xs text-slate-400 block font-medium">Protein Gained</span>
          <div className="flex items-center justify-center space-x-1 mt-1">
            <TrendingUp className="w-4 h-4 text-emerald-400" />
            <span className="text-2xl font-black text-emerald-400">
              +{proteinDiff}g
            </span>
          </div>
          <span className="text-[11px] text-emerald-500 font-bold">muscle nourishment</span>
        </div>
      </div>

      {/* Nutritional Comparison Table */}
      <div className="glass-card rounded-2xl overflow-hidden border border-slate-800">
        <div className="p-4 border-b border-slate-800 bg-slate-900/60 flex items-center justify-between">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider">
            Nutritional Comparison Table ({useServing ? `${customServingGrams}g Serving` : '100g Standard'})
          </h3>
          <span className="text-xs text-slate-400">All numbers measured per equal quantity</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950/80 text-slate-400 border-b border-slate-800 uppercase font-semibold text-[10px]">
              <tr>
                <th className="py-3 px-4">Nutrient</th>
                <th className="py-3 px-4 text-rose-400">{orig.name}</th>
                <th className="py-3 px-4 text-emerald-400">{alt.name}</th>
                <th className="py-3 px-4">Net Difference</th>
                <th className="py-3 px-4">Improvement</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              <tr>
                <td className="py-3 px-4 font-semibold text-slate-200">Calories</td>
                <td className="py-3 px-4 text-slate-300 font-bold">{currentOrig.calories} kcal</td>
                <td className="py-3 px-4 text-emerald-400 font-bold">{currentAlt.calories} kcal</td>
                <td className="py-3 px-4 font-bold text-emerald-400">-{calDiff} kcal</td>
                <td className="py-3 px-4 text-emerald-400 font-semibold">{comparison.percentageReductions.calories}% fewer</td>
              </tr>
              <tr>
                <td className="py-3 px-4 font-semibold text-slate-200">Total Fat</td>
                <td className="py-3 px-4 text-slate-300 font-bold">{currentOrig.totalFat} g</td>
                <td className="py-3 px-4 text-emerald-400 font-bold">{currentAlt.totalFat} g</td>
                <td className="py-3 px-4 font-bold text-emerald-400">
                  {currentOrig.totalFat - currentAlt.totalFat > 0 ? `-${Math.round((currentOrig.totalFat - currentAlt.totalFat)*10)/10} g` : '0 g'}
                </td>
                <td className="py-3 px-4 text-emerald-400 font-semibold">{comparison.percentageReductions.totalFat}% less fat</td>
              </tr>
              <tr>
                <td className="py-3 px-4 font-semibold text-slate-200">Saturated Fat</td>
                <td className="py-3 px-4 text-rose-400 font-bold">{currentOrig.saturatedFat} g</td>
                <td className="py-3 px-4 text-emerald-400 font-bold">{currentAlt.saturatedFat} g</td>
                <td className="py-3 px-4 font-bold text-emerald-400">-{satFatDiff} g</td>
                <td className="py-3 px-4 text-emerald-400 font-semibold">{comparison.percentageReductions.saturatedFat}% cut</td>
              </tr>
              <tr>
                <td className="py-3 px-4 font-semibold text-slate-200">Sugar</td>
                <td className="py-3 px-4 text-slate-300 font-bold">{currentOrig.sugar} g</td>
                <td className="py-3 px-4 text-emerald-400 font-bold">{currentAlt.sugar} g</td>
                <td className="py-3 px-4 font-bold text-emerald-400">-{sugarDiff} g</td>
                <td className="py-3 px-4 text-emerald-400 font-semibold">{comparison.percentageReductions.sugar}% less sugar</td>
              </tr>
              <tr>
                <td className="py-3 px-4 font-semibold text-slate-200">Protein</td>
                <td className="py-3 px-4 text-slate-300 font-bold">{currentOrig.protein} g</td>
                <td className="py-3 px-4 text-emerald-400 font-bold">{currentAlt.protein} g</td>
                <td className="py-3 px-4 font-bold text-emerald-400">+{proteinDiff} g</td>
                <td className="py-3 px-4 text-emerald-400 font-semibold">Protein Boost</td>
              </tr>
              <tr>
                <td className="py-3 px-4 font-semibold text-slate-200">Dietary Fiber</td>
                <td className="py-3 px-4 text-slate-300 font-bold">{currentOrig.fiber} g</td>
                <td className="py-3 px-4 text-emerald-400 font-bold">{currentAlt.fiber} g</td>
                <td className="py-3 px-4 font-bold text-emerald-400">+{fiberDiff} g</td>
                <td className="py-3 px-4 text-emerald-400 font-semibold">Digestion support</td>
              </tr>
              <tr>
                <td className="py-3 px-4 font-semibold text-slate-200">Sodium</td>
                <td className="py-3 px-4 text-rose-400 font-bold">{currentOrig.sodium} mg</td>
                <td className="py-3 px-4 text-emerald-400 font-bold">{currentAlt.sodium} mg</td>
                <td className="py-3 px-4 font-bold text-emerald-400">-{sodiumDiff} mg</td>
                <td className="py-3 px-4 text-emerald-400 font-semibold">{comparison.percentageReductions.sodium}% lower sodium</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Visual Analytics Charts (Bar Chart & Radar Chart) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Horizontal / Grouped Bar Chart */}
        <div className="glass-card rounded-2xl p-5 border border-slate-800">
          <div className="mb-4">
            <h4 className="text-sm font-bold text-white">Nutritional Balance Comparison</h4>
            <p className="text-xs text-slate-400">Direct comparison across key macronutrients (in grams)</p>
          </div>
          <div className="h-64 flex items-center justify-center">
            <Bar
              data={barChartData}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                  legend: { labels: { color: '#cbd5e1', font: { size: 11 } } }
                },
                scales: {
                  x: { ticks: { color: '#94a3b8' }, grid: { color: 'rgba(255,255,255,0.05)' } },
                  y: { ticks: { color: '#94a3b8' }, grid: { color: 'rgba(255,255,255,0.05)' } }
                }
              }}
            />
          </div>
        </div>

        {/* Radar Chart */}
        <div className="glass-card rounded-2xl p-5 border border-slate-800">
          <div className="mb-4">
            <h4 className="text-sm font-bold text-white">Holistic Nutritional Radar</h4>
            <p className="text-xs text-slate-400">Visualizing micronutrient quality, sodium moderation, and protein</p>
          </div>
          <div className="h-64 flex items-center justify-center">
            <Radar
              data={radarChartData}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                  legend: { labels: { color: '#cbd5e1', font: { size: 11 } } }
                },
                scales: {
                  r: {
                    angleLines: { color: 'rgba(255,255,255,0.1)' },
                    grid: { color: 'rgba(255,255,255,0.08)' },
                    pointLabels: { color: '#cbd5e1', font: { size: 10 } },
                    ticks: { display: false }
                  }
                }
              }}
            />
          </div>
        </div>
      </div>

      {/* Module 6: Exercise Equivalency Comparison */}
      <ExerciseCalculator
        calories={currentOrig.calories}
        snackName={orig.name}
        savedCalories={calDiff}
        savedMinutes={comparison.exerciseEquivalents.savedWorkoutMinutes}
      />

      {/* The Big Hackathon Demo CTA Button: "I Swapped This!" */}
      <div className="p-8 glass-card rounded-3xl border border-emerald-500/40 text-center bg-gradient-to-r from-emerald-950/40 via-slate-900 to-teal-950/40 space-y-4">
        <div className="max-w-xl mx-auto">
          <span className="text-xs uppercase font-extrabold tracking-widest text-emerald-400 block mb-1">
            Turn Knowledge into Action
          </span>
          <h2 className="text-2xl sm:text-3xl font-black text-white">
            Log This Swap in Your Weekly Tracker
          </h2>
          <p className="text-xs text-slate-400 mt-2">
            Clicking records this swap directly to your SQLite database, logs the {calDiff} kcal & {sodiumDiff}mg sodium avoided, and unlocks your challenge streak!
          </p>
        </div>

        <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            onClick={handleSwapLog}
            disabled={loggingSwap || swapLoggedSuccess}
            className={`px-8 py-3.5 rounded-xl font-black text-sm transition-all shadow-xl flex items-center space-x-2 ${
              swapLoggedSuccess
                ? 'bg-emerald-600 text-white cursor-default'
                : 'bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 hover:scale-105'
            }`}
          >
            {swapLoggedSuccess ? (
              <>
                <Check className="w-5 h-5 text-white" />
                <span>Swap Logged to Dashboard! 🎉</span>
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5" />
                <span>{loggingSwap ? 'Saving...' : 'I Swapped This!'}</span>
              </>
            )}
          </button>

          {swapLoggedSuccess && (
            <Link
              to="/dashboard"
              className="px-6 py-3.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-sm font-bold border border-slate-700 flex items-center space-x-2"
            >
              <span>View My Dashboard Analytics</span>
              <ArrowRight className="w-4 h-4 text-emerald-400" />
            </Link>
          )}
        </div>
      </div>
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { DashboardStats, SwapLogItem } from '../types/snack';
import { fetchDashboardData } from '../services/api';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  LineElement,
  PointElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Bar, Doughnut } from 'react-chartjs-2';
import { 
  Sparkles, 
  Flame, 
  Droplet, 
  Award, 
  TrendingDown, 
  Footprints, 
  Bike, 
  History, 
  ArrowRight,
  ShieldCheck,
  CheckCircle2
} from 'lucide-react';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  LineElement,
  PointElement,
  ArcElement,
  Title,
  Tooltip,
  Legend
);

export const Dashboard: React.FC = () => {
  const [data, setData] = useState<{
    stats: DashboardStats;
    recentSwaps: SwapLogItem[];
    dailyTimeline: any[];
    categoryBreakdown: any[];
  } | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData()
      .then(setData)
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="py-24 text-center">
        <div className="w-10 h-10 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
        <p className="text-sm text-slate-400">Loading your nutrition improvement analytics...</p>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="max-w-xl mx-auto py-20 text-center">
        <h2 className="text-xl font-bold text-white">Dashboard data unavailable</h2>
        <Link to="/explore" className="text-emerald-400 hover:underline mt-3 inline-block text-sm">
          Start Swapping Snacks
        </Link>
      </div>
    );
  }

  const { stats, recentSwaps, dailyTimeline, categoryBreakdown } = data;

  // Timeline chart data
  const timelineChartData = {
    labels: dailyTimeline.length > 0 ? dailyTimeline.map(d => d.swapDate) : ['Today'],
    datasets: [
      {
        label: 'Calories Saved (kcal)',
        data: dailyTimeline.length > 0 ? dailyTimeline.map(d => Math.round(d.calories)) : [stats.totalCaloriesSaved],
        backgroundColor: 'rgba(16, 185, 129, 0.7)',
        borderColor: '#10B981',
        borderRadius: 6
      }
    ]
  };

  // Category donut chart
  const categoryLabels = categoryBreakdown.length > 0 ? categoryBreakdown.map(c => c.category) : ['Chips & Crisps', 'Beverages', 'Street Food'];
  const categoryCounts = categoryBreakdown.length > 0 ? categoryBreakdown.map(c => c.count) : [3, 2, 1];

  const donutChartData = {
    labels: categoryLabels,
    datasets: [
      {
        data: categoryCounts,
        backgroundColor: [
          '#10B981',
          '#06D6A0',
          '#3B82F6',
          '#F59E0B',
          '#8B5CF6',
          '#EC4899'
        ],
        borderWidth: 2,
        borderColor: '#0B132B'
      }
    ]
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <span className="text-xs uppercase font-extrabold tracking-widest text-emerald-400">
            Module 7: My Snack Swaps Dashboard
          </span>
          <h1 className="text-3xl font-extrabold text-white mt-0.5">My Nutrition Progress</h1>
          <p className="text-xs text-slate-400 mt-1">
            Real cumulative improvements calculated from every healthy swap you logged.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <Link
            to="/my-swaps"
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl border border-slate-700 flex items-center space-x-1.5 transition-all"
          >
            <History className="w-4 h-4 text-emerald-400" />
            <span>Full Swap History</span>
          </Link>
          <Link
            to="/explore"
            className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-extrabold rounded-xl shadow-md transition-all flex items-center space-x-1"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Swap a Snack</span>
          </Link>
        </div>
      </div>

      {/* 4 Big Metrics Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Swaps */}
        <div className="glass-card rounded-2xl p-5 border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold">Swaps Logged</span>
            <div className="w-7 h-7 rounded-lg bg-emerald-500/15 text-emerald-400 flex items-center justify-center font-bold">
              <Sparkles className="w-3.5 h-3.5" />
            </div>
          </div>
          <span className="text-3xl font-black text-white">{stats.totalSwaps}</span>
          <span className="text-[11px] text-slate-400 block mt-1">Snack decisions upgraded</span>
        </div>

        {/* Calories Avoided */}
        <div className="glass-card rounded-2xl p-5 border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold">Energy Difference</span>
            <div className="w-7 h-7 rounded-lg bg-amber-500/15 text-amber-400 flex items-center justify-center font-bold">
              <Flame className="w-3.5 h-3.5" />
            </div>
          </div>
          <span className="text-3xl font-black text-amber-400">{stats.totalCaloriesSaved}</span>
          <span className="text-[11px] text-slate-400 block mt-1">kcal avoided without starving</span>
        </div>

        {/* Sugar Avoided */}
        <div className="glass-card rounded-2xl p-5 border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold">Sugar Difference</span>
            <div className="w-7 h-7 rounded-lg bg-rose-500/15 text-rose-400 flex items-center justify-center font-bold">
              <Droplet className="w-3.5 h-3.5" />
            </div>
          </div>
          <span className="text-3xl font-black text-rose-400">{stats.totalSugarSaved}g</span>
          <span className="text-[11px] text-slate-400 block mt-1">free refined sugar cut</span>
        </div>

        {/* Sodium Avoided */}
        <div className="glass-card rounded-2xl p-5 border border-slate-800">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs font-semibold">Sodium Difference</span>
            <div className="w-7 h-7 rounded-lg bg-teal-500/15 text-teal-400 flex items-center justify-center font-bold">
              <ShieldCheck className="w-3.5 h-3.5" />
            </div>
          </div>
          <span className="text-3xl font-black text-teal-400">{stats.totalSodiumSaved}mg</span>
          <span className="text-[11px] text-slate-400 block mt-1">excess sodium spared</span>
        </div>
      </div>

      {/* Challenge Progress Banner */}
      <div className="glass-card rounded-2xl p-6 border border-emerald-500/30 bg-gradient-to-r from-emerald-950/20 via-slate-900 to-slate-900 flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 flex items-center justify-center font-black">
            <Award className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs uppercase font-extrabold tracking-wider text-emerald-400">
              Weekly Challenge Progress
            </span>
            <h3 className="text-lg font-bold text-white mt-0.5">
              {stats.challengeProgress.completedDays} of {stats.challengeProgress.totalDays} Days Swapped
            </h3>
            <p className="text-xs text-slate-400">Keep your daily healthy streak alive!</p>
          </div>
        </div>

        <div className="flex-1 max-w-xs w-full">
          <div className="flex justify-between text-xs font-semibold mb-1">
            <span className="text-slate-400">Goal Completion</span>
            <span className="text-emerald-400">
              {Math.round((stats.challengeProgress.completedDays / stats.challengeProgress.totalDays) * 100)}%
            </span>
          </div>
          <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden">
            <div
              className="bg-gradient-to-r from-emerald-500 to-teal-400 h-full rounded-full transition-all duration-500"
              style={{
                width: `${(stats.challengeProgress.completedDays / stats.challengeProgress.totalDays) * 100}%`
              }}
            />
          </div>
        </div>

        <Link
          to="/challenge"
          className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold rounded-xl transition-all shrink-0"
        >
          Check In Today
        </Link>
      </div>

      {/* Exercise Equivalent Benefit Banner */}
      <div className="glass-card rounded-2xl p-6 border border-slate-800">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">
              Workout Energy Equivalency Saved
            </h3>
            <p className="text-xs text-slate-400">
              By choosing lighter snack alternatives, you spared your body from needing this extra energy burn!
            </p>
          </div>
          <span className="text-xs font-bold text-amber-400 bg-amber-500/10 px-2.5 py-1 rounded-lg border border-amber-500/30">
            {stats.totalCaloriesSaved} kcal total
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 text-center">
            <Footprints className="w-6 h-6 text-emerald-400 mx-auto mb-1.5" />
            <span className="text-xs text-slate-400 block">Walking Saved</span>
            <span className="text-2xl font-black text-white block mt-0.5">
              {stats.activityEquivalents.walkingMinutes} <span className="text-xs font-normal text-slate-400">minutes</span>
            </span>
          </div>

          <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 text-center">
            <Flame className="w-6 h-6 text-orange-400 mx-auto mb-1.5" />
            <span className="text-xs text-slate-400 block">Jogging Saved</span>
            <span className="text-2xl font-black text-white block mt-0.5">
              {stats.activityEquivalents.joggingMinutes} <span className="text-xs font-normal text-slate-400">minutes</span>
            </span>
          </div>

          <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 text-center">
            <Bike className="w-6 h-6 text-teal-400 mx-auto mb-1.5" />
            <span className="text-xs text-slate-400 block">Cycling Saved</span>
            <span className="text-2xl font-black text-white block mt-0.5">
              {stats.activityEquivalents.cyclingMinutes} <span className="text-xs font-normal text-slate-400">minutes</span>
            </span>
          </div>
        </div>
      </div>

      {/* Visual Analytics Grid: Timeline Bar Chart & Category Donut */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Timeline Chart */}
        <div className="lg:col-span-2 glass-card rounded-2xl p-5 border border-slate-800">
          <div className="mb-4">
            <h4 className="text-sm font-bold text-white">Daily Calorie Savings Progression</h4>
            <p className="text-xs text-slate-400">Cumulative energy spared per day</p>
          </div>
          <div className="h-64 flex items-center justify-center">
            <Bar
              data={timelineChartData}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                  legend: { labels: { color: '#cbd5e1', font: { size: 11 } } }
                },
                scales: {
                  x: { ticks: { color: '#94a3b8' }, grid: { color: 'rgba(255,255,255,0.05)' } },
                  y: { ticks: { color: '#94a3b8' }, grid: { color: 'rgba(255,255,255,0.05)' } }
                }
              }}
            />
          </div>
        </div>

        {/* Category Donut */}
        <div className="glass-card rounded-2xl p-5 border border-slate-800 flex flex-col justify-between">
          <div className="mb-2">
            <h4 className="text-sm font-bold text-white">Swaps by Food Category</h4>
            <p className="text-xs text-slate-400">Distribution of snacks upgraded</p>
          </div>
          <div className="h-56 flex items-center justify-center">
            <Doughnut
              data={donutChartData}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                  legend: { position: 'bottom', labels: { color: '#cbd5e1', font: { size: 10 } } }
                }
              }}
            />
          </div>
        </div>
      </div>

      {/* Recent Swaps List */}
      <div className="glass-card rounded-2xl overflow-hidden border border-slate-800">
        <div className="p-4 border-b border-slate-800 bg-slate-900/60 flex items-center justify-between">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider">
            Recent Swaps
          </h3>
          <Link to="/my-swaps" className="text-xs text-emerald-400 hover:underline">
            View All ({stats.totalSwaps})
          </Link>
        </div>

        <div className="divide-y divide-slate-800/60">
          {recentSwaps.map((swap) => (
            <div key={swap.logId} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-900/40 transition-colors">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 rounded-lg bg-emerald-500/15 text-emerald-400 flex items-center justify-center font-bold shrink-0">
                  <CheckCircle2 className="w-4 h-4" />
                </div>
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="text-sm font-bold text-rose-300">{swap.origName}</span>
                    <ArrowRight className="w-3.5 h-3.5 text-slate-500" />
                    <span className="text-sm font-bold text-emerald-400">{swap.altName}</span>
                  </div>
                  <span className="text-[11px] text-slate-400">
                    Portion: {swap.quantityGrams}g · Logged on {new Date(swap.timestamp).toLocaleDateString()}
                  </span>
                </div>
              </div>

              <div className="flex items-center space-x-2 text-xs">
                <span className="px-2 py-0.5 bg-amber-500/10 text-amber-300 border border-amber-500/30 rounded-md font-bold">
                  -{swap.caloriesSaved} kcal
                </span>
                <span className="px-2 py-0.5 bg-rose-500/10 text-rose-300 border border-rose-500/30 rounded-md font-bold">
                  -{swap.sugarSaved}g sugar
                </span>
                <span className="px-2 py-0.5 bg-teal-500/10 text-teal-300 border border-teal-500/30 rounded-md font-bold">
                  -{swap.sodiumSaved}mg Na
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

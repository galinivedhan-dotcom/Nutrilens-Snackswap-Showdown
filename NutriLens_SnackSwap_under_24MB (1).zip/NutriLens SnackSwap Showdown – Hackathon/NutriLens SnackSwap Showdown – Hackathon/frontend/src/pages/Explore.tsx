import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Snack } from '../types/snack';
import { fetchAllSnacks } from '../services/api';
import { SnackCard } from '../components/SnackCard';
import { Search, Filter, Sparkles, AlertCircle, Home, ArrowUpDown, RefreshCw } from 'lucide-react';

export const Explore: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const initialQuery = searchParams.get('q') || '';

  const [snacks, setSnacks] = useState<Snack[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState(initialQuery);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [filterType, setFilterType] = useState<'all' | 'junk' | 'healthy' | 'hostel'>('all');
  const [sortBy, setSortBy] = useState<'default' | 'grade-asc' | 'grade-desc' | 'calories' | 'protein' | 'price'>('default');

  const categories = [
    'All',
    'Chips & Crisps',
    'Street Food & Fried',
    'Beverages',
    'Biscuits & Bakery',
    'Noodles & Quick Bites',
    'Chocolates & Sweets',
    'Dairy & Shakes',
    'Breakfast & Cereals'
  ];

  const loadSnacks = async () => {
    setLoading(true);
    try {
      const data = await fetchAllSnacks();
      setSnacks(data);
    } catch (err) {
      console.error('Failed to load snacks:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadSnacks();
  }, []);

  // Filter & Sort logic
  const filteredSnacks = snacks.filter((s) => {
    // Search matching
    const q = searchTerm.toLowerCase().trim();
    const matchSearch =
      !q ||
      s.name.toLowerCase().includes(q) ||
      s.description.toLowerCase().includes(q) ||
      s.tasteTexture.toLowerCase().includes(q) ||
      s.category.toLowerCase().includes(q);

    // Category matching
    const matchCat = selectedCategory === 'All' || s.category === selectedCategory;

    // Type filter
    let matchType = true;
    if (filterType === 'junk') matchType = !s.isHealthyAlternative;
    if (filterType === 'healthy') matchType = s.isHealthyAlternative;
    if (filterType === 'hostel') matchType = Boolean(s.hostelFriendly);

    return matchSearch && matchCat && matchType;
  });

  const sortedSnacks = [...filteredSnacks].sort((a, b) => {
    const gradeWeight: Record<string, number> = { A: 1, B: 2, C: 3, D: 4, E: 5 };
    if (sortBy === 'grade-asc') return (gradeWeight[a.healthGrade] || 3) - (gradeWeight[b.healthGrade] || 3);
    if (sortBy === 'grade-desc') return (gradeWeight[b.healthGrade] || 3) - (gradeWeight[a.healthGrade] || 3);
    if (sortBy === 'calories') return a.nutrition.calories - b.nutrition.calories;
    if (sortBy === 'protein') return b.nutrition.protein - a.nutrition.protein;
    if (sortBy === 'price') return a.priceINR - b.priceINR;
    return a.id - b.id;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 pb-6 border-b border-slate-800">
        <div>
          <div className="flex items-center space-x-2">
            <span className="text-xs uppercase font-extrabold tracking-widest text-emerald-400">
              Module 2: Snack Nutrition Lookup
            </span>
            <span className="text-xs bg-slate-800 text-slate-300 px-2 py-0.5 rounded-full border border-slate-700">
              40 Verified Records
            </span>
          </div>
          <h1 className="text-3xl font-extrabold text-white mt-1">Explore Snacks & Swaps</h1>
          <p className="text-sm text-slate-400 mt-1 max-w-xl">
            Compare 20 commonly consumed Indian student snacks with 20 nutrient-dense alternatives.
          </p>
        </div>

        {/* Quick Type Filter Tabs */}
        <div className="flex items-center space-x-1 bg-slate-900 p-1.5 rounded-xl border border-slate-800 self-start md:self-auto">
          <button
            onClick={() => setFilterType('all')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
              filterType === 'all'
                ? 'bg-emerald-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            All (40)
          </button>
          <button
            onClick={() => setFilterType('junk')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
              filterType === 'junk'
                ? 'bg-rose-500 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Junk / Craving (20)
          </button>
          <button
            onClick={() => setFilterType('healthy')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
              filterType === 'healthy'
                ? 'bg-emerald-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Healthier Swaps (20)
          </button>
          <button
            onClick={() => setFilterType('hostel')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
              filterType === 'hostel'
                ? 'bg-amber-400 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Hostel Hacks
          </button>
        </div>
      </div>

      {/* Search & Category Filter Controls */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row items-center gap-3">
          {/* Search Box */}
          <div className="relative flex-1 w-full">
            <Search className="w-5 h-5 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              placeholder="Search by snack name, taste (crispy, spicy, sweet), or category..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-11 pr-4 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
            />
            {searchTerm && (
              <button
                onClick={() => setSearchTerm('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-500 hover:text-white"
              >
                Clear
              </button>
            )}
          </div>

          {/* Sort selector */}
          <div className="flex items-center space-x-2 w-full sm:w-auto">
            <ArrowUpDown className="w-4 h-4 text-slate-400 shrink-0" />
            <select
              value={sortBy}
              onChange={(e: any) => setSortBy(e.target.value)}
              className="bg-slate-900 border border-slate-800 rounded-xl px-3 py-2.5 text-xs font-semibold text-slate-200 focus:outline-none focus:border-emerald-500 cursor-pointer"
            >
              <option value="default">Default Order</option>
              <option value="grade-asc">Health Grade: Best First (A → E)</option>
              <option value="grade-desc">Health Grade: Worst First (E → A)</option>
              <option value="calories">Lowest Calories</option>
              <option value="protein">Highest Protein</option>
              <option value="price">Lowest Price (₹)</option>
            </select>
          </div>
        </div>

        {/* Category Pill Scroll */}
        <div className="flex items-center space-x-2 overflow-x-auto pb-2 scrollbar-none">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                selectedCategory === cat
                  ? 'bg-emerald-500 text-slate-950 font-bold shadow-sm'
                  : 'bg-slate-900/80 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Results Count & Status */}
      <div className="flex items-center justify-between text-xs text-slate-400">
        <span>Showing <strong className="text-white">{sortedSnacks.length}</strong> snacks</span>
        {(searchTerm || selectedCategory !== 'All' || filterType !== 'all') && (
          <button
            onClick={() => {
              setSearchTerm('');
              setSelectedCategory('All');
              setFilterType('all');
            }}
            className="text-emerald-400 hover:underline flex items-center space-x-1"
          >
            <RefreshCw className="w-3 h-3" />
            <span>Reset Filters</span>
          </button>
        )}
      </div>

      {/* Snacks Grid */}
      {loading ? (
        <div className="py-24 text-center">
          <div className="w-10 h-10 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
          <p className="text-sm text-slate-400">Loading 40-snack nutrition database...</p>
        </div>
      ) : sortedSnacks.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {sortedSnacks.map((snack) => (
            <SnackCard key={snack.id} snack={snack} />
          ))}
        </div>
      ) : (
        <div className="py-20 text-center glass-card rounded-2xl p-8 border border-slate-800">
          <AlertCircle className="w-12 h-12 text-slate-500 mx-auto mb-3" />
          <h3 className="text-lg font-bold text-white">No snacks found</h3>
          <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
            Try adjusting your search query or reset the filters to see all 40 snacks.
          </p>
        </div>
      )}
    </div>
  );
};

import React, { useState, useRef, useEffect } from 'react';
import { lookupBarcodeApi } from '../services/api';
import { HealthGradeBadge } from '../components/HealthGradeBadge';
import { Recommendation } from '../types/snack';
import { 
  ScanLine, 
  Camera, 
  CameraOff, 
  Sparkles, 
  Check, 
  AlertTriangle, 
  Scale, 
  ArrowRight,
  Barcode as BarcodeIcon,
  RefreshCw
} from 'lucide-react';
import { Link } from 'react-router-dom';

export const Scanner: React.FC = () => {
  const [barcodeInput, setBarcodeInput] = useState('8901491101837');
  const [loading, setLoading] = useState(false);
  const [cameraActive, setCameraActive] = useState(false);
  const [scanResult, setScanResult] = useState<any | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);

  const sampleBarcodes = [
    { label: "Lay's Magic Masala", code: '8901491101837', tag: 'Chips' },
    { label: 'Kurkure Masala Munch', code: '8901491000628', tag: 'Namkeen' },
    { label: 'Oreo Cream Biscuits', code: '7622210886638', tag: 'Biscuits' },
    { label: 'Coca-Cola Can', code: '5449000000996', tag: 'Soda' },
    { label: 'Maggi 2-Min Noodles', code: '8901058852329', tag: 'Noodles' }
  ];

  const handleScan = async (codeToLookup?: string) => {
    const code = codeToLookup || barcodeInput;
    if (!code.trim()) return;

    setLoading(true);
    setErrorMsg(null);
    try {
      const data = await lookupBarcodeApi(code.trim());
      setScanResult(data);
    } catch (err: any) {
      console.error(err);
      setErrorMsg('Failed to lookup barcode. Please verify the code or select a sample.');
    } finally {
      setLoading(false);
    }
  };

  // Toggle Camera
  const toggleCamera = async () => {
    if (cameraActive) {
      // Stop camera
      if (mediaStreamRef.current) {
        mediaStreamRef.current.getTracks().forEach(t => t.stop());
        mediaStreamRef.current = null;
      }
      setCameraActive(false);
    } else {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'environment' }
        });
        mediaStreamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
        setCameraActive(true);
      } catch (err) {
        console.warn('Camera access denied or unavailable:', err);
        setErrorMsg('Camera access unavailable. You can use manual entry or 1-click test samples below.');
      }
    }
  };

  useEffect(() => {
    // Initial demo lookup on mount so the user sees immediate results
    handleScan('8901491101837');

    return () => {
      if (mediaStreamRef.current) {
        mediaStreamRef.current.getTracks().forEach(t => t.stop());
      }
    };
  }, []);

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center space-x-2">
            <span className="text-xs uppercase font-extrabold tracking-widest text-emerald-400">
              Module 8: Barcode Scanner
            </span>
            <span className="text-xs bg-emerald-500/10 text-emerald-300 px-2 py-0.5 rounded-full border border-emerald-500/30">
              Open Food Facts API Live
            </span>
          </div>
          <h1 className="text-3xl font-extrabold text-white mt-1">Scan Any Packaged Snack</h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-xl">
            Scan any packaged food barcode with your camera or lookup EAN codes to instantly decode nutrition and get healthy swaps.
          </p>
        </div>

        <button
          onClick={toggleCamera}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 shadow-md ${
            cameraActive
              ? 'bg-rose-600 text-white hover:bg-rose-500'
              : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950'
          }`}
        >
          {cameraActive ? (
            <>
              <CameraOff className="w-4 h-4" />
              <span>Turn Off Camera</span>
            </>
          ) : (
            <>
              <Camera className="w-4 h-4" />
              <span>Start Camera Scanner</span>
            </>
          )}
        </button>
      </div>

      {/* Camera Viewfinder */}
      {cameraActive && (
        <div className="relative max-w-md mx-auto aspect-video rounded-3xl overflow-hidden bg-black border-2 border-emerald-500/60 shadow-2xl">
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            {/* Viewfinder Target */}
            <div className="w-64 h-32 border-2 border-emerald-400 rounded-xl relative shadow-[0_0_20px_rgba(16,185,129,0.5)]">
              <div className="absolute top-0 left-0 w-full h-0.5 bg-emerald-400 animate-pulse" />
              <span className="absolute -bottom-6 left-1/2 -translate-x-1/2 text-[10px] font-bold text-emerald-300 whitespace-nowrap bg-black/60 px-2 py-0.5 rounded">
                Align barcode within box
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Manual Input & 1-Click Samples */}
      <div className="glass-card rounded-2xl p-6 border border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row items-center gap-3">
          <div className="relative flex-1 w-full">
            <BarcodeIcon className="w-5 h-5 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              placeholder="Enter 13-digit EAN Barcode (e.g. 8901491101837)..."
              value={barcodeInput}
              onChange={(e) => setBarcodeInput(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-xl pl-11 pr-4 py-3 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
            />
          </div>

          <button
            onClick={() => handleScan()}
            disabled={loading}
            className="w-full sm:w-auto px-6 py-3 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-xl text-sm transition-all shadow-md flex items-center justify-center space-x-1.5"
          >
            {loading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <ScanLine className="w-4 h-4" />}
            <span>{loading ? 'Searching API...' : 'Scan Product'}</span>
          </button>
        </div>

        {/* 1-Click Samples Bar */}
        <div>
          <span className="text-xs font-semibold text-slate-400 block mb-2">
            ⚡ Quick-Test Verified Barcodes (1-Click Demo):
          </span>
          <div className="flex flex-wrap gap-2">
            {sampleBarcodes.map((item) => (
              <button
                key={item.code}
                onClick={() => {
                  setBarcodeInput(item.code);
                  handleScan(item.code);
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-all flex items-center space-x-1.5 ${
                  barcodeInput === item.code
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 font-bold'
                    : 'bg-slate-900 text-slate-300 hover:bg-slate-800 border-slate-700/80'
                }`}
              >
                <span>{item.label}</span>
                <span className="text-[10px] text-slate-500 font-mono">({item.tag})</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {errorMsg && (
        <div className="p-4 bg-rose-500/15 border border-rose-500/30 rounded-xl text-xs text-rose-300 flex items-center space-x-2">
          <AlertTriangle className="w-4 h-4 shrink-0 text-rose-400" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* Scanned Results Showcase */}
      {scanResult && (
        <div className="space-y-6">
          <div className="glass-card rounded-3xl p-6 md:p-8 border border-slate-800">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div className="flex items-center space-x-2">
                <span className="text-xs uppercase font-extrabold tracking-wider text-emerald-400">
                  Scanned Product Profile
                </span>
                <span className="text-xs bg-slate-800 text-slate-400 px-2 py-0.5 rounded border border-slate-700">
                  Source: {scanResult.source}
                </span>
              </div>
              <span className="text-xs font-mono text-slate-400">Barcode: {scanResult.scannedProduct.barcode}</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center mt-6">
              <div className="md:col-span-4 h-56 rounded-2xl overflow-hidden bg-slate-900 border border-slate-800">
                <img
                  src={scanResult.scannedProduct.image}
                  alt={scanResult.scannedProduct.name}
                  className="w-full h-full object-cover"
                />
              </div>

              <div className="md:col-span-8 space-y-3">
                <div className="flex items-center space-x-2">
                  <span className="text-xs font-bold bg-slate-800 text-slate-300 px-2.5 py-0.5 rounded-full border border-slate-700">
                    {scanResult.scannedProduct.brand || scanResult.scannedProduct.category}
                  </span>
                  <span className="text-xs text-slate-400">
                    Serving: {scanResult.scannedProduct.servingSizeDescription || '50g'}
                  </span>
                </div>

                <h2 className="text-2xl font-bold text-white">{scanResult.scannedProduct.name}</h2>

                {/* Health Grade pill */}
                <div className="flex items-center space-x-3 p-3 bg-slate-900/80 rounded-xl border border-slate-800">
                  <HealthGradeBadge
                    grade={scanResult.scannedProduct.healthGrade}
                    score={scanResult.scannedProduct.healthScore}
                    size="md"
                    showDetails
                  />
                  <div className="border-l border-slate-800 pl-3">
                    <span className="text-xs font-bold text-white block">
                      {scanResult.scannedProduct.gradeMeaning}
                    </span>
                    <span className="text-[11px] text-slate-400">
                      Nutri-Score: {scanResult.scannedProduct.healthScore} points
                    </span>
                  </div>
                </div>

                {/* Nutrition Highlights Grid */}
                <div className="grid grid-cols-4 gap-2 text-center text-xs bg-slate-900/60 p-3 rounded-xl border border-slate-800">
                  <div>
                    <span className="text-slate-400 text-[10px] block">Energy</span>
                    <span className="font-extrabold text-amber-400">{scanResult.scannedProduct.nutrition.calories} kcal</span>
                  </div>
                  <div>
                    <span className="text-slate-400 text-[10px] block">Sat. Fat</span>
                    <span className="font-extrabold text-rose-400">{scanResult.scannedProduct.nutrition.saturatedFat}g</span>
                  </div>
                  <div>
                    <span className="text-slate-400 text-[10px] block">Sugar</span>
                    <span className="font-extrabold text-rose-400">{scanResult.scannedProduct.nutrition.sugar}g</span>
                  </div>
                  <div>
                    <span className="text-slate-400 text-[10px] block">Sodium</span>
                    <span className="font-extrabold text-rose-400">{scanResult.scannedProduct.nutrition.sodium}mg</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Recommended Swaps for this scanned product */}
          <div>
            <div className="mb-4">
              <h3 className="text-xl font-bold text-white flex items-center space-x-2">
                <Sparkles className="w-5 h-5 text-emerald-400" />
                <span>Smart Healthy Swaps for this Product</span>
              </h3>
              <p className="text-xs text-slate-400">
                NutriLens algorithm analyzed this scanned barcode and found 3 superior alternatives.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {scanResult.recommendedSwaps.map((rec: Recommendation, idx: number) => {
                const alt = rec.snack;
                return (
                  <div key={alt.id} className="glass-card rounded-2xl p-4 border border-slate-800 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-[10px] font-black uppercase text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/30">
                          #{idx + 1} Best Match
                        </span>
                        <HealthGradeBadge grade={alt.healthGrade} score={alt.healthScore} size="sm" />
                      </div>

                      <div className="flex items-center space-x-3 mb-2">
                        <img
                          src={alt.image}
                          alt={alt.name}
                          className="w-14 h-14 rounded-xl object-cover border border-slate-700"
                        />
                        <div>
                          <h4 className="text-sm font-bold text-white line-clamp-1">{alt.name}</h4>
                          <span className="text-xs text-emerald-400 font-bold">₹{alt.priceINR}</span>
                          <span className="text-[10px] text-slate-400 block">{alt.tasteTexture}</span>
                        </div>
                      </div>

                      <p className="text-xs text-slate-300 bg-slate-900/60 p-2.5 rounded-lg border border-slate-800 line-clamp-2">
                        {rec.whySuggested}
                      </p>
                    </div>

                    <Link
                      to={`/compare/1/${alt.id}`}
                      className="mt-3 w-full py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-xl text-xs text-center transition-all flex items-center justify-center space-x-1"
                    >
                      <span>Compare Side-by-Side</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </Link>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { Snack } from '../types/snack';
import { fetchSnackById } from '../services/api';
import { NutritionFactsCard } from '../components/NutritionFactsCard';
import { ExerciseCalculator } from '../components/ExerciseCalculator';
import { HealthGradeBadge } from '../components/HealthGradeBadge';
import { ArrowLeft, ArrowRight, Sparkles, Scale, Info, ShieldCheck, Home } from 'lucide-react';

export const SnackDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [snack, setSnack] = useState<Snack | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (id) {
      setLoading(true);
      fetchSnackById(id)
        .then(setSnack)
        .catch(err => console.error(err))
        .finally(() => setLoading(false));
    }
  }, [id]);

  if (loading) {
    return (
      <div className="py-24 text-center">
        <div className="w-10 h-10 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
        <p className="text-sm text-slate-400">Loading nutrition profile...</p>
      </div>
    );
  }

  if (!snack) {
    return (
      <div className="max-w-xl mx-auto py-20 text-center">
        <h2 className="text-xl font-bold text-white">Snack not found</h2>
        <Link to="/explore" className="text-emerald-400 hover:underline mt-3 inline-block text-sm">
          Return to Explore
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Back button */}
      <div>
        <button
          onClick={() => navigate(-1)}
          className="inline-flex items-center space-x-1.5 text-xs font-semibold text-slate-400 hover:text-white transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Snacks</span>
        </button>
      </div>

      {/* Hero Overview Card */}
      <div className="glass-card rounded-3xl p-6 md:p-8 border border-slate-800">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
          {/* Image */}
          <div className="md:col-span-5 relative rounded-2xl overflow-hidden h-64 md:h-80 bg-slate-900 border border-slate-700/60 shadow-xl">
            <img
              src={snack.image}
              alt={snack.name}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
            <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between">
              <span className="text-xs font-black bg-slate-950/90 text-emerald-400 px-3 py-1 rounded-lg border border-emerald-500/30">
                ₹{snack.priceINR}
              </span>
              <span className="text-xs text-slate-300 font-medium bg-black/70 px-2.5 py-1 rounded-lg backdrop-blur-sm">
                Serving: {snack.servingSizeDescription}
              </span>
            </div>
          </div>

          {/* Details & Grades */}
          <div className="md:col-span-7 space-y-4">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-bold text-slate-300 bg-slate-800 px-3 py-1 rounded-full border border-slate-700">
                {snack.category}
              </span>
              {snack.isHealthyAlternative ? (
                <span className="text-xs font-bold bg-emerald-500/20 text-emerald-300 px-3 py-1 rounded-full border border-emerald-500/30 flex items-center space-x-1">
                  <Sparkles className="w-3 h-3" />
                  <span>Healthy Alternative</span>
                </span>
              ) : (
                <span className="text-xs font-bold bg-rose-500/20 text-rose-300 px-3 py-1 rounded-full border border-rose-500/30">
                  Common Craving Food
                </span>
              )}
              {snack.hostelFriendly && (
                <span className="text-xs font-bold bg-amber-500/20 text-amber-300 px-3 py-1 rounded-full border border-amber-500/30 flex items-center space-x-1">
                  <Home className="w-3 h-3" />
                  <span>Hostel Friendly ({snack.prepTimeMinutes === 0 ? 'Ready to Eat' : `${snack.prepTimeMinutes} mins`})</span>
                </span>
              )}
            </div>

            <h1 className="text-3xl sm:text-4xl font-extrabold text-white">{snack.name}</h1>
            <p className="text-sm text-slate-300 leading-relaxed">{snack.description}</p>

            {/* Taste & texture notes */}
            <div className="p-3.5 bg-slate-900/60 rounded-xl border border-slate-800 text-xs space-y-1">
              <div>
                <span className="text-slate-400">Taste & Texture Profile: </span>
                <strong className="text-emerald-300">{snack.tasteTexture}</strong>
              </div>
              {snack.flavorNotes && (
                <div>
                  <span className="text-slate-400">Flavor Profile: </span>
                  <span className="text-slate-200">{snack.flavorNotes}</span>
                </div>
              )}
              <div>
                <span className="text-slate-400">Preparation Method: </span>
                <span className="text-slate-200">{snack.preparationMethod}</span>
              </div>
            </div>

            {/* Health Grade Showcase */}
            <div className="pt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-slate-900/80 rounded-2xl border border-slate-800">
              <div>
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                  NutriLens Health Rating
                </span>
                <span className="text-sm font-bold text-white mt-0.5 block">
                  {snack.gradeMeaning}
                </span>
              </div>
              <HealthGradeBadge grade={snack.healthGrade} score={snack.healthScore} size="lg" showDetails />
            </div>

            {/* Direct CTA */}
            <div className="pt-3 flex flex-wrap gap-3">
              {!snack.isHealthyAlternative ? (
                <Link
                  to={`/recommendations/${snack.id}`}
                  className="px-6 py-3 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold rounded-xl text-sm transition-all shadow-lg flex items-center space-x-2"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>Find Healthy Alternatives</span>
                  <ArrowRight className="w-4 h-4" />
                </Link>
              ) : (
                <Link
                  to={`/compare/1/${snack.id}`}
                  className="px-6 py-3 bg-teal-600 hover:bg-teal-500 text-white font-bold rounded-xl text-sm transition-all shadow-lg flex items-center space-x-2"
                >
                  <Scale className="w-4 h-4" />
                  <span>Compare with Potato Chips</span>
                </Link>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Module 2 & 3: Interactive Nutrition Facts Card */}
      <NutritionFactsCard snack={snack} />

      {/* Module 6: Exercise Energy Equivalency */}
      <ExerciseCalculator
        calories={snack.nutrition.calories}
        snackName={snack.name}
      />
    </div>
  );
};

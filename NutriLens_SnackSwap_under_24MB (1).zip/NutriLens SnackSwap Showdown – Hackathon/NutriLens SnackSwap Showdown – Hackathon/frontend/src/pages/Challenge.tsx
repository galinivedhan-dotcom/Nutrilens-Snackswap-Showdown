import React, { useState, useEffect } from 'react';
import { ChallengeDay } from '../types/snack';
import { fetchWeeklyChallenge, toggleChallengeDayApi } from '../services/api';
import confetti from 'canvas-confetti';
import { 
  Trophy, 
  Sparkles, 
  Check, 
  Award, 
  Zap, 
  Droplet, 
  Shield, 
  Home, 
  Heart, 
  Activity,
  Flame,
  CheckCircle2,
  Lock
} from 'lucide-react';
import { Link } from 'react-router-dom';

export const Challenge: React.FC = () => {
  const [challenge, setChallenge] = useState<{
    challengeTitle: string;
    subtitle: string;
    progress: { completedDays: number; totalDays: number; percentage: number; streakDays: number };
    days: ChallengeDay[];
    badges: any[];
  } | null>(null);
  const [loading, setLoading] = useState(true);
  const [updatingDay, setUpdatingDay] = useState<number | null>(null);
  const [unlockedNotice, setUnlockedNotice] = useState<string | null>(null);

  const loadChallenge = () => {
    fetchWeeklyChallenge()
      .then(setChallenge)
      .catch(console.error)
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    loadChallenge();
  }, []);

  const handleToggle = async (dayNumber: number) => {
    setUpdatingDay(dayNumber);
    try {
      const res = await toggleChallengeDayApi(dayNumber);
      if (res.isCompleted) {
        // Fire celebration confetti!
        confetti({
          particleCount: 90,
          spread: 70,
          origin: { y: 0.6 }
        });
        setUnlockedNotice(`🎉 Unlocked Badge: ${res.badgeUnlocked}!`);
        setTimeout(() => setUnlockedNotice(null), 4000);
      }
      loadChallenge();
    } catch (err) {
      console.error(err);
    } finally {
      setUpdatingDay(null);
    }
  };

  const getBadgeIcon = (iconName: string) => {
    switch (iconName) {
      case 'zap': return Zap;
      case 'droplet': return Droplet;
      case 'shield': return Shield;
      case 'home': return Home;
      case 'heart': return Heart;
      case 'activity': return Activity;
      default: return Award;
    }
  };

  if (loading) {
    return (
      <div className="py-24 text-center">
        <div className="w-10 h-10 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
        <p className="text-sm text-slate-400">Loading 7-Day SnackSwap Challenge...</p>
      </div>
    );
  }

  if (!challenge) return null;

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Page Header */}
      <div className="glass-card rounded-3xl p-6 md:p-8 border border-emerald-500/30 bg-gradient-to-r from-emerald-950/30 via-slate-900 to-teal-950/30">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-2 text-center md:text-left">
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold">
              <Trophy className="w-3.5 h-3.5" />
              <span>Module 10: Gamified Habits</span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-black text-white">{challenge.challengeTitle}</h1>
            <p className="text-xs sm:text-sm text-slate-300 max-w-xl">
              {challenge.subtitle}
            </p>
          </div>

          {/* Streak & Progress Pill */}
          <div className="bg-slate-950/80 p-5 rounded-2xl border border-slate-800 text-center min-w-[200px] shadow-xl">
            <span className="text-xs text-slate-400 font-semibold block">Active Swapping Streak</span>
            <div className="flex items-center justify-center space-x-1.5 my-1">
              <Flame className="w-6 h-6 text-orange-400 fill-orange-400 animate-pulse" />
              <span className="text-3xl font-black text-white">{challenge.progress.streakDays}</span>
              <span className="text-xs font-bold text-slate-400">/ 7 Days</span>
            </div>
            <span className="text-[11px] text-emerald-400 font-bold block">
              {challenge.progress.percentage}% Completed
            </span>
          </div>
        </div>

        {/* Overall Progress Bar */}
        <div className="mt-6 pt-4 border-t border-slate-800/80">
          <div className="w-full bg-slate-950 h-3 rounded-full overflow-hidden p-0.5 border border-slate-800">
            <div
              className="bg-gradient-to-r from-emerald-500 via-teal-400 to-lime-400 h-full rounded-full transition-all duration-500"
              style={{ width: `${challenge.progress.percentage}%` }}
            />
          </div>
        </div>
      </div>

      {/* Unlocked Notice Banner */}
      {unlockedNotice && (
        <div className="p-4 bg-emerald-500/20 border border-emerald-500/40 rounded-2xl flex items-center space-x-3 text-emerald-300 text-sm font-bold shadow-lg animate-bounce">
          <Award className="w-6 h-6 text-emerald-400" />
          <span>{unlockedNotice}</span>
        </div>
      )}

      {/* Badges Showcase Section */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-lg font-bold text-white flex items-center space-x-2">
              <Award className="w-5 h-5 text-emerald-400" />
              <span>Achievement Badges Showcase</span>
            </h3>
            <p className="text-xs text-slate-400">Unlock badges by checking in on each daily swap mission.</p>
          </div>
          <span className="text-xs text-emerald-400 font-bold">
            {challenge.badges.filter(b => b.unlocked).length} / 7 Unlocked
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
          {challenge.badges.map((b) => {
            const Icon = getBadgeIcon(b.badgeIcon);
            return (
              <div
                key={b.dayNumber}
                className={`p-3.5 rounded-2xl text-center border transition-all ${
                  b.unlocked
                    ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-300 shadow-lg shadow-emerald-500/10 scale-105'
                    : 'bg-slate-900/60 border-slate-800 text-slate-500 opacity-60'
                }`}
              >
                <div
                  className={`w-12 h-12 mx-auto rounded-xl flex items-center justify-center mb-2 ${
                    b.unlocked
                      ? 'bg-gradient-to-tr from-emerald-500 to-teal-400 text-slate-950 shadow-md'
                      : 'bg-slate-800 text-slate-600'
                  }`}
                >
                  {b.unlocked ? <Icon className="w-6 h-6" /> : <Lock className="w-5 h-5" />}
                </div>
                <span className="text-[11px] font-black block line-clamp-1">{b.badgeName}</span>
                <span className="text-[10px] text-slate-400 block mt-0.5">Day {b.dayNumber}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* 7-Day Checklist Timeline */}
      <div className="space-y-4">
        <div>
          <h3 className="text-lg font-bold text-white">Daily Snack Swap Missions</h3>
          <p className="text-xs text-slate-400">Follow the path and conquer unhealthy snacking step by step.</p>
        </div>

        <div className="space-y-3">
          {challenge.days.map((day) => {
            const Icon = getBadgeIcon(day.badgeIcon);
            return (
              <div
                key={day.dayNumber}
                className={`glass-card rounded-2xl p-4 sm:p-5 border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
                  day.isCompleted
                    ? 'border-emerald-500/40 bg-emerald-950/15'
                    : 'border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-start sm:items-center space-x-4">
                  <div
                    className={`w-11 h-11 rounded-xl flex items-center justify-center font-black shrink-0 ${
                      day.isCompleted
                        ? 'bg-emerald-500 text-slate-950 shadow-md'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {day.isCompleted ? <Check className="w-6 h-6" /> : <span className="text-sm font-mono">{day.dayNumber}</span>}
                  </div>

                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider">
                        Day {day.dayNumber} · {day.targetSwapCategory}
                      </span>
                      <span className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded-full border border-slate-700">
                        {day.badgeName}
                      </span>
                    </div>
                    <h4 className="text-base font-bold text-white mt-0.5">{day.title}</h4>
                    <p className="text-xs text-slate-400 mt-1 max-w-xl">{day.description}</p>
                  </div>
                </div>

                <div className="flex items-center space-x-3 self-end sm:self-auto">
                  <Link
                    to="/explore"
                    className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-semibold"
                  >
                    Find Swap
                  </Link>

                  <button
                    onClick={() => handleToggle(day.dayNumber)}
                    disabled={updatingDay === day.dayNumber}
                    className={`px-4 py-2 rounded-xl text-xs font-black transition-all flex items-center space-x-1.5 ${
                      day.isCompleted
                        ? 'bg-slate-800 text-emerald-400 border border-emerald-500/30 hover:bg-slate-700'
                        : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-md'
                    }`}
                  >
                    {day.isCompleted ? (
                      <>
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        <span>Completed</span>
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-4 h-4" />
                        <span>Check In Swap</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { SwapLogItem } from '../types/snack';
import { fetchSwapHistory } from '../services/api';
import { HealthGradeBadge } from '../components/HealthGradeBadge';
import { History, ArrowRight, ArrowLeft, Sparkles, Flame, Droplet, ShieldCheck, Calendar } from 'lucide-react';

export const MySwaps: React.FC = () => {
  const [history, setHistory] = useState<SwapLogItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchSwapHistory()
      .then(setHistory)
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="py-24 text-center">
        <div className="w-10 h-10 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
        <p className="text-sm text-slate-400">Loading swap history logs...</p>
      </div>
    );
  }

  const totalCalories = Math.round(history.reduce((acc, h) => acc + (h.caloriesSaved || 0), 0) * 10) / 10;
  const totalSugar = Math.round(history.reduce((acc, h) => acc + (h.sugarSaved || 0), 0) * 10) / 10;
  const totalSodium = Math.round(history.reduce((acc, h) => acc + (h.sodiumSaved || 0), 0));

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center space-x-2">
            <Link to="/dashboard" className="text-xs text-slate-400 hover:text-white flex items-center space-x-1">
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back to Dashboard</span>
            </Link>
          </div>
          <h1 className="text-3xl font-extrabold text-white mt-1">My Swap Log History</h1>
          <p className="text-xs text-slate-400 mt-1">
            Every conscious food upgrade recorded in your personal NutriLens journey.
          </p>
        </div>

        <Link
          to="/explore"
          className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-black rounded-xl shadow-md transition-all flex items-center space-x-1.5 self-start sm:self-auto"
        >
          <Sparkles className="w-4 h-4" />
          <span>Log Another Swap</span>
        </Link>
      </div>

      {/* Aggregate Stats Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="glass-card rounded-2xl p-4 border border-slate-800 flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/15 text-amber-400 flex items-center justify-center font-bold">
            <Flame className="w-5 h-5" />
          </div>
          <div>
            <span className="text-xs text-slate-400 block">Total Energy Spared</span>
            <span className="text-xl font-black text-amber-400">{totalCalories} kcal</span>
          </div>
        </div>

        <div className="glass-card rounded-2xl p-4 border border-slate-800 flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-rose-500/15 text-rose-400 flex items-center justify-center font-bold">
            <Droplet className="w-5 h-5" />
          </div>
          <div>
            <span className="text-xs text-slate-400 block">Refined Sugar Cut</span>
            <span className="text-xl font-black text-rose-400">{totalSugar} g</span>
          </div>
        </div>

        <div className="glass-card rounded-2xl p-4 border border-slate-800 flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-teal-500/15 text-teal-400 flex items-center justify-center font-bold">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <span className="text-xs text-slate-400 block">Excess Sodium Spared</span>
            <span className="text-xl font-black text-teal-400">{totalSodium} mg</span>
          </div>
        </div>
      </div>

      {/* History Table */}
      {history.length > 0 ? (
        <div className="glass-card rounded-2xl overflow-hidden border border-slate-800">
          <div className="p-4 border-b border-slate-800 bg-slate-900/60 flex items-center justify-between">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">
              Recorded Swaps ({history.length})
            </h3>
            <span className="text-xs text-slate-400">Stored locally in SQLite database</span>
          </div>

          <div className="divide-y divide-slate-800/60">
            {history.map((item) => (
              <div
                key={item.logId}
                className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-slate-900/40 transition-colors"
              >
                {/* Snack Pair */}
                <div className="flex items-center space-x-4">
                  <div className="w-9 h-9 rounded-xl bg-slate-800 flex items-center justify-center text-slate-400 shrink-0">
                    <Calendar className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="text-sm font-bold text-rose-300">{item.origName}</span>
                      <ArrowRight className="w-3.5 h-3.5 text-slate-500" />
                      <span className="text-sm font-bold text-emerald-400">{item.altName}</span>
                    </div>
                    <div className="flex items-center space-x-2 text-[11px] text-slate-400 mt-0.5">
                      <span>Portion: <strong>{item.quantityGrams}g</strong></span>
                      <span>•</span>
                      <span>{new Date(item.timestamp).toLocaleString()}</span>
                    </div>
                  </div>
                </div>

                {/* Savings Pills */}
                <div className="flex flex-wrap items-center gap-2 text-xs">
                  <span className="px-2.5 py-1 bg-amber-500/10 text-amber-300 border border-amber-500/30 rounded-lg font-bold">
                    -{item.caloriesSaved} kcal
                  </span>
                  <span className="px-2.5 py-1 bg-rose-500/10 text-rose-300 border border-rose-500/30 rounded-lg font-bold">
                    -{item.sugarSaved}g sugar
                  </span>
                  <span className="px-2.5 py-1 bg-teal-500/10 text-teal-300 border border-teal-500/30 rounded-lg font-bold">
                    -{item.sodiumSaved}mg Na
                  </span>
                  {item.proteinGained && item.proteinGained > 0 && (
                    <span className="px-2.5 py-1 bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 rounded-lg font-bold">
                      +{item.proteinGained}g protein
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div className="glass-card rounded-2xl p-12 text-center border border-slate-800">
          <History className="w-12 h-12 text-slate-500 mx-auto mb-3" />
          <h3 className="text-base font-bold text-white">No swaps logged yet</h3>
          <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
            Try searching for a snack like Potato Chips or Samosa and click "I Swapped This!" to record your first healthy upgrade.
          </p>
          <Link
            to="/explore"
            className="mt-4 inline-block px-5 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-xl text-xs transition-all"
          >
            Explore Snacks
          </Link>
        </div>
      )}
    </div>
  );
};

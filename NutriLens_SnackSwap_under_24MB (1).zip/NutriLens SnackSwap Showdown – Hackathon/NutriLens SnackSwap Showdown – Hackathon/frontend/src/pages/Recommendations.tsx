import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { Snack, Recommendation } from '../types/snack';
import { fetchAlternatives, logSnackSwap } from '../services/api';
import { HealthGradeBadge } from '../components/HealthGradeBadge';
import confetti from 'canvas-confetti';
import { 
  Sparkles, 
  ArrowRight, 
  ArrowLeft, 
  Scale, 
  Check, 
  Flame, 
  HeartHandshake, 
  IndianRupee,
  ShieldCheck,
  TrendingUp,
  AlertCircle
} from 'lucide-react';

export const Recommendations: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  const [originalSnack, setOriginalSnack] = useState<Snack | null>(null);
  const [recommendations, setRecommendations] = useState<Recommendation[]>([]);
  const [loading, setLoading] = useState(true);
  const [swappingId, setSwappingId] = useState<number | null>(null);
  const [swappedSuccess, setSwappedSuccess] = useState<string | null>(null);

  useEffect(() => {
    if (id) {
      setLoading(true);
      fetchAlternatives(id)
        .then((data) => {
          setOriginalSnack(data.originalSnack);
          setRecommendations(data.recommendations);
        })
        .catch(console.error)
        .finally(() => setLoading(false));
    }
  }, [id]);

  const handleQuickSwap = async (altSnack: Snack) => {
    if (!originalSnack) return;
    setSwappingId(altSnack.id);
    try {
      await logSnackSwap(originalSnack.id, altSnack.id, originalSnack.servingSizeGrams || 50);

      // Trigger Confetti!
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 }
      });

      setSwappedSuccess(`Swapped to ${altSnack.name}! Recorded to your dashboard.`);
      setTimeout(() => {
        setSwappedSuccess(null);
      }, 4000);
    } catch (err) {
      console.error('Swap failed:', err);
    } finally {
      setSwappingId(null);
    }
  };

  if (loading) {
    return (
      <div className="py-24 text-center">
        <div className="w-10 h-10 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
        <p className="text-sm text-slate-400">Finding taste & texture matched alternatives...</p>
      </div>
    );
  }

  if (!originalSnack) {
    return (
      <div className="max-w-xl mx-auto py-20 text-center">
        <h2 className="text-xl font-bold text-white">Original snack not found</h2>
        <Link to="/explore" className="text-emerald-400 hover:underline mt-3 inline-block text-sm">
          Return to Explore
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Navigation & Success Alert */}
      <div className="flex items-center justify-between">
        <button
          onClick={() => navigate(-1)}
          className="inline-flex items-center space-x-1.5 text-xs font-semibold text-slate-400 hover:text-white transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back</span>
        </button>
        <Link
          to="/dashboard"
          className="text-xs font-semibold text-emerald-400 hover:underline flex items-center space-x-1"
        >
          <span>View My Dashboard</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </Link>
      </div>

      {swappedSuccess && (
        <div className="p-4 bg-emerald-500/20 border border-emerald-500/40 rounded-2xl flex items-center justify-between text-emerald-300 text-sm font-bold shadow-lg animate-fade-in">
          <div className="flex items-center space-x-2">
            <Check className="w-5 h-5 text-emerald-400" />
            <span>{swappedSuccess}</span>
          </div>
          <Link to="/dashboard" className="text-xs bg-emerald-500 text-slate-950 px-3 py-1.5 rounded-lg hover:bg-emerald-400 font-extrabold">
            View Analytics
          </Link>
        </div>
      )}

      {/* Header Banner: Original Snack Craving */}
      <div className="glass-card rounded-2xl p-6 border border-slate-800 bg-gradient-to-r from-slate-900/90 via-slate-900/60 to-slate-950/80">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="flex items-center space-x-4">
            <img
              src={originalSnack.image}
              alt={originalSnack.name}
              className="w-20 h-20 rounded-2xl object-cover border border-slate-700 shadow-md"
            />
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider text-rose-400">
                You Selected Your Craving
              </span>
              <h2 className="text-2xl font-extrabold text-white">{originalSnack.name}</h2>
              <div className="flex items-center space-x-2 mt-1">
                <HealthGradeBadge grade={originalSnack.healthGrade} score={originalSnack.healthScore} size="sm" />
                <span className="text-xs text-slate-400">
                  {originalSnack.nutrition.calories} kcal · ₹{originalSnack.priceINR}
                </span>
                <span className="text-[11px] text-slate-500 bg-slate-800/80 px-2 py-0.5 rounded-md">
                  👅 {originalSnack.tasteTexture}
                </span>
              </div>
            </div>
          </div>

          <div className="text-right sm:border-l sm:border-slate-800 sm:pl-6">
            <span className="text-xs text-slate-400 block">Module 4 Intelligence</span>
            <span className="text-xs font-bold text-emerald-400 block mt-0.5">
              3 Taste & Texture Matches Found
            </span>
          </div>
        </div>
      </div>

      {/* Recommendations List */}
      <div className="space-y-6">
        <div>
          <h3 className="text-xl font-bold text-white flex items-center space-x-2">
            <Sparkles className="w-5 h-5 text-emerald-400" />
            <span>Recommended Healthy Alternatives</span>
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Ranked by Euclidean nutritional distance, sensory similarity, student budget, and hostel convenience.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {recommendations.map((rec, index) => {
            const alt = rec.snack;
            return (
              <div
                key={alt.id}
                className="glass-card glass-card-hover rounded-2xl overflow-hidden border border-slate-800 flex flex-col justify-between"
              >
                <div>
                  {/* Top Image & Match Pill */}
                  <div className="relative h-44 w-full bg-slate-900">
                    <img
                      src={alt.image}
                      alt={alt.name}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-black/30" />
                    
                    {/* Floating Grade */}
                    <div className="absolute top-2.5 right-2.5">
                      <HealthGradeBadge grade={alt.healthGrade} score={alt.healthScore} size="sm" />
                    </div>

                    {/* Rank Pill */}
                    <div className="absolute top-2.5 left-2.5">
                      <span className="text-[10px] font-black bg-emerald-500 text-slate-950 px-2 py-0.5 rounded-md shadow-md uppercase">
                        #{index + 1} Best Match
                      </span>
                    </div>

                    {/* Price comparison */}
                    <div className="absolute bottom-2.5 left-2.5 flex items-center space-x-1.5 text-xs font-bold">
                      <span className="bg-slate-950/90 text-emerald-400 px-2 py-0.5 rounded-md border border-emerald-500/30">
                        ₹{alt.priceINR}
                      </span>
                      {rec.priceComparisonINR === 0 ? (
                        <span className="bg-slate-900/80 text-slate-300 text-[10px] px-1.5 py-0.5 rounded">Same price</span>
                      ) : rec.priceComparisonINR < 0 ? (
                        <span className="bg-emerald-950/80 text-emerald-300 text-[10px] px-1.5 py-0.5 rounded">
                          ₹{Math.abs(rec.priceComparisonINR)} cheaper!
                        </span>
                      ) : (
                        <span className="bg-slate-900/80 text-slate-400 text-[10px] px-1.5 py-0.5 rounded">
                          +₹{rec.priceComparisonINR}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Body Content */}
                  <div className="p-4 space-y-3">
                    <div>
                      <h4 className="text-base font-bold text-white line-clamp-1">{alt.name}</h4>
                      <p className="text-xs text-slate-400 mt-1 line-clamp-2">{alt.description}</p>
                    </div>

                    {/* Why this alternative is suggested */}
                    <div className="p-2.5 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-xs text-emerald-300 leading-snug">
                      <strong className="text-white block mb-0.5 font-semibold">Why this swap?</strong>
                      {rec.whySuggested}
                    </div>

                    {/* Nutritional Perks Grid */}
                    <div className="grid grid-cols-3 gap-1.5 text-center bg-slate-900/60 p-2 rounded-xl border border-slate-800 text-xs">
                      <div>
                        <span className="text-[10px] text-slate-400 block">Calories Saved</span>
                        <span className="font-extrabold text-amber-400">
                          {rec.caloriesSavedPer100g > 0 ? `-${rec.caloriesSavedPer100g}` : rec.caloriesSavedPer100g}
                        </span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 block">Sat. Fat Cut</span>
                        <span className="font-extrabold text-emerald-400">
                          -{rec.satFatSavedPer100g}g
                        </span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 block">Protein Gain</span>
                        <span className="font-extrabold text-emerald-400">
                          +{rec.proteinGainedPer100g}g
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="p-4 pt-0 space-y-2">
                  <Link
                    to={`/compare/${originalSnack.id}/${alt.id}`}
                    className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold transition-all flex items-center justify-center space-x-1.5 border border-slate-700"
                  >
                    <Scale className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Compare Both Side-by-Side</span>
                  </Link>

                  <button
                    onClick={() => handleQuickSwap(alt)}
                    disabled={swappingId === alt.id}
                    className="w-full py-2 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 rounded-xl text-xs font-black transition-all shadow-md flex items-center justify-center space-x-1.5"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>{swappingId === alt.id ? 'Recording...' : 'I Swapped This!'}</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { 
  Sparkles, 
  Search, 
  ArrowRight, 
  Flame, 
  ShieldCheck, 
  TrendingUp, 
  HeartHandshake, 
  Zap, 
  Award,
  CheckCircle2,
  Clock,
  Layers,
  BarChart3
} from 'lucide-react';

export const Home: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const navigate = useNavigate();

  const popularSearches = [
    { name: 'Potato Chips', id: 1 },
    { name: 'Samosa', id: 2 },
    { name: 'Cola Soft Drink', id: 3 },
    { name: 'Instant Noodles', id: 5 },
    { name: 'Cream Biscuits', id: 4 },
    { name: 'Fried Namkeen', id: 6 }
  ];

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      navigate(`/explore?q=${encodeURIComponent(searchTerm.trim())}`);
    }
  };

  return (
    <div className="space-y-20 pb-16">
      {/* Hero Section */}
      <section className="relative pt-12 pb-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto overflow-hidden">
        {/* Glow ambient background effects */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-gradient-to-tr from-emerald-500/20 to-teal-400/10 blur-[120px] rounded-full pointer-events-none -z-10" />

        <div className="text-center max-w-3xl mx-auto space-y-6">
          <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold tracking-wide shadow-sm">
            <Sparkles className="w-3.5 h-3.5" />
            <span>AI-Inspired Nutrition Intelligence for Students</span>
          </div>

          <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight text-white leading-tight">
            See What's Inside. <br />
            <span className="bg-gradient-to-r from-emerald-400 via-teal-300 to-lime-400 bg-clip-text text-transparent">
              Swap What's Better.
            </span>
          </h1>

          <p className="text-base sm:text-lg text-slate-300 leading-relaxed font-normal">
            College life is fueled by quick packaged snacks and street food. 
            NutriLens converts complicated labels into clear <strong>A–E health grades</strong>, 
            smart <strong>taste & texture-matched swaps</strong>, and tracks your weekly calorie and sodium savings.
          </p>

          {/* Search Bar */}
          <form onSubmit={handleSearch} className="max-w-2xl mx-auto pt-2">
            <div className="relative flex items-center shadow-2xl rounded-2xl overflow-hidden p-1.5 bg-slate-900/90 border border-slate-700/80 focus-within:border-emerald-500/80 transition-all">
              <Search className="w-6 h-6 text-slate-400 ml-3 shrink-0" />
              <input
                type="text"
                placeholder="Search your favorite snack (e.g. Potato Chips, Samosa, Cola)..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full bg-transparent px-3 py-3 text-sm sm:text-base text-white placeholder-slate-400 focus:outline-none"
              />
              <button
                type="submit"
                className="px-6 py-3 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold rounded-xl text-sm transition-all flex items-center space-x-1.5 shadow-md shrink-0"
              >
                <span>Analyze</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            {/* Popular quick links */}
            <div className="flex flex-wrap items-center justify-center gap-2 mt-4 text-xs">
              <span className="text-slate-400 font-medium">Try searching:</span>
              {popularSearches.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => navigate(`/snack/${item.id}`)}
                  className="px-2.5 py-1 rounded-lg bg-slate-800/80 text-slate-300 hover:text-emerald-300 hover:bg-slate-700 border border-slate-700/60 transition-colors"
                >
                  {item.name}
                </button>
              ))}
            </div>
          </form>
        </div>

        {/* Live Demo Banner: Chips -> Makhana Showcase */}
        <div className="mt-14 max-w-4xl mx-auto glass-card rounded-2xl p-6 border border-slate-700/80 shadow-2xl">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            {/* Original Junk */}
            <div className="flex items-center space-x-4">
              <img
                src="https://images.unsplash.com/photo-1566478989037-eec170784d0b?w=300&auto=format&fit=crop&q=80"
                alt="Potato Chips"
                className="w-16 h-16 rounded-xl object-cover border border-slate-700"
              />
              <div>
                <span className="text-[10px] font-bold text-rose-400 uppercase tracking-wider block">Original Craving</span>
                <h4 className="text-base font-bold text-white">Potato Chips</h4>
                <div className="flex items-center space-x-2 mt-0.5">
                  <span className="px-2 py-0.5 rounded bg-rose-600 text-white font-black text-xs">Grade D</span>
                  <span className="text-xs text-slate-400">536 kcal · 11.2g Sat. Fat</span>
                </div>
              </div>
            </div>

            {/* Swap Arrow with Diff Highlight */}
            <div className="flex flex-col items-center">
              <div className="w-10 h-10 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center">
                <ArrowRight className="w-5 h-5" />
              </div>
              <span className="text-[11px] font-bold text-emerald-400 mt-1">Cuts 93% Sat. Fat!</span>
            </div>

            {/* Healthy Alternative */}
            <div className="flex items-center space-x-4">
              <img
                src="https://images.unsplash.com/photo-1628088062854-d1870b4553da?w=300&auto=format&fit=crop&q=80"
                alt="Roasted Makhana"
                className="w-16 h-16 rounded-xl object-cover border border-emerald-500/40"
              />
              <div>
                <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider block">Recommended Swap</span>
                <h4 className="text-base font-bold text-white">Roasted Makhana</h4>
                <div className="flex items-center space-x-2 mt-0.5">
                  <span className="px-2 py-0.5 rounded bg-emerald-600 text-white font-black text-xs">Grade A</span>
                  <span className="text-xs text-slate-400">362 kcal · 0.4g Sat. Fat · 9.7g Protein</span>
                </div>
              </div>
            </div>

            {/* CTA */}
            <Link
              to="/compare/1/21"
              className="px-4 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded-xl transition-all shadow-md shrink-0 flex items-center space-x-1"
            >
              <span>See Full Diff</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* How NutriLens Works: 5 Step Journey */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-xs font-extrabold uppercase tracking-widest text-emerald-400">The 5-Step System</span>
          <h2 className="text-3xl font-extrabold text-white mt-1">How NutriLens Solves Your Snack Craving</h2>
          <p className="text-sm text-slate-400 mt-2">
            No shaming, no unrealistic diets. Just intelligent, taste-matched swaps that satisfy your appetite.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          {[
            { step: '01', title: 'Search a Snack', desc: 'Type any favorite snack like Potato Chips, Samosa, or Maggi.', icon: Search },
            { step: '02', title: 'Analyze Nutrition', desc: 'Instant breakdown of calories, saturated fat, sodium, sugar, and Nutri-Score.', icon: Layers },
            { step: '03', title: 'Get Alternatives', desc: 'Algorithm suggests 2–3 alternatives matching your exact taste & texture.', icon: Sparkles },
            { step: '04', title: 'Side-by-Side Diff', desc: 'See visual charts showing calories saved, sugar avoided, and protein gain.', icon: BarChart3 },
            { step: '05', title: 'Log My Swap', desc: 'Record your swap, earn badges, and watch your weekly dashboard level up.', icon: Award }
          ].map((item, idx) => {
            const Icon = item.icon;
            return (
              <div
                key={idx}
                className="glass-card rounded-2xl p-5 border border-slate-800 flex flex-col justify-between hover:border-emerald-500/40 transition-colors"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xl font-black text-emerald-400/40 font-mono">{item.step}</span>
                    <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
                      <Icon className="w-4 h-4" />
                    </div>
                  </div>
                  <h3 className="text-sm font-bold text-white mb-1.5">{item.title}</h3>
                  <p className="text-xs text-slate-400 leading-relaxed">{item.desc}</p>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Innovation & Differentiators */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="glass-card rounded-3xl p-8 border border-slate-800 bg-gradient-to-b from-slate-900/60 to-slate-950/80">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <span className="text-xs font-extrabold uppercase tracking-widest text-emerald-400">Why NutriLens Wins</span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white mt-1">
              5 Technical Innovations for the Hackathon
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800">
              <div className="w-10 h-10 rounded-xl bg-teal-500/20 text-teal-400 flex items-center justify-center font-bold mb-3">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <h4 className="text-sm font-bold text-white mb-1">Standardized Nutri-Score Engine</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                No black-box guesses. We strictly compute points N for negative nutrients and points P for positive nutrients according to official dietary profiling rules.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold mb-3">
                <Sparkles className="w-5 h-5" />
              </div>
              <h4 className="text-sm font-bold text-white mb-1">Taste & Texture Vector Matching</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                If you crave crispy and salty, we won't recommend a plain apple. We recommend air-roasted makhana with rock salt to satisfy the sensory craving!
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800">
              <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold mb-3">
                <HeartHandshake className="w-5 h-5" />
              </div>
              <h4 className="text-sm font-bold text-white mb-1">Authentic Indian Snack Database</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                Built specifically for Indian colleges: samosas, aloo bhujia, chana, makhana, masala nimbu pani, chaas, and kettle-friendly hostel hacks under ₹30.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Ready to swap CTA */}
      <section className="max-w-5xl mx-auto px-4 text-center">
        <div className="bg-gradient-to-r from-emerald-600/20 via-teal-600/20 to-emerald-600/20 border border-emerald-500/40 rounded-3xl p-10">
          <h2 className="text-2xl sm:text-4xl font-extrabold text-white mb-3">
            Ready to Take the 7-Day SnackSwap Challenge?
          </h2>
          <p className="text-sm text-slate-300 max-w-xl mx-auto mb-6">
            Make one simple swap today. See your energy levels rise and track real nutritional savings on your personal dashboard.
          </p>
          <div className="flex flex-wrap items-center justify-center gap-3">
            <Link
              to="/explore"
              className="px-6 py-3 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-xl text-sm transition-all shadow-lg"
            >
              Explore 40 Snacks Database
            </Link>
            <Link
              to="/challenge"
              className="px-6 py-3 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl text-sm border border-slate-700 transition-all"
            >
              Join Weekly Challenge
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

import React from 'react';
import { Link } from 'react-router-dom';
import { Coffee, Flame, Sparkles, Clock, IndianRupee, CheckCircle, ChefHat, ArrowRight } from 'lucide-react';

interface HostelHack {
  id: number;
  title: string;
  category: string;
  costINR: number;
  prepTimeMinutes: number;
  cookingTool: 'No Cooking' | 'Electric Kettle' | 'Microwave / Ready';
  replacesJunk: string;
  replacesSnackId: number;
  image: string;
  ingredients: string[];
  instructions: string[];
  nutritionHighlight: string;
  whyStudentLovesIt: string;
}

export const HostelHacks: React.FC = () => {
  const hacks: HostelHack[] = [
    {
      id: 1,
      title: '3-Minute Spiced Roasted Makhana',
      category: 'Crispy Snack',
      costINR: 25,
      prepTimeMinutes: 3,
      cookingTool: 'No Cooking',
      replacesJunk: 'Potato Chips / Lays',
      replacesSnackId: 1,
      image: 'https://images.unsplash.com/photo-1628088062854-d1870b4553da?w=600&auto=format&fit=crop&q=80',
      ingredients: [
        '1 packet plain raw or pre-roasted Makhana (₹20)',
        '1 pinch Chaat Masala & Black Salt',
        'Optional: 1 tsp Ghee or drop of mustard oil'
      ],
      instructions: [
        'Pour makhana into your hostel mug or bowl.',
        'Sprinkle chaat masala and black salt evenly.',
        'Shake the bowl vigorously for 10 seconds. Enjoy instant airy crunch!'
      ],
      nutritionHighlight: 'Cuts 93% saturated fat and 70% sodium compared to fried potato chips.',
      whyStudentLovesIt: 'Super light, no oil stains on your laptop keyboard while studying late!'
    },
    {
      id: 2,
      title: 'Spiced Bhuna Chana & Gur (Jaggery) Combo',
      category: 'Energy Booster',
      costINR: 15,
      prepTimeMinutes: 1,
      cookingTool: 'No Cooking',
      replacesJunk: 'Milk Chocolate Bar / Candy',
      replacesSnackId: 8,
      image: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=600&auto=format&fit=crop&q=80',
      ingredients: [
        '1 handful roasted black chana with skins (₹10)',
        '1 small cube organic jaggery (₹5)'
      ],
      instructions: [
        'Keep a jar of bhuna chana and jaggery cubes on your study table.',
        'Take alternate bites of crunchy chana and sweet jaggery.',
        'Zero preparation, 100% natural sustained dopamine and iron boost!'
      ],
      nutritionHighlight: 'Zero refined white sugar, high in plant protein and dietary iron.',
      whyStudentLovesIt: 'Legendary Indian stamina snack. Defeats 4 PM library fatigue instantly.'
    },
    {
      id: 3,
      title: 'Hostel Kettle Whole-Wheat Atta Veggie Bowl',
      category: 'Hot Meal',
      costINR: 30,
      prepTimeMinutes: 5,
      cookingTool: 'Electric Kettle',
      replacesJunk: 'Fried Instant Noodles / Maggi',
      replacesSnackId: 5,
      image: 'https://images.unsplash.com/photo-1552611052-33e04de081de?w=600&auto=format&fit=crop&q=80',
      ingredients: [
        '1 cake 100% Whole Wheat Atta Noodles (₹15)',
        '1 small handful frozen peas or shredded carrots from mess (₹10)',
        'Half packet spice mix (to control sodium) + dash of pepper'
      ],
      instructions: [
        'Boil water in your hostel electric kettle.',
        'Drop in the whole-wheat atta noodles and shredded veggies.',
        'Let sit covered for 4 minutes with kettle off. Drain excess broth and season lightly!'
      ],
      nutritionHighlight: 'Saves 68% sodium and 82% saturated fat compared to flash-fried noodles.',
      whyStudentLovesIt: 'Satisfies late-night exam slurping cravings without next-day sodium bloat.'
    },
    {
      id: 4,
      title: 'Quick Chatpata Peanut & Onion Chaat',
      category: 'Crunchy Protein',
      costINR: 20,
      prepTimeMinutes: 2,
      cookingTool: 'No Cooking',
      replacesJunk: 'Deep-Fried Namkeen (Bhujia)',
      replacesSnackId: 6,
      image: 'https://images.unsplash.com/photo-1525253086316-d0c936c81468?w=600&auto=format&fit=crop&q=80',
      ingredients: [
        '40g dry-roasted unsalted peanuts (₹12)',
        'Quarter finely chopped onion & green chili (from dining hall) (₹5)',
        'Squeeze of half fresh lemon + pinch of salt & cumin (₹3)'
      ],
      instructions: [
        'Toss peanuts and chopped onions into a steel glass or bowl.',
        'Squeeze fresh lemon juice over the top.',
        'Mix with a spoon. Spicy, crunchy, street-chaat bliss in 2 minutes!'
      ],
      nutritionHighlight: 'Packs 10g natural plant protein, healthy monounsaturated fats, and zero palm oil.',
      whyStudentLovesIt: 'Tastes like Mumbai beach bhel puri but pure clean protein.'
    },
    {
      id: 5,
      title: 'Hostel Room Masala Chaas (Spiced Buttermilk)',
      category: 'Cooling Beverage',
      costINR: 15,
      prepTimeMinutes: 2,
      cookingTool: 'No Cooking',
      replacesJunk: 'Cola / Fizzy Soda Can (₹40)',
      replacesSnackId: 3,
      image: 'https://images.unsplash.com/photo-1550583724-b2692b85b150?w=600&auto=format&fit=crop&q=80',
      ingredients: [
        '1 pouch fresh curd / dahi or buttermilk (₹12)',
        'Half glass cold water',
        'Roasted cumin (jeera) powder and pinch of black salt (₹3)'
      ],
      instructions: [
        'Pour curd and cold water into your water bottle or shaker.',
        'Add jeera powder and black salt.',
        'Shake vigorously for 15 seconds until frothy. Sip cold!'
      ],
      nutritionHighlight: 'Zero added sugar, active gut probiotics, and cooling electrolyte hydration.',
      whyStudentLovesIt: 'Costs 1/3rd of a soda can and fixes hostel indigestion effortlessly.'
    },
    {
      id: 6,
      title: 'Mess Bread Paneer & Mint Chutney Sandwich',
      category: 'Filling Bite',
      costINR: 30,
      prepTimeMinutes: 3,
      cookingTool: 'No Cooking',
      replacesJunk: 'Deep-Fried Bread Pakora',
      replacesSnackId: 13,
      image: 'https://images.unsplash.com/photo-1528735602780-2552fd46c7af?w=600&auto=format&fit=crop&q=80',
      ingredients: [
        '2 slices whole wheat bread or roti (₹6)',
        '30g fresh paneer slices (₹18)',
        '1 spoonful green mint chutney (₹4)',
        'Cucumber or tomato slices'
      ],
      instructions: [
        'Spread fresh mint coriander chutney on bread slices.',
        'Layer fresh paneer slices and crisp cucumber rounds.',
        'Press together. Clean, cold, high-protein club sandwich!'
      ],
      nutritionHighlight: 'Eliminates 15g of frying oil fat while doubling wholesome casein protein.',
      whyStudentLovesIt: 'Filling enough to skip expensive food delivery apps.'
    }
  ];

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center space-x-2">
            <span className="text-xs uppercase font-extrabold tracking-widest text-amber-400">
              Module 9: Hostel Snack Hacks
            </span>
            <span className="text-xs bg-amber-500/10 text-amber-300 px-2 py-0.5 rounded-full border border-amber-500/30">
              Budget &lt; ₹30 · Minimal Prep
            </span>
          </div>
          <h1 className="text-3xl font-extrabold text-white mt-1">Hostel Room Survival Hacks</h1>
          <p className="text-sm text-slate-400 mt-1 max-w-2xl">
            No kitchen? No problem. College-tested snack recipes that take under 3 minutes, cost less than junk food, and require only a bowl, spoon, or kettle.
          </p>
        </div>

        <Link
          to="/explore"
          className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl border border-slate-700 self-start md:self-auto flex items-center space-x-1.5"
        >
          <span>Explore All Snacks</span>
          <ArrowRight className="w-3.5 h-3.5 text-emerald-400" />
        </Link>
      </div>

      {/* Hacks Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {hacks.map((hack) => (
          <div
            key={hack.id}
            className="glass-card glass-card-hover rounded-2xl overflow-hidden border border-slate-800 flex flex-col justify-between"
          >
            <div>
              {/* Header Image */}
              <div className="relative h-44 w-full bg-slate-900">
                <img
                  src={hack.image}
                  alt={hack.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-black/30" />

                {/* Badges */}
                <div className="absolute top-2.5 left-2.5 flex items-center space-x-1.5">
                  <span className="text-[10px] font-black bg-amber-400 text-slate-950 px-2 py-0.5 rounded-md shadow-sm">
                    ₹{hack.costINR} ONLY
                  </span>
                  <span className="text-[10px] font-bold bg-slate-900/90 text-slate-200 px-2 py-0.5 rounded-md border border-slate-700 flex items-center space-x-1">
                    <Clock className="w-3 h-3 text-emerald-400" />
                    <span>{hack.prepTimeMinutes} mins</span>
                  </span>
                </div>

                <div className="absolute top-2.5 right-2.5">
                  <span className="text-[10px] font-semibold bg-black/70 text-slate-300 px-2 py-0.5 rounded border border-white/10">
                    {hack.cookingTool}
                  </span>
                </div>

                {/* Replaces junk tag */}
                <div className="absolute bottom-2.5 left-2.5">
                  <span className="text-xs bg-rose-500/90 text-white font-bold px-2 py-0.5 rounded-md shadow-sm">
                    Swaps out: {hack.replacesJunk}
                  </span>
                </div>
              </div>

              {/* Content */}
              <div className="p-5 space-y-4">
                <div>
                  <h3 className="text-lg font-bold text-white">{hack.title}</h3>
                  <p className="text-xs text-amber-300/90 mt-1 italic">
                    "{hack.whyStudentLovesIt}"
                  </p>
                </div>

                {/* Nutritional Benefit Callout */}
                <div className="p-3 bg-emerald-500/10 border border-emerald-500/25 rounded-xl text-xs text-emerald-300">
                  <strong className="text-white block mb-0.5 font-bold">Nutritional Superpower:</strong>
                  {hack.nutritionHighlight}
                </div>

                {/* Ingredients */}
                <div>
                  <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5 flex items-center space-x-1">
                    <ChefHat className="w-3.5 h-3.5 text-slate-400" />
                    <span>Pocket-Friendly Ingredients</span>
                  </h4>
                  <ul className="space-y-1 text-xs text-slate-400">
                    {hack.ingredients.map((ing, idx) => (
                      <li key={idx} className="flex items-start space-x-1.5">
                        <span className="text-emerald-400 font-bold">•</span>
                        <span>{ing}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Quick Steps */}
                <div>
                  <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-1.5">
                    No-Stove Preparation
                  </h4>
                  <ol className="space-y-1 text-xs text-slate-300 list-decimal list-inside">
                    {hack.instructions.map((step, idx) => (
                      <li key={idx} className="leading-relaxed">
                        <span className="text-slate-400">{step}</span>
                      </li>
                    ))}
                  </ol>
                </div>
              </div>
            </div>

            {/* Action */}
            <div className="p-5 pt-0">
              <Link
                to={`/compare/${hack.replacesSnackId}/21`}
                className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold transition-all flex items-center justify-center space-x-1.5 border border-slate-700"
              >
                <span>Compare vs {hack.replacesJunk.split('/')[0]}</span>
                <ArrowRight className="w-3.5 h-3.5 text-emerald-400" />
              </Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

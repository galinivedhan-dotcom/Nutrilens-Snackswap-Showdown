import React from 'react';
import { Sparkles, Heart, ShieldAlert, Award } from 'lucide-react';
import { Link } from 'react-router-dom';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-950/80 border-t border-slate-800/80 mt-20 pt-12 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-10">
          {/* Brand */}
          <div className="md:col-span-2 space-y-3">
            <div className="flex items-center space-x-2.5">
              <div className="w-8 h-8 rounded-lg bg-emerald-500 flex items-center justify-center text-slate-950 font-bold">
                <Sparkles className="w-4 h-4" />
              </div>
              <span className="text-lg font-extrabold text-white">
                Nutri<span className="text-emerald-400">Lens</span>
              </span>
            </div>
            <p className="text-slate-400 text-xs leading-relaxed max-w-md">
              A smart nutrition comparison platform designed for college students and young professionals. 
              We transform confusing food labels into actionable health grades, smart taste-matched swaps, and healthy habits.
            </p>
            <div className="flex items-center space-x-2 text-xs text-slate-400">
              <Award className="w-4 h-4 text-emerald-400" />
              <span>Built for Hackathon: HealthTech & AI-inspired Recommendation</span>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 mb-3">Quick Navigation</h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li><Link to="/" className="hover:text-emerald-400">Home Showcase</Link></li>
              <li><Link to="/explore" className="hover:text-emerald-400">40-Snack Nutrition Explorer</Link></li>
              <li><Link to="/compare/1/21" className="hover:text-emerald-400">Side-by-Side Comparison</Link></li>
              <li><Link to="/dashboard" className="hover:text-emerald-400">My Swaps Dashboard</Link></li>
              <li><Link to="/challenge" className="hover:text-emerald-400">7-Day Healthy Challenge</Link></li>
              <li><Link to="/hostel-hacks" className="hover:text-emerald-400">Hostel Snack Hacks (&lt; ₹30)</Link></li>
              <li><Link to="/scanner" className="hover:text-emerald-400">Barcode Scanner (Open Food Facts)</Link></li>
            </ul>
          </div>

          {/* Scientific Transparency */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 mb-3">Scoring Transparency</h4>
            <p className="text-[11px] text-slate-400 leading-relaxed mb-3">
              NutriLens implements the standardized <strong>Nutri-Score profiling algorithm</strong> (negative points for saturated fat, free sugars, sodium & calories; positive points for fiber, protein, fruits/legumes).
            </p>
            <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 text-[10px] text-slate-400 flex items-start space-x-2">
              <ShieldAlert className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
              <span>Values derived from ICMR-NIN IFCT 2017 & USDA FoodData Central. For educational nutrition guidance.</span>
            </div>
          </div>
        </div>

        <div className="pt-6 border-t border-slate-800/60 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500">
          <p>© 2026 NutriLens Showdown. Open Source Hackathon Project.</p>
          <div className="flex items-center space-x-1 mt-2 sm:mt-0">
            <span>Crafted with</span>
            <Heart className="w-3 h-3 text-rose-500 inline fill-rose-500" />
            <span>for healthier campus snacking</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

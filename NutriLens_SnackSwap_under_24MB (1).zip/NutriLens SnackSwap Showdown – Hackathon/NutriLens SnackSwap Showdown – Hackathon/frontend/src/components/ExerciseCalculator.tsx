import React from 'react';
import { Footprints, Bike, Flame, Sparkles, Info } from 'lucide-react';

interface ExerciseCalculatorProps {
  calories: number;
  snackName?: string;
  savedCalories?: number;
  savedMinutes?: { walking: number; jogging: number; cycling: number };
}

export const ExerciseCalculator: React.FC<ExerciseCalculatorProps> = ({
  calories,
  snackName = 'Snack',
  savedCalories,
  savedMinutes
}) => {
  // Activity rates (kcal per minute for ~65kg human)
  const walkingRate = 3.7;
  const joggingRate = 9.0;
  const cyclingRate = 6.5;

  const walkingMin = Math.round(calories / walkingRate);
  const joggingMin = Math.round(calories / joggingRate);
  const cyclingMin = Math.round(calories / cyclingRate);

  return (
    <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 rounded-lg bg-orange-500/20 text-orange-400 flex items-center justify-center font-bold">
            <Flame className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-white">Exercise Energy Equivalency</h4>
            <p className="text-xs text-slate-400">
              Energy burn equivalent for <span className="text-amber-400 font-bold">{calories} kcal</span>
            </p>
          </div>
        </div>
        <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700">
          Module 6
        </span>
      </div>

      {/* Activity Grid */}
      <div className="grid grid-cols-3 gap-3">
        {/* Walking */}
        <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800/80 text-center hover:border-emerald-500/40 transition-colors">
          <div className="w-8 h-8 mx-auto mb-2 rounded-full bg-emerald-500/15 text-emerald-400 flex items-center justify-center">
            <Footprints className="w-4 h-4" />
          </div>
          <span className="text-xs font-semibold text-slate-300 block">Walking</span>
          <span className="text-lg font-black text-white block mt-0.5">{walkingMin} <span className="text-xs font-normal text-slate-400">mins</span></span>
          <span className="text-[10px] text-slate-500 block mt-0.5">@ 4.5 km/h</span>
        </div>

        {/* Jogging */}
        <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800/80 text-center hover:border-orange-500/40 transition-colors">
          <div className="w-8 h-8 mx-auto mb-2 rounded-full bg-orange-500/15 text-orange-400 flex items-center justify-center">
            <Flame className="w-4 h-4" />
          </div>
          <span className="text-xs font-semibold text-slate-300 block">Jogging</span>
          <span className="text-lg font-black text-white block mt-0.5">{joggingMin} <span className="text-xs font-normal text-slate-400">mins</span></span>
          <span className="text-[10px] text-slate-500 block mt-0.5">@ 8.0 km/h</span>
        </div>

        {/* Cycling */}
        <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800/80 text-center hover:border-teal-500/40 transition-colors">
          <div className="w-8 h-8 mx-auto mb-2 rounded-full bg-teal-500/15 text-teal-400 flex items-center justify-center">
            <Bike className="w-4 h-4" />
          </div>
          <span className="text-xs font-semibold text-slate-300 block">Cycling</span>
          <span className="text-lg font-black text-white block mt-0.5">{cyclingMin} <span className="text-xs font-normal text-slate-400">mins</span></span>
          <span className="text-[10px] text-slate-500 block mt-0.5">@ 15 km/h</span>
        </div>
      </div>

      {/* Saved Workout Minutes Banner (if swap saved calories) */}
      {savedMinutes && savedMinutes.walking > 0 && (
        <div className="mt-4 p-3 bg-gradient-to-r from-emerald-500/15 to-teal-500/15 border border-emerald-500/30 rounded-xl flex items-center space-x-3">
          <div className="w-8 h-8 rounded-lg bg-emerald-500 text-slate-950 flex items-center justify-center font-black shrink-0">
            <Sparkles className="w-4 h-4" />
          </div>
          <div className="text-xs">
            <span className="font-bold text-emerald-300 block">
              🎉 By swapping, you automatically avoid {savedMinutes.walking} minutes of walking!
            </span>
            <span className="text-slate-400 text-[11px]">
              Or {savedMinutes.jogging} minutes of high-intensity jogging saved without hitting the track.
            </span>
          </div>
        </div>
      )}

      {/* Educational Disclaimer */}
      <div className="mt-3 flex items-start space-x-1.5 text-[10px] text-slate-500">
        <Info className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
        <span>
          Educational energy equivalents only. Actual energy expenditure varies with body weight, metabolism, and intensity. Exercise is for cardiovascular health, not a compensation for eating.
        </span>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { Snack } from '../types/snack';
import { HealthGradeBadge } from './HealthGradeBadge';
import { AlertTriangle, CheckCircle, ShieldAlert, Scale, Sparkles } from 'lucide-react';

interface NutritionFactsCardProps {
  snack: Snack;
}

export const NutritionFactsCard: React.FC<NutritionFactsCardProps> = ({ snack }) => {
  const [useServing, setUseServing] = useState(false);
  const [customServingGrams, setCustomServingGrams] = useState<number>(snack.servingSizeGrams || 50);

  const factor = useServing ? customServingGrams / 100 : 1;

  const n = snack.nutrition;
  const cal = Math.round(n.calories * factor * 10) / 10;
  const fat = Math.round(n.totalFat * factor * 10) / 10;
  const satFat = Math.round(n.saturatedFat * factor * 10) / 10;
  const carbs = Math.round(n.carbohydrates * factor * 10) / 10;
  const sugar = Math.round(n.sugar * factor * 10) / 10;
  const protein = Math.round(n.protein * factor * 10) / 10;
  const fiber = Math.round(n.fiber * factor * 10) / 10;
  const sodium = Math.round(n.sodium * factor);

  return (
    <div className="glass-card rounded-2xl p-6 border border-slate-800">
      {/* Header and Toggle */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-4">
        <div>
          <span className="text-xs uppercase font-extrabold tracking-wider text-emerald-400">
            Nutritional Facts & Profile
          </span>
          <h2 className="text-xl font-bold text-white mt-0.5">{snack.name}</h2>
          <p className="text-xs text-slate-400">
            Official Source: <span className="text-slate-300 font-medium">{snack.dataSource}</span> (Verified {snack.lastVerified})
          </p>
        </div>

        {/* Serving Size Toggle */}
        <div className="flex items-center space-x-2 bg-slate-900 p-1.5 rounded-xl border border-slate-700/60 self-start sm:self-auto">
          <button
            onClick={() => setUseServing(false)}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
              !useServing
                ? 'bg-emerald-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Per 100g (Standard)
          </button>
          <button
            onClick={() => setUseServing(true)}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
              useServing
                ? 'bg-emerald-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Per Serving ({customServingGrams}g)
          </button>
        </div>
      </div>

      {/* Serving Slider if in serving mode */}
      {useServing && (
        <div className="my-4 p-3 bg-slate-900/60 rounded-xl border border-slate-800 flex items-center justify-between space-x-4">
          <div className="flex items-center space-x-2">
            <Scale className="w-4 h-4 text-emerald-400" />
            <span className="text-xs font-semibold text-slate-300">
              Serving: {customServingGrams}g ({snack.servingSizeDescription})
            </span>
          </div>
          <div className="flex items-center space-x-2 w-48">
            <input
              type="range"
              min="10"
              max="200"
              step="5"
              value={customServingGrams}
              onChange={(e) => setCustomServingGrams(Number(e.target.value))}
              className="w-full accent-emerald-500 cursor-pointer"
            />
            <span className="text-xs font-mono text-emerald-400 w-10 text-right">{customServingGrams}g</span>
          </div>
        </div>
      )}

      {/* Main Nutrition Facts Table */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 my-5">
        <div className="p-3 bg-slate-900/80 rounded-xl border border-slate-800 text-center">
          <span className="text-xs text-slate-400 font-medium block">Energy</span>
          <span className="text-2xl font-black text-amber-400 block mt-1">{cal}</span>
          <span className="text-[11px] text-slate-500">kcal</span>
        </div>
        <div className="p-3 bg-slate-900/80 rounded-xl border border-slate-800 text-center">
          <span className="text-xs text-slate-400 font-medium block">Saturated Fat</span>
          <span className={`text-2xl font-black block mt-1 ${satFat > 5 ? 'text-rose-400' : 'text-slate-200'}`}>
            {satFat}
          </span>
          <span className="text-[11px] text-slate-500">grams</span>
        </div>
        <div className="p-3 bg-slate-900/80 rounded-xl border border-slate-800 text-center">
          <span className="text-xs text-slate-400 font-medium block">Total Sugar</span>
          <span className={`text-2xl font-black block mt-1 ${sugar > 10 ? 'text-rose-400' : 'text-slate-200'}`}>
            {sugar}
          </span>
          <span className="text-[11px] text-slate-500">grams</span>
        </div>
        <div className="p-3 bg-slate-900/80 rounded-xl border border-slate-800 text-center">
          <span className="text-xs text-slate-400 font-medium block">Sodium</span>
          <span className={`text-2xl font-black block mt-1 ${sodium > 400 ? 'text-rose-400' : 'text-slate-200'}`}>
            {sodium}
          </span>
          <span className="text-[11px] text-slate-500">milligrams</span>
        </div>
      </div>

      {/* Secondary Nutrients Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 my-3 text-xs bg-slate-900/40 p-3 rounded-xl border border-slate-800/80">
        <div>
          <span className="text-slate-400">Total Fat:</span> <span className="font-bold text-white">{fat}g</span>
        </div>
        <div>
          <span className="text-slate-400">Total Carbs:</span> <span className="font-bold text-white">{carbs}g</span>
        </div>
        <div>
          <span className="text-slate-400">Dietary Fiber:</span> <span className="font-bold text-emerald-400">{fiber}g</span>
        </div>
        <div>
          <span className="text-slate-400">Protein:</span> <span className="font-bold text-emerald-400">{protein}g</span>
        </div>
      </div>

      {/* Warnings & Highlights */}
      <div className="mt-5 space-y-2">
        {/* Warnings */}
        {snack.warnings && snack.warnings.length > 0 && (
          <div className="flex flex-wrap gap-2">
            {snack.warnings.map((w, idx) => (
              <span
                key={idx}
                className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-lg text-xs font-semibold bg-rose-500/15 text-rose-300 border border-rose-500/30"
              >
                <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
                <span>{w.text}</span>
              </span>
            ))}
          </div>
        )}

        {/* Highlights */}
        {snack.highlights && snack.highlights.length > 0 && (
          <div className="flex flex-wrap gap-2">
            {snack.highlights.map((h, idx) => (
              <span
                key={idx}
                className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-lg text-xs font-semibold bg-emerald-500/15 text-emerald-300 border border-emerald-500/30"
              >
                <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                <span>{h.text}</span>
              </span>
            ))}
          </div>
        )}

        {/* Allergens */}
        {snack.allergens && snack.allergens.length > 0 && (
          <div className="pt-2 flex items-center space-x-2 text-xs text-slate-400">
            <ShieldAlert className="w-4 h-4 text-amber-400" />
            <span>Allergen Notice: Contains <strong className="text-amber-300">{snack.allergens.join(', ')}</strong></span>
          </div>
        )}
      </div>

      {/* Nutri-Score Algorithm Breakdown Accordion */}
      {snack.scoringBreakdown && (
        <div className="mt-6 pt-5 border-t border-slate-800">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center space-x-2">
              <HealthGradeBadge grade={snack.healthGrade} score={snack.healthScore} size="md" />
              <div>
                <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                  Nutri-Score Engine Breakdown (Points System)
                </h4>
                <p className="text-[11px] text-slate-400">
                  Calculated using official Nutri-Score rules: Points N (Negative) minus Points P (Positive).
                </p>
              </div>
            </div>
            <span className="text-xs font-mono font-bold text-emerald-400 bg-slate-900 px-2.5 py-1 rounded-lg border border-slate-700">
              Score: {snack.healthScore}
            </span>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
            <div className="bg-slate-900/60 p-2 rounded-lg border border-slate-800">
              <span className="text-slate-400 text-[10px] block">Energy (kJ)</span>
              <span className="font-bold text-rose-300">+{snack.scoringBreakdown.energyPoints} pts</span>
            </div>
            <div className="bg-slate-900/60 p-2 rounded-lg border border-slate-800">
              <span className="text-slate-400 text-[10px] block">Free Sugars</span>
              <span className="font-bold text-rose-300">+{snack.scoringBreakdown.sugarPoints} pts</span>
            </div>
            <div className="bg-slate-900/60 p-2 rounded-lg border border-slate-800">
              <span className="text-slate-400 text-[10px] block">Saturated Fat</span>
              <span className="font-bold text-rose-300">+{snack.scoringBreakdown.satFatPoints} pts</span>
            </div>
            <div className="bg-slate-900/60 p-2 rounded-lg border border-slate-800">
              <span className="text-slate-400 text-[10px] block">Sodium</span>
              <span className="font-bold text-rose-300">+{snack.scoringBreakdown.sodiumPoints} pts</span>
            </div>
            <div className="bg-slate-900/60 p-2 rounded-lg border border-slate-800">
              <span className="text-slate-400 text-[10px] block">Dietary Fiber</span>
              <span className="font-bold text-emerald-400">-{snack.scoringBreakdown.fiberPoints} pts</span>
            </div>
            <div className="bg-slate-900/60 p-2 rounded-lg border border-slate-800">
              <span className="text-slate-400 text-[10px] block">Protein</span>
              <span className="font-bold text-emerald-400">-{snack.scoringBreakdown.proteinPoints} pts</span>
            </div>
            <div className="bg-slate-900/60 p-2 rounded-lg border border-slate-800">
              <span className="text-slate-400 text-[10px] block">Fruits / Veg / Nuts</span>
              <span className="font-bold text-emerald-400">-{snack.scoringBreakdown.fvnlPoints} pts</span>
            </div>
            <div className="bg-slate-900/60 p-2 rounded-lg border border-slate-800">
              <span className="text-slate-400 text-[10px] block">Traffic Light</span>
              <span className="font-bold capitalize text-white">{snack.trafficLight}</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

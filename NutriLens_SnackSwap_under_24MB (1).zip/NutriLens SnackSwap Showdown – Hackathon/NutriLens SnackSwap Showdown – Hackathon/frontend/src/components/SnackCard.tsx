import React from 'react';
import { Link } from 'react-router-dom';
import { Snack } from '../types/snack';
import { HealthGradeBadge } from './HealthGradeBadge';
import { Flame, Droplet, ArrowRight, Sparkles, Home } from 'lucide-react';

interface SnackCardProps {
  snack: Snack;
  onSelectCompare?: (snack: Snack) => void;
}

export const SnackCard: React.FC<SnackCardProps> = ({ snack, onSelectCompare }) => {
  return (
    <div className="glass-card glass-card-hover rounded-2xl overflow-hidden flex flex-col justify-between border border-slate-800 group">
      {/* Top Image & Floating Badges */}
      <div className="relative h-44 w-full overflow-hidden bg-slate-900">
        <img
          src={snack.image}
          alt={snack.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          onError={(e) => {
            // fallback image
            (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1566478989037-eec170784d0b?w=600&auto=format&fit=crop&q=80';
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0B132B] via-transparent to-black/40" />

        {/* Floating Health Grade */}
        <div className="absolute top-2.5 right-2.5">
          <HealthGradeBadge grade={snack.healthGrade} score={snack.healthScore} size="sm" />
        </div>

        {/* Category & Healthy pill */}
        <div className="absolute top-2.5 left-2.5 flex flex-wrap gap-1">
          <span className="text-[10px] font-bold bg-black/60 backdrop-blur-md text-slate-200 px-2 py-0.5 rounded-full border border-white/10">
            {snack.category}
          </span>
          {snack.isHealthyAlternative ? (
            <span className="text-[10px] font-bold bg-emerald-500/90 text-slate-950 px-2 py-0.5 rounded-full flex items-center space-x-1 shadow-sm">
              <Sparkles className="w-2.5 h-2.5" />
              <span>Healthy Swap</span>
            </span>
          ) : (
            <span className="text-[10px] font-semibold bg-rose-500/80 text-white px-2 py-0.5 rounded-full">
              Common Junk
            </span>
          )}
        </div>

        {/* Price & Hostel friendly pill */}
        <div className="absolute bottom-2.5 left-2.5 flex items-center space-x-1.5">
          <span className="text-xs font-black bg-slate-950/80 text-emerald-400 px-2 py-0.5 rounded-md border border-emerald-500/30">
            ₹{snack.priceINR}
          </span>
          {snack.hostelFriendly && (
            <span className="text-[10px] bg-slate-900/80 text-amber-300 px-1.5 py-0.5 rounded flex items-center space-x-0.5 border border-amber-500/30" title="Hostel Friendly: minimal/no prep">
              <Home className="w-2.5 h-2.5" />
              <span>Hostel OK</span>
            </span>
          )}
        </div>
      </div>

      {/* Content */}
      <div className="p-4 flex-1 flex flex-col justify-between">
        <div>
          <div className="flex items-start justify-between">
            <h3 className="font-bold text-base text-white group-hover:text-emerald-400 transition-colors line-clamp-1">
              {snack.name}
            </h3>
          </div>

          <p className="text-xs text-slate-400 mt-1 line-clamp-2">
            {snack.description}
          </p>

          {/* Taste & texture tag */}
          <div className="mt-2.5 flex items-center space-x-1">
            <span className="text-[10px] font-medium text-slate-400 bg-slate-800/80 px-2 py-0.5 rounded-full border border-slate-700/60 line-clamp-1">
              👅 {snack.tasteTexture}
            </span>
          </div>

          {/* Key Nutrition Matrix (per 100g) */}
          <div className="grid grid-cols-4 gap-1.5 bg-slate-900/60 rounded-xl p-2.5 my-3 border border-slate-800/80 text-center">
            <div>
              <span className="text-[10px] text-slate-400 block">Calories</span>
              <span className="text-xs font-extrabold text-amber-400 flex items-center justify-center">
                <Flame className="w-3 h-3 mr-0.5" />
                {snack.nutrition.calories}
              </span>
            </div>
            <div>
              <span className="text-[10px] text-slate-400 block">Sat. Fat</span>
              <span className={`text-xs font-bold ${snack.nutrition.saturatedFat > 5 ? 'text-rose-400' : 'text-slate-200'}`}>
                {snack.nutrition.saturatedFat}g
              </span>
            </div>
            <div>
              <span className="text-[10px] text-slate-400 block">Sugar</span>
              <span className={`text-xs font-bold ${snack.nutrition.sugar > 10 ? 'text-rose-400' : 'text-slate-200'}`}>
                {snack.nutrition.sugar}g
              </span>
            </div>
            <div>
              <span className="text-[10px] text-slate-400 block">Protein</span>
              <span className="text-xs font-bold text-emerald-400">
                {snack.nutrition.protein}g
              </span>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center space-x-2 pt-1 border-t border-slate-800/60">
          <Link
            to={`/snack/${snack.id}`}
            className="flex-1 py-1.5 px-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-semibold text-center transition-colors"
          >
            Nutrition Details
          </Link>
          
          {!snack.isHealthyAlternative ? (
            <Link
              to={`/recommendations/${snack.id}`}
              className="flex-1 py-1.5 px-2 bg-emerald-600/90 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold text-center transition-all flex items-center justify-center space-x-1 shadow-sm"
            >
              <span>Swap This</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          ) : (
            <Link
              to={`/compare/1/${snack.id}`}
              className="flex-1 py-1.5 px-2 bg-teal-600/90 hover:bg-teal-500 text-white rounded-lg text-xs font-bold text-center transition-all flex items-center justify-center space-x-1 shadow-sm"
            >
              <span>Compare</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          )}
        </div>
      </div>
    </div>
  );
};

import React from 'react';

interface HealthGradeBadgeProps {
  grade: 'A' | 'B' | 'C' | 'D' | 'E';
  score?: number;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showDetails?: boolean;
}

export const HealthGradeBadge: React.FC<HealthGradeBadgeProps> = ({
  grade,
  score,
  size = 'md',
  showDetails = false
}) => {
  const grades: Array<{ key: 'A' | 'B' | 'C' | 'D' | 'E'; bg: string; text: string; label: string }> = [
    { key: 'A', bg: 'bg-emerald-600', text: 'text-white', label: 'Best Profile' },
    { key: 'B', bg: 'bg-lime-500', text: 'text-slate-900', label: 'Good Profile' },
    { key: 'C', bg: 'bg-amber-400', text: 'text-slate-900', label: 'Moderate' },
    { key: 'D', bg: 'bg-orange-500', text: 'text-white', label: 'Less Favorable' },
    { key: 'E', bg: 'bg-rose-600', text: 'text-white', label: 'Least Favorable' }
  ];

  const currentGrade = grades.find(g => g.key === grade) || grades[2];

  const sizeClasses = {
    sm: 'text-xs px-2 py-0.5 font-bold rounded',
    md: 'text-sm px-2.5 py-1 font-bold rounded-md',
    lg: 'text-base px-3.5 py-1.5 font-extrabold rounded-lg',
    xl: 'text-xl px-5 py-2 font-black rounded-xl'
  };

  return (
    <div className="inline-flex flex-col items-center">
      <div className="flex items-center space-x-1 bg-slate-900/80 p-1 rounded-lg border border-slate-700/60 shadow-inner">
        {grades.map(g => {
          const isActive = g.key === grade;
          return (
            <div
              key={g.key}
              className={`flex items-center justify-center transition-all duration-200 ${
                isActive
                  ? `${g.bg} ${g.text} font-black scale-110 shadow-lg ring-2 ring-white/30 z-10 ${
                      size === 'xl' ? 'w-10 h-10 text-xl rounded-lg' : size === 'lg' ? 'w-8 h-8 text-base rounded-md' : 'w-6 h-6 text-xs rounded'
                    }`
                  : `bg-slate-800/80 text-slate-500 opacity-40 font-semibold ${
                      size === 'xl' ? 'w-7 h-7 text-sm rounded' : size === 'lg' ? 'w-6 h-6 text-xs rounded' : 'w-5 h-5 text-[10px] rounded'
                    }`
              }`}
            >
              {g.key}
            </div>
          );
        })}
      </div>
      {showDetails && (
        <div className="mt-1 flex items-center space-x-1.5 text-xs">
          <span className="font-semibold text-slate-300">Grade {grade}:</span>
          <span className="text-slate-400">{currentGrade.label}</span>
          {score !== undefined && (
            <span className="text-slate-500 text-[11px] font-mono">({score > 0 ? `+${score}` : score} pts)</span>
          )}
        </div>
      )}
    </div>
  );
};

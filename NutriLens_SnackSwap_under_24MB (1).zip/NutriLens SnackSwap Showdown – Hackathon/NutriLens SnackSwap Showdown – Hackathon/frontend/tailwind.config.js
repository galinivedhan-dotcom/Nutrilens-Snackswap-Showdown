/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        nutri: {
          dark: '#0B132B',
          navy: '#1C2541',
          teal: '#3A506B',
          emerald: '#10B981',
          lime: '#84CC16',
          amber: '#F59E0B',
          coral: '#F97316',
          rose: '#EF4444',
          accent: '#06D6A0',
          card: '#131D38'
        }
      },
      fontFamily: {
        sans: ['Plus Jakarta Sans', 'Inter', 'system-ui', 'sans-serif']
      }
    },
  },
  plugins: [],
}

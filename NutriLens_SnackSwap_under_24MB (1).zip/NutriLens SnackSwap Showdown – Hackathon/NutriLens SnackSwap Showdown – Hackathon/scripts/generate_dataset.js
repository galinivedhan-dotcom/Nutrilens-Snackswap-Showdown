const fs = require('fs');
const path = require('path');

// Nutri-Score algorithm implementation (Solid foods & Beverages)
function calculateNutriScore(nutrient, isBeverage = false, isWater = false) {
  if (isWater) {
    return {
      pointsN: 0,
      pointsP: 0,
      finalScore: -15,
      grade: 'A',
      trafficLight: 'green',
      meaning: 'Best nutritional profile',
      breakdown: { energyPoints: 0, sugarPoints: 0, satFatPoints: 0, sodiumPoints: 0, fiberPoints: 0, proteinPoints: 0, fvnlPoints: 5 }
    };
  }

  const energyKj = nutrient.calories * 4.184;
  
  // Energy points (0-10)
  let energyPoints = 0;
  if (!isBeverage) {
    const energyThresholds = [335, 670, 1005, 1340, 1675, 2010, 2345, 2680, 3015, 3350];
    for (let i = 0; i < energyThresholds.length; i++) {
      if (energyKj > energyThresholds[i]) energyPoints = i + 1;
    }
  } else {
    const bevEnergyThresholds = [0, 30, 60, 90, 120, 150, 180, 210, 240, 270];
    for (let i = 0; i < bevEnergyThresholds.length; i++) {
      if (energyKj > bevEnergyThresholds[i]) energyPoints = i + 1;
    }
  }

  // Sugar points (0-15 solid, 0-10 beverage)
  let sugarPoints = 0;
  if (!isBeverage) {
    const sugarThresholds = [3.4, 6.8, 10, 13.5, 17, 20, 24, 27, 31, 34, 38, 41, 45, 48, 52];
    for (let i = 0; i < sugarThresholds.length; i++) {
      if (nutrient.sugar > sugarThresholds[i]) sugarPoints = i + 1;
    }
  } else {
    const bevSugarThresholds = [0, 1.5, 3.0, 4.5, 6.0, 7.5, 9.0, 10.5, 12.0, 13.5];
    for (let i = 0; i < bevSugarThresholds.length; i++) {
      if (nutrient.sugar > bevSugarThresholds[i]) sugarPoints = i + 1;
    }
  }

  // Saturated Fat points (0-10)
  let satFatPoints = 0;
  const satFatThresholds = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
  for (let i = 0; i < satFatThresholds.length; i++) {
    if (nutrient.saturatedFat > satFatThresholds[i]) satFatPoints = i + 1;
  }

  // Sodium points (0-10)
  let sodiumPoints = 0;
  const sodiumThresholds = [90, 180, 270, 360, 450, 540, 630, 720, 810, 900];
  for (let i = 0; i < sodiumThresholds.length; i++) {
    if (nutrient.sodium > sodiumThresholds[i]) sodiumPoints = i + 1;
  }

  const pointsN = energyPoints + sugarPoints + satFatPoints + sodiumPoints;

  // FVNL (Fruits, veggies, nuts, legumes %) (0-5)
  const fvnl = nutrient.fruitVegetablesLegumesPercent || 0;
  let fvnlPoints = 0;
  if (fvnl > 80) fvnlPoints = 5;
  else if (fvnl > 60) fvnlPoints = 2;
  else if (fvnl > 40) fvnlPoints = 1;

  // Fiber points (0-5)
  let fiberPoints = 0;
  const fiberThresholds = [0.9, 1.9, 2.8, 3.7, 4.7];
  for (let i = 0; i < fiberThresholds.length; i++) {
    if (nutrient.fiber > fiberThresholds[i]) fiberPoints = i + 1;
  }

  // Protein points (0-5)
  let proteinPoints = 0;
  const proteinThresholds = [1.6, 3.2, 4.8, 6.4, 8.0];
  for (let i = 0; i < proteinThresholds.length; i++) {
    if (nutrient.protein > proteinThresholds[i]) proteinPoints = i + 1;
  }

  let finalScore = 0;
  if (!isBeverage) {
    if (pointsN < 11 || fvnlPoints >= 5) {
      finalScore = pointsN - (fiberPoints + proteinPoints + fvnlPoints);
    } else {
      // High negative points restrict protein counting
      finalScore = pointsN - (fiberPoints + fvnlPoints);
    }
  } else {
    finalScore = pointsN - (fvnlPoints);
  }

  let grade = 'C';
  let trafficLight = 'yellow';
  let meaning = 'Moderate nutritional profile';

  if (!isBeverage) {
    if (finalScore <= -1) {
      grade = 'A';
      trafficLight = 'green';
      meaning = 'Best nutritional profile';
    } else if (finalScore <= 2) {
      grade = 'B';
      trafficLight = 'light-green';
      meaning = 'Good nutritional profile';
    } else if (finalScore <= 10) {
      grade = 'C';
      trafficLight = 'yellow';
      meaning = 'Moderate nutritional profile';
    } else if (finalScore <= 18) {
      grade = 'D';
      trafficLight = 'orange';
      meaning = 'Less favorable nutritional profile';
    } else {
      grade = 'E';
      trafficLight = 'red';
      meaning = 'Least favorable nutritional profile';
    }
  } else {
    if (finalScore <= 1) {
      grade = 'B';
      trafficLight = 'light-green';
      meaning = 'Good beverage profile';
    } else if (finalScore <= 5) {
      grade = 'C';
      trafficLight = 'yellow';
      meaning = 'Moderate beverage profile';
    } else if (finalScore <= 9) {
      grade = 'D';
      trafficLight = 'orange';
      meaning = 'High sugar/calorie beverage';
    } else {
      grade = 'E';
      trafficLight = 'red';
      meaning = 'Least favorable beverage profile';
    }
  }

  return {
    pointsN,
    pointsP: fiberPoints + proteinPoints + fvnlPoints,
    finalScore,
    grade,
    trafficLight,
    meaning,
    breakdown: {
      energyPoints,
      sugarPoints,
      satFatPoints,
      sodiumPoints,
      fiberPoints,
      proteinPoints,
      fvnlPoints
    }
  };
}

// 40 Snacks Dataset
const rawSnacks = [
  // --- JUNK / COMMONLY CONSUMED SNACKS (20 items) ---
  {
    id: 1,
    name: "Potato Chips",
    category: "Chips & Crisps",
    description: "Classic salted crispy thin potato slices fried in vegetable oil. Popular quick snack, heavily salted.",
    image: "https://images.unsplash.com/photo-1566478989037-eec170784d0b?w=600&auto=format&fit=crop&q=80",
    isHealthyAlternative: false,
    servingSizeDescription: "1 standard bag (50g)",
    servingSizeGrams: 50,
    priceINR: 20,
    tasteTexture: "Crispy, Salty, Savory",
    flavorNotes: "Crunchy thin potato slices seasoned with table salt and palm oil.",
    preparationMethod: "Deep Fried",
    hostelFriendly: true,
    prepTimeMinutes: 0,
    allergens: [],
    dataSource: "ICMR-NIN & USDA Food Data Central",
    lastVerified: "2026-11-01",
    nutrition: {
      calories: 536,
      totalFat: 34.6,
      saturatedFat: 11.2,
      carbohydrates: 53.0,
      sugar: 0.5,
      protein: 6.5,
      fiber: 4.4,
      sodium: 590,
      fruitVegetablesLegumesPercent: 0
    },
    suggestedAlternativeIds: [21, 22, 26]
  },
  {
    id: 2,
    name: "Samosa",
    category: "Street Food & Fried",
    description: "Deep-fried triangular maida pastry filled with spiced mashed potatoes, green peas, and whole spices.",
    image: "https://images.unsplash.com/photo-1601050690597-df0568f70950?w=600&auto=format&fit=crop&q=80",
    isHealthyAlternative: false,
    servingSizeDescription: "1 piece (85g)",
    servingSizeGrams: 85,
    priceINR: 15,
    tasteTexture: "Crispy crust, Soft spicy filling",
    flavorNotes: "Hot spiced potatoes with cumin and coriander in deep-fried refined wheat crust.",
    preparationMethod: "Deep Fried",
    hostelFriendly: true,
    prepTimeMinutes: 0,
    allergens: ["Gluten"],
    dataSource: "Indian Food Composition Tables (IFCT) 2017",
    lastVerified: "2026-11-01",
    nutrition: {
      calories: 308,
      totalFat: 17.5,
      saturatedFat: 6.8,
      carbohydrates: 32.4,
      sugar: 1.8,
      protein: 4.6,
      fiber: 2.1,
      sodium: 480,
      fruitVegetablesLegumesPercent: 20
    },
    suggestedAlternativeIds: [22, 33, 35]
  },
  {
    id: 3,
    name: "Cola Soft Drink",
    category: "Beverages",
    description: "Carbonated sweet beverage flavored with caramel, phosphoric acid, and caffeine.",
    image: "https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=600&auto=format&fit=crop&q=80",
    isHealthyAlternative: false,
    servingSizeDescription: "1 can (300ml)",
    servingSizeGrams: 300,
    priceINR: 40,
    tasteTexture: "Sweet, Fizzy, Chilled",
    flavorNotes: "High sugar effervescent soda with caramel aroma.",
    preparationMethod: "Bottled / Ready to Drink",
    hostelFriendly: true,
    prepTimeMinutes: 0,
    allergens: [],
    dataSource: "USDA Food Data Central",
    lastVerified: "2026-11-01",
    nutrition: {
      calories: 42,
      totalFat: 0,
      saturatedFat: 0,
      carbohydrates: 10.6,
      sugar: 10.6,
      protein: 0,
      fiber: 0,
      sodium: 12,
      fruitVegetablesLegumesPercent: 0
    },
    isBeverage: true,
    suggestedAlternativeIds: [23, 31, 40]
  },
  {
    id: 4,
    name: "Cream Biscuits",
    category: "Biscuits & Bakery",
    description: "Sandwich cookies filled with sweetened hydrogenated vegetable oil chocolate or vanilla cream.",
    image: "https://images.unsplash.com/photo-1558961363-fa8fdf82db35?w=600&auto=format&fit=crop&q=80",
    isHealthyAlternative: false,
    servingSizeDescription: "4 biscuits (45g)",
    servingSizeGrams: 45,
    priceINR: 30,
    tasteTexture: "Crunchy biscuit, Rich sugary cream",
    flavorNotes: "Refined maida crackers with sweet hydrogenated fat filling.",
    preparationMethod: "Commercially Baked",
    hostelFriendly: true,
    prepTimeMinutes: 0,
    allergens: ["Gluten", "Dairy", "Soy"],
    dataSource: "Open Food Facts & Brand Labels",
    lastVerified: "2026-11-01",
    nutrition: {
      calories: 495,
      totalFat: 21.8,
      saturatedFat: 10.5,
      carbohydrates: 69.2,
      sugar: 35.0,
      protein: 5.2,
      fiber: 2.3,
      sodium: 320,
      fruitVegetablesLegumesPercent: 0
    },
    suggestedAlternativeIds: [24, 29, 32]
  },
  {
    id: 5,
    name: "Instant Noodles",
    category: "Noodles & Quick Bites",
    description: "Pre-cooked flash-fried wheat noodle block accompanied by sodium-heavy spice tastemaker pouch.",
    image: "https://images.unsplash.com/photo-1612927601601-6638404737ce?w=600&auto=format&fit=crop&q=80",
    isHealthyAlternative: false,
    servingSizeDescription: "1 single pack (70g)",
    servingSizeGrams: 70,
    priceINR: 14,
    tasteTexture: "Soft, Slurpy, Spicy & Savory",
    flavorNotes: "Pungent onion-garlic masala spices with tender refined wheat noodles.",
    preparationMethod: "Palm Oil Flash Fried",
    hostelFriendly: true,
    prepTimeMinutes: 3,
    allergens: ["Gluten", "Soy"],
    dataSource: "Brand Nutrition Labels & IFCT",
    lastVerified: "2026-11-01",
    nutrition: {
      calories: 450,
      totalFat: 17.8,
      saturatedFat: 8.2,
      carbohydrates: 63.5,
      sugar: 2.8,
      protein: 8.8,
      fiber: 3.2,
      sodium: 1180,
      fruitVegetablesLegumesPercent: 0
    },
    suggestedAlternativeIds: [25, 26, 39]
  },
  {
    id: 6,
    name: "Fried Namkeen (Aloo Bhujia)",
    category: "Street Food & Fried",
    description: "Crunchy thin spiced noodles made of chickpea flour, potato flakes, and red chili, deep-fried in oil.",
    image: "https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?w=600&auto=format&fit=crop&q=80",
    isHealthyAlternative: false,
    servingSizeDescription: "1 small bowl (40g)",
    servingSizeGrams: 40,
    priceINR: 20,
    tasteTexture: "Super crunchy, Tangy, Spicy",
    flavorNotes: "Tangy citric amchur, black pepper, and spicy red chili fried crisps.",
    preparationMethod: "Deep Fried",
    hostelFriendly: true,
    prepTimeMinutes: 0,
    allergens: [],
    dataSource: "Indian Food Composition Tables",
    lastVerified: "2026-11-01",
    nutrition: {
      calories: 578,
      totalFat: 42.0,
      saturatedFat: 14.5,
      carbohydrates: 41.5,
      sugar: 3.2,
      protein: 8.5,
      fiber: 4.8,
      sodium: 780,
      fruitVegetablesLegumesPercent: 15
    },
    suggestedAlternativeIds: [26, 21, 39]
  },
  {
    id: 7,
    name: "French Fries",
    category: "Street Food & Fried",
    description: "Batonnet-cut potatoes deep-fried in vegetable oil until golden and crisp, seasoned with fine salt.",
    image: "https://images.unsplash.com/photo-1576107232684-1279f3908594?w=600&auto=format&fit=crop&q=80",
    isHealthyAlternative: false,
    servingSizeDescription: "Medium serving (110g)",
    servingSizeGrams: 110,
    priceINR: 90,
    tasteTexture: "Crisp outside, Soft inside, Salty",
    flavorNotes: "Golden fried potato batons with generous table salt.",
    preparationMethod: "Deep Fried",
    hostelFriendly: false,
    prepTimeMinutes: 10,
    allergens: [],
    dataSource: "USDA Food Data Central",
    lastVerified: "2026-11-01",
    nutrition: {
      calories: 312,
      totalFat: 15.2,
      saturatedFat: 2.8,
      carbohydrates: 41.4,
      sugar: 0.3,
      protein: 3.4,
      fiber: 3.8,
      sodium: 520,
      fruitVegetablesLegumesPercent: 0
    },
    suggestedAlternativeIds: [27, 21, 22]
  },
  {
    id: 8,
    name: "Chocolate Bar (Milk Chocolate)",
    category: "Chocolates & Sweets",
    description: "Solid confectionery slab made with cocoa butter, whole milk powder, and high refined sugar.",
    image: "https://images.unsplash.com/photo-1549007994-cb92caebd54b?w=600&auto=format&fit=crop&q=80",
    isHealthyAlternative: false,
    servingSizeDescription: "1 bar (45g)",
    servingSizeGrams: 45,
    priceINR: 40,
    tasteTexture: "Smooth, Melt-in-mouth, Sweet",
    flavorNotes: "Creamy cocoa with dominating sweetness from refined cane sugar.",
    preparationMethod: "Confectionery Conched",
    hostelFriendly: true,
    prepTimeMinutes: 0,
    allergens: ["Dairy", "Soy"],
    dataSource: "USDA Food Data Central",
    lastVerified: "2026-11-01",
    nutrition: {
      calories: 535,
      totalFat: 29.7,
      saturatedFat: 18.5,
      carbohydrates: 59.4,
      sugar: 51.5,
      protein: 7.6,
      fiber: 3.4,
      sodium: 79,
      fruitVegetablesLegumesPercent: 0
    },
    suggestedAlternativeIds: [28, 29, 30]
  },
  {
    id: 9,
    name: "Glazed Donut",
    category: "Biscuits & Bakery",
    description: "Deep-fried sweet yeast dough ring coated with a sugary glaze or chocolate frosting.",
    image: "https://images.unsplash.com/photo-1551024709-8f23befc6f87?w=600&auto=format&fit=crop&q=80",
    isHealthyAlternative: false,
    servingSizeDescription: "1 donut (60g)",
    servingSizeGrams: 60,
    priceINR: 50,
    tasteTexture: "Puffy, Soft, Sticky Sweet",
    flavorNotes: "Sweet fried brioche crumb coated in melted sugar syrup.",
    preparationMethod: "Deep Fried & Glazed",
    hostelFriendly: true,
    prepTimeMinutes: 0,
    allergens: ["Gluten", "Dairy", "Eggs"],
    dataSource: "USDA Food Data Central",
    lastVerified: "2026-11-01",
    nutrition: {
      calories: 421,
      totalFat: 22.1,
      saturatedFat: 10.4,
      carbohydrates: 50.8,
      sugar: 27.2,
      protein: 5.1,
      fiber: 1.8,
      sodium: 380,
      fruitVegetablesLegumesPercent: 0
    },
    suggestedAlternativeIds: [29, 32, 28]
  },
  {
    id: 10,
    name: "Candy / Chewy Drops",
    category: "Chocolates & Sweets",
    description: "Hard boiled sugar candies and jellies made with glucose syrup, synthetic colors, and artificial flavors.",
    image: "https://images.unsplash.com/photo-1582058091505-f87a2e55a40f?w=600&auto=format&fit=crop&q=80",
    isHealthyAlternative: false,
    servingSizeDescription: "5 pieces (30g)",
    servingSizeGrams: 30,
    priceINR: 10,
    tasteTexture: "Hard, Chewy, Ultra Sweet",
    flavorNotes: "Pure sugar rush with artificial fruit flavoring and tart citric acid.",
    preparationMethod: "Sugar Boiled",
    hostelFriendly: true,
    prepTimeMinutes: 0,
    allergens: [],
    dataSource: "USDA Food Data Central",
    lastVerified: "2026-11-01",
    nutrition: {
      calories: 394,
      totalFat: 0.2,
      saturatedFat: 0.1,
      carbohydrates: 98.0,
      sugar: 75.0,
      protein: 0.1,
      fiber: 0.0,
      sodium: 38,
      fruitVegetablesLegumesPercent: 0
    },
    suggestedAlternativeIds: [30, 29, 28]
  },
  {
    id: 11,
    name: "Energy Drink",
    category: "Beverages",
    description: "Caffeinated high-sugar carbonated drink with artificial taurine, guarana, and citric acid.",
    image: "https://images.unsplash.com/photo-1622543925917-763c34d1a86e?w=600&auto=format&fit=crop&q=80",
    isHealthyAlternative: false,
    servingSizeDescription: "1 can (250ml)",
    servingSizeGrams: 250,
    priceINR: 110,
    tasteTexture: "Sharp, Tangy, Fizzy, Sweet",
    flavorNotes: "Acidic citrus with punchy artificial sweet tang and stimulant buzz.",
    preparationMethod: "Ready to Drink",
    hostelFriendly: true,
    prepTimeMinutes: 0,
    allergens: [],
    dataSource: "Brand Nutrition Facts",
    lastVerified: "2026-11-01",
    nutrition: {
      calories: 46,
      totalFat: 0,
      saturatedFat: 0,
      carbohydrates: 11.0,
      sugar: 11.0,
      protein: 0.3,
      fiber: 0,
      sodium: 80,
      fruitVegetablesLegumesPercent: 0
    },
    isBeverage: true,
    suggestedAlternativeIds: [23, 31, 40]
  },
  {
    id: 12,
    name: "Packaged Fruit Cake",
    category: "Biscuits & Bakery",
    description: "Refined maida loaf cake studded with tutti-frutti pieces, palm fat, and preservatives.",
    image: "https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=600&auto=format&fit=crop&q=80",
    isHealthyAlternative: false,
    servingSizeDescription: "2 slices (60g)",
    servingSizeGrams: 60,
    priceINR: 25,
    tasteTexture: "Spongy, Sweet, Crumbly",
    flavorNotes: "Vanilla essence and sweet glazed fruit bits in vegetable fat sponge.",
    preparationMethod: "Industrial Baked",
    hostelFriendly: true,
    prepTimeMinutes: 0,
    allergens: ["Gluten", "Eggs", "Dairy"],
    dataSource: "Open Food Facts",
    lastVerified: "2026-11-01",
    nutrition: {
      calories: 410,
      totalFat: 16.5,
      saturatedFat: 7.9,
      carbohydrates: 61.0,
      sugar: 32.5,
      protein: 4.8,
      fiber: 1.2,
      sodium: 260,
      fruitVegetablesLegumesPercent: 5
    },
    suggestedAlternativeIds: [32, 29, 24]
  },
  {
    id: 13,
    name: "Fried Bread Pakora",
    category: "Street Food & Fried",
    description: "White bread triangles stuffed with spiced potatoes, dipped in gram flour batter and deep fried in oil.",
    image: "https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?w=600&auto=format&fit=crop&q=80",
    isHealthyAlternative: false,
    servingSizeDescription: "1 piece (120g)",
    servingSizeGrams: 120,
    priceINR: 20,
    tasteTexture: "Oily crunchy coating, Steaming spicy filling",
    flavorNotes: "Heavy fried gram flour batter with spiced potato mash and soaked vegetable oil.",
    preparationMethod: "Deep Fried",
    hostelFriendly: true,
    prepTimeMinutes: 0,
    allergens: ["Gluten"],
    dataSource: "IFCT 2017",
    lastVerified: "2026-11-01",
    nutrition: {
      calories: 285,
      totalFat: 15.8,
      saturatedFat: 5.6,
      carbohydrates: 30.5,
      sugar: 2.1,
      protein: 5.2,
      fiber: 2.5,
      sodium: 510,
      fruitVegetablesLegumesPercent: 10
    },
    suggestedAlternativeIds: [33, 35, 26]
  },
  {
    id: 14,
    name: "Salted Fried Peanuts",
    category: "Street Food & Fried",
    description: "Shelled peanuts fried in refined oil with thick sodium salt seasoning.",
    image: "https://images.unsplash.com/photo-1525253086316-d0c936c81468?w=600&auto=format&fit=crop&q=80",
    isHealthyAlternative: false,
    servingSizeDescription: "1 pouch (45g)",
    servingSizeGrams: 45,
    priceINR: 15,
    tasteTexture: "Crunchy, Very salty, Nutty",
    flavorNotes: "Oily crisp peanut crunch with sharp sodium bite.",
    preparationMethod: "Oil Fried",
    hostelFriendly: true,
    prepTimeMinutes: 0,
    allergens: ["Peanuts"],
    dataSource: "USDA Food Data Central",
    lastVerified: "2026-11-01",
    nutrition: {
      calories: 605,
      totalFat: 51.5,
      saturatedFat: 9.8,
      carbohydrates: 15.2,
      sugar: 4.1,
      protein: 24.5,
      fiber: 8.2,
      sodium: 840,
      fruitVegetablesLegumesPercent: 100
    },
    suggestedAlternativeIds: [34, 26, 21]
  },
  {
    id: 15,
    name: "Fast Food Pizza Slice",
    category: "Street Food & Fried",
    description: "Thick crust refined maida dough topped with processed mozzarella cheese, palm oil sauce, and salt.",
    image: "https://images.unsplash.com/photo-1513104890138-7c749659a591?w=600&auto=format&fit=crop&q=80",
    isHealthyAlternative: false,
    servingSizeDescription: "1 medium slice (105g)",
    servingSizeGrams: 105,
    priceINR: 120,
    tasteTexture: "Cheesy, Doughy, Savory",
    flavorNotes: "Melted cheese stretch with herbaceous tomato sauce and greasy dough crust.",
    preparationMethod: "High Heat Oven Baked",
    hostelFriendly: false,
    prepTimeMinutes: 15,
    allergens: ["Gluten", "Dairy"],
    dataSource: "USDA Food Data Central",
    lastVerified: "2026-11-01",
    nutrition: {
      calories: 272,
      totalFat: 10.4,
      saturatedFat: 4.8,
      carbohydrates: 32.5,
      sugar: 3.6,
      protein: 11.2,
      fiber: 2.1,
      sodium: 610,
      fruitVegetablesLegumesPercent: 12
    },
    suggestedAlternativeIds: [35, 36, 33]
  },
  {
    id: 16,
    name: "Fast Food Burger",
    category: "Street Food & Fried",
    description: "Refined flour burger bun sandwiching a fried spiced vegetable/potato patty, slathered in mayonnaise.",
    image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=600&auto=format&fit=crop&q=80",
    isHealthyAlternative: false,
    servingSizeDescription: "1 burger (150g)",
    servingSizeGrams: 150,
    priceINR: 80,
    tasteTexture: "Soft bun, Crunchy patty, Creamy sauce",
    flavorNotes: "Tangy mayonnaise with golden crumb fried potato patty in soft sweet bun.",
    preparationMethod: "Deep Fried Patty & Griddled Bun",
    hostelFriendly: true,
    prepTimeMinutes: 5,
    allergens: ["Gluten", "Dairy", "Soy"],
    dataSource: "Fast Food Brand Disclosures",
    lastVerified: "2026-11-01",
    nutrition: {
      calories: 288,
      totalFat: 13.5,
      saturatedFat: 4.2,
      carbohydrates: 36.2,
      sugar: 5.4,
      protein: 5.8,
      fiber: 2.8,
      sodium: 540,
      fruitVegetablesLegumesPercent: 15
    },
    suggestedAlternativeIds: [36, 35, 33]
  },
  {
    id: 17,
    name: "Sweetened Flavored Yogurt",
    category: "Dairy & Shakes",
    description: "Pasteurized milk curd blended with fruit pulp syrup and substantial quantities of refined sugar.",
    image: "https://images.unsplash.com/photo-1488477181946-6428a0291777?w=600&auto=format&fit=crop&q=80",
    isHealthyAlternative: false,
    servingSizeDescription: "1 cup (100g)",
    servingSizeGrams: 100,
    priceINR: 35,
    tasteTexture: "Creamy, Sweet, Fruity",
    flavorNotes: "Thick sweet dairy dessert flavored with mango or strawberry syrup.",
    preparationMethod: "Cultured & Sweetened",
    hostelFriendly: true,
    prepTimeMinutes: 0,
    allergens: ["Dairy"],
    dataSource: "Open Food Facts",
    lastVerified: "2026-11-01",
    nutrition: {
      calories: 112,
      totalFat: 3.1,
      saturatedFat: 2.0,
      carbohydrates: 17.5,
      sugar: 15.2,
      protein: 3.5,
      fiber: 0.2,
      sodium: 55,
      fruitVegetablesLegumesPercent: 8
    },
    suggestedAlternativeIds: [37, 30, 40]
  },
  {
    id: 18,
    name: "Sugary Breakfast Cereal",
    category: "Breakfast & Cereals",
    description: "Extruded processed corn flakes coated with high-fructose corn syrup and white sugar frosting.",
    image: "https://images.unsplash.com/photo-1521483451569-e33803c0330c?w=600&auto=format&fit=crop&q=80",
    isHealthyAlternative: false,
    servingSizeDescription: "1 bowl (40g)",
    servingSizeGrams: 40,
    priceINR: 30,
    tasteTexture: "Crisp, Sugary crunch",
    flavorNotes: "High sweet sugar-glazed corn grain flakes.",
    preparationMethod: "Extruded & Frosted",
    hostelFriendly: true,
    prepTimeMinutes: 1,
    allergens: [],
    dataSource: "USDA Food Data Central",
    lastVerified: "2026-11-01",
    nutrition: {
      calories: 388,
      totalFat: 1.2,
      saturatedFat: 0.3,
      carbohydrates: 87.5,
      sugar: 32.0,
      protein: 5.1,
      fiber: 2.4,
      sodium: 620,
      fruitVegetablesLegumesPercent: 0
    },
    suggestedAlternativeIds: [38, 24, 29]
  },
  {
    id: 19,
    name: "Potato Masala Wafers",
    category: "Chips & Crisps",
    description: "Ruffled crispy potato chips coated with red chili, chaat masala, and monosodium flavorings.",
    image: "https://images.unsplash.com/photo-1528750997573-59b89d56f4f7?w=600&auto=format&fit=crop&q=80",
    isHealthyAlternative: false,
    servingSizeDescription: "1 pack (45g)",
    servingSizeGrams: 45,
    priceINR: 20,
    tasteTexture: "Shatteringly crisp, Spicy, Salty",
    flavorNotes: "Spicy Indian chaat masala on deep-fried crisp wafers.",
    preparationMethod: "Deep Fried",
    hostelFriendly: true,
    prepTimeMinutes: 0,
    allergens: [],
    dataSource: "Open Food Facts",
    lastVerified: "2026-11-01",
    nutrition: {
      calories: 545,
      totalFat: 36.0,
      saturatedFat: 12.0,
      carbohydrates: 49.5,
      sugar: 2.5,
      protein: 6.2,
      fiber: 3.9,
      sodium: 710,
      fruitVegetablesLegumesPercent: 0
    },
    suggestedAlternativeIds: [21, 26, 22]
  },
  {
    id: 20,
    name: "Sugary Chocolate Milkshake",
    category: "Dairy & Shakes",
    description: "Bottled commercial milkshake loaded with cocoa powder, whole milk, stabilizers, and high cane sugar.",
    image: "https://images.unsplash.com/photo-1572490122747-3968b75cc699?w=600&auto=format&fit=crop&q=80",
    isHealthyAlternative: false,
    servingSizeDescription: "1 bottle (200ml)",
    servingSizeGrams: 200,
    priceINR: 40,
    tasteTexture: "Thick, Creamy, Rich sweet",
    flavorNotes: "Heavy sweet chocolate dairy beverage.",
    preparationMethod: "Sterilized Sweet Dairy",
    hostelFriendly: true,
    prepTimeMinutes: 0,
    allergens: ["Dairy"],
    dataSource: "Brand Nutrition Facts",
    lastVerified: "2026-11-01",
    nutrition: {
      calories: 94,
      totalFat: 3.2,
      saturatedFat: 2.1,
      carbohydrates: 13.8,
      sugar: 12.5,
      protein: 2.8,
      fiber: 0.6,
      sodium: 70,
      fruitVegetablesLegumesPercent: 0
    },
    isBeverage: true,
    suggestedAlternativeIds: [40, 31, 23]
  },

  // --- HEALTHIER ALTERNATIVES (20 items) ---
  {
    id: 21,
    name: "Roasted Makhana (Fox Nuts)",
    category: "Chips & Crisps",
    description: "Air-roasted popped lotus seeds roasted with a touch of ghee, Himalayan pink salt, and turmeric.",
    image: "https://images.unsplash.com/photo-1628088062854-d1870b4553da?w=600&auto=format&fit=crop&q=80",
    isHealthyAlternative: true,
    servingSizeDescription: "1 medium bowl (35g)",
    servingSizeGrams: 35,
    priceINR: 25,
    tasteTexture: "Crispy, Airy, Lightly Salty",
    flavorNotes: "Puffy airy crunch with earthy savory salt and black pepper.",
    preparationMethod: "Air Roasted / Dry Toasted",
    hostelFriendly: true,
    prepTimeMinutes: 3,
    allergens: [],
    dataSource: "ICMR-NIN Food Composition Database",
    lastVerified: "2026-11-01",
    nutrition: {
      calories: 362,
      totalFat: 2.2,
      saturatedFat: 0.4,
      carbohydrates: 76.8,
      sugar: 0.8,
      protein: 9.7,
      fiber: 7.6,
      sodium: 180,
      fruitVegetablesLegumesPercent: 100
    },
    swapReasons: "Cuts 93% fat and 70% sodium while matching the crispy crunch of potato chips!"
  },
  {
    id: 22,
    name: "Baked Soya Crisps",
    category: "Chips & Crisps",
    description: "Protein-dense crisps made from defatted soya flour and brown rice, seasoned with pudina masala.",
    image: "https://images.unsplash.com/photo-1541592106381-b31e9677c0e5?w=600&auto=format&fit=crop&q=80",
    isHealthyAlternative: true,
    servingSizeDescription: "1 packet (40g)",
    servingSizeGrams: 40,
    priceINR: 30,
    tasteTexture: "Crunchy, Savory, Minty Spice",
    flavorNotes: "Hearty crisp bite with refreshing mint and chatpata cumin.",
    preparationMethod: "Oven Baked",
    hostelFriendly: true,
    prepTimeMinutes: 0,
    allergens: ["Soy"],
    dataSource: "USDA & Laboratory Assays",
    lastVerified: "2026-11-01",
    nutrition: {
      calories: 382,
      totalFat: 6.5,
      saturatedFat: 1.1,
      carbohydrates: 58.0,
      sugar: 2.1,
      protein: 23.0,
      fiber: 9.2,
      sodium: 290,
      fruitVegetablesLegumesPercent: 65
    },
    swapReasons: "Delivers 4x the protein of fried chips with 80% less saturated fat."
  },
  {
    id: 23,
    name: "Unsweetened Lemon Mint Water (Nimbu Pani)",
    category: "Beverages",
    description: "Freshly squeezed lemon juice in chilled water infused with fresh garden mint leaves and black rock salt.",
    image: "https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?w=600&auto=format&fit=crop&q=80",
    isHealthyAlternative: true,
    servingSizeDescription: "1 tall glass (300ml)",
    servingSizeGrams: 300,
    priceINR: 10,
    tasteTexture: "Tangy, Crisp, Refreshing",
    flavorNotes: "Zesty real citrus with herbal mint fragrance and mineral rock salt.",
    preparationMethod: "Fresh Mixed",
    hostelFriendly: true,
    prepTimeMinutes: 2,
    allergens: [],
    dataSource: "IFCT 2017",
    lastVerified: "2026-11-01",
    nutrition: {
      calories: 8,
      totalFat: 0.1,
      saturatedFat: 0,
      carbohydrates: 1.8,
      sugar: 0.4,
      protein: 0.2,
      fiber: 0.3,
      sodium: 45,
      fruitVegetablesLegumesPercent: 15
    },
    isBeverage: true,
    swapReasons: "Zero added sugar, 80% fewer calories than soda, and rich in natural Vitamin C!"
  },
  {
    id: 24,
    name: "Plain Rolled Oats with Berries & Almonds",
    category: "Biscuits & Bakery",
    description: "100% whole grain rolled oats soaked in warm water/milk, topped with dried cranberries and crushed almonds.",
    image: "https://images.unsplash.com/photo-1584776296944-ab6fb57b0bdd?w=600&auto=format&fit=crop&q=80",
    isHealthyAlternative: true,
    servingSizeDescription: "1 bowl (50g dry oats + toppings)",
    servingSizeGrams: 60,
    priceINR: 20,
    tasteTexture: "Hearty, Soft, Chewy, Naturally nutty",
    flavorNotes: "Comforting toasted oat aroma with tart berry pops and crunchy almonds.",
    preparationMethod: "Boiled / Steamed",
    hostelFriendly: true,
    prepTimeMinutes: 3,
    allergens: ["Tree Nuts"],
    dataSource: "USDA Food Data Central",
    lastVerified: "2026-11-01",
    nutrition: {
      calories: 380,
      totalFat: 7.2,
      saturatedFat: 1.2,
      carbohydrates: 62.5,
      sugar: 4.8,
      protein: 13.5,
      fiber: 10.4,
      sodium: 15,
      fruitVegetablesLegumesPercent: 30
    },
    swapReasons: "Cuts 85% free sugars compared to cream biscuits, loaded with beta-glucan fiber."
  },
  {
    id: 25,
    name: "Vegetable Whole-Wheat Masala Noodles",
    category: "Noodles & Quick Bites",
    description: "Air-dried 100% atta noodles tossed with finely diced carrots, green peas, capsicum, and low-sodium spices.",
    image: "https://images.unsplash.com/photo-1552611052-33e04de081de?w=600&auto=format&fit=crop&q=80",
    isHealthyAlternative: true,
    servingSizeDescription: "1 bowl prepared (120g)",
    servingSizeGrams: 120,
    priceINR: 25,
    tasteTexture: "Warm, Slurpy, Hearty vegetable crunch",
    flavorNotes: "Authentic Indian masala aroma packed with crunchy carrots and sweet peas.",
    preparationMethod: "Air-Dried Whole Wheat & Steamed",
    hostelFriendly: true,
    prepTimeMinutes: 5,
    allergens: ["Gluten"],
    dataSource: "IFCT 2017 & Brand Specifications",
    lastVerified: "2026-11-01",
    nutrition: {
      calories: 335,
      totalFat: 3.2,
      saturatedFat: 0.6,
      carbohydrates: 64.0,
      sugar: 3.1,
      protein: 12.0,
      fiber: 8.5,
      sodium: 380,
      fruitVegetablesLegumesPercent: 40
    },
    swapReasons: "Saves 68% sodium and 82% saturated fat while giving the same comforting noodle bowl."
  },
  {
    id: 26,
    name: "Roasted Chana (Bengal Gram)",
    category: "Street Food & Fried",
    description: "Traditional sand-roasted brown chickpeas with skins intact, lightly seasoned with jeera and kala namak.",
    image: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=600&auto=format&fit=crop&q=80",
    isHealthyAlternative: true,
    servingSizeDescription: "1 handful (40g)",
    servingSizeGrams: 40,
    priceINR: 12,
    tasteTexture: "Crunchy, Nutty, Earthy",
    flavorNotes: "Pleasantly nutty toasted legume crunch with digestive cumin salt.",
    preparationMethod: "Sand Roasted / Dry Heat",
    hostelFriendly: true,
    prepTimeMinutes: 0,
    allergens: [],
    dataSource: "ICMR-NIN Food Composition Tables",
    lastVerified: "2026-11-01",
    nutrition: {
      calories: 369,
      totalFat: 5.3,
      saturatedFat: 0.7,
      carbohydrates: 58.1,
      sugar: 2.2,
      protein: 18.6,
      fiber: 15.2,
      sodium: 140,
      fruitVegetablesLegumesPercent: 100
    },
    swapReasons: "Zero palm oil, 3x the fiber of namkeen, and a massive 18g plant protein punch!"
  },
  {
    id: 27,
    name: "Baked Sweet Potato Wedges",
    category: "Street Food & Fried",
    description: "Thick skin-on sweet potato wedges lightly brushed with cold-pressed olive oil, rosemary, and sea salt.",
    image: "https://images.unsplash.com/photo-1573080496219-bb080dd4f877?w=600&auto=format&fit=crop&q=80",
    isHealthyAlternative: true,
    servingSizeDescription: "1 medium plate (110g)",
    servingSizeGrams: 110,
    priceINR: 35,
    tasteTexture: "Crisp edges, Tender sweet center",
    flavorNotes: "Naturally caramelized sweet earthy root potato with herb aroma.",
    preparationMethod: "Oven Baked",
    hostelFriendly: false,
    prepTimeMinutes: 20,
    allergens: [],
    dataSource: "USDA Food Data Central",
    lastVerified: "2026-11-01",
    nutrition: {
      calories: 142,
      totalFat: 3.5,
      saturatedFat: 0.5,
      carbohydrates: 25.8,
      sugar: 6.2,
      protein: 2.2,
      fiber: 4.1,
      sodium: 120,
      fruitVegetablesLegumesPercent: 100
    },
    swapReasons: "54% fewer calories and 75% less sodium than deep fried restaurant fries."
  },
  {
    id: 28,
    name: "Dark Chocolate Cocoa Bites (75%)",
    category: "Chocolates & Sweets",
    description: "Rich bittersweet single-origin dark chocolate nibs crafted with minimal unrefined jaggery/cane sugar.",
    image: "https://images.unsplash.com/photo-1511381939415-e44015466834?w=600&auto=format&fit=crop&q=80",
    isHealthyAlternative: true,
    servingSizeDescription: "3 small squares (25g)",
    servingSizeGrams: 25,
    priceINR: 35,
    tasteTexture: "Intense, Smooth, Bittersweet",
    flavorNotes: "Deep roasted cocoa richness with subtle fruity undertones and mild sweetness.",
    preparationMethod: "Conched Artisan",
    hostelFriendly: true,
    prepTimeMinutes: 0,
    allergens: ["Soy"],
    dataSource: "USDA Food Data Central",
    lastVerified: "2026-11-01",
    nutrition: {
      calories: 520,
      totalFat: 38.0,
      saturatedFat: 21.0,
      carbohydrates: 36.0,
      sugar: 18.0,
      protein: 8.8,
      fiber: 11.5,
      sodium: 20,
      fruitVegetablesLegumesPercent: 75
    },
    swapReasons: "65% less sugar than commercial milk chocolate, rich in heart-healthy flavonoids and fiber."
  },
  {
    id: 29,
    name: "Homemade Oat & Date Energy Bites",
    category: "Chocolates & Sweets",
    description: "No-bake wholesome truffle balls made from rolled oats, Medjool dates, chia seeds, and crushed nuts.",
    image: "https://images.unsplash.com/photo-1541832676-9b763b0239ab?w=600&auto=format&fit=crop&q=80",
    isHealthyAlternative: true,
    servingSizeDescription: "2 bites (40g)",
    servingSizeGrams: 40,
    priceINR: 20,
    tasteTexture: "Soft, Fudgy, Chewy, Nutty",
    flavorNotes: "Natural caramel sweetness from ripe dates paired with toasted rolled oats.",
    preparationMethod: "Raw Rolled / No Bake",
    hostelFriendly: true,
    prepTimeMinutes: 5,
    allergens: ["Tree Nuts"],
    dataSource: "Laboratory Composite & USDA",
    lastVerified: "2026-11-01",
    nutrition: {
      calories: 340,
      totalFat: 9.8,
      saturatedFat: 1.5,
      carbohydrates: 54.0,
      sugar: 22.0,
      protein: 9.2,
      fiber: 8.8,
      sodium: 35,
      fruitVegetablesLegumesPercent: 55
    },
    swapReasons: "100% natural sugars with zero trans fats or refined flour. Keeps energy sustained for hours."
  },
  {
    id: 30,
    name: "Fresh Fruit Chaat Bowl",
    category: "Chocolates & Sweets",
    description: "Crisp fresh diced apple, ripe papaya, crunchy guava, and pomegranate arils with chatpata rock salt.",
    image: "https://images.unsplash.com/photo-1519996529931-28324d5a630e?w=600&auto=format&fit=crop&q=80",
    isHealthyAlternative: true,
    servingSizeDescription: "1 large bowl (150g)",
    servingSizeGrams: 150,
    priceINR: 30,
    tasteTexture: "Juicy, Crunchy, Sweet & Tangy",
    flavorNotes: "Bursting with juicy natural fruit sugars balanced by savory amchur spice.",
    preparationMethod: "Fresh Cut",
    hostelFriendly: true,
    prepTimeMinutes: 3,
    allergens: [],
    dataSource: "IFCT 2017",
    lastVerified: "2026-11-01",
    nutrition: {
      calories: 58,
      totalFat: 0.3,
      saturatedFat: 0.1,
      carbohydrates: 14.2,
      sugar: 10.5,
      protein: 0.9,
      fiber: 3.2,
      sodium: 65,
      fruitVegetablesLegumesPercent: 100
    },
    swapReasons: "Replaces processed candy chemicals with living enzymes, natural antioxidants, and hydration."
  },
  {
    id: 31,
    name: "Spiced Masala Buttermilk (Chaas)",
    category: "Beverages",
    description: "Traditional churned curd beverage with roasted cumin powder, fresh ginger, green coriander, and rock salt.",
    image: "https://images.unsplash.com/photo-1550583724-b2692b85b150?w=600&auto=format&fit=crop&q=80",
    isHealthyAlternative: true,
    servingSizeDescription: "1 tall glass (250ml)",
    servingSizeGrams: 250,
    priceINR: 15,
    tasteTexture: "Smooth, Cooling, Savory & Tangy",
    flavorNotes: "Herbaceous cilantro and warming roasted jeera in cooling probiotic yogurt whey.",
    preparationMethod: "Fresh Churned",
    hostelFriendly: true,
    prepTimeMinutes: 2,
    allergens: ["Dairy"],
    dataSource: "IFCT 2017",
    lastVerified: "2026-11-01",
    nutrition: {
      calories: 32,
      totalFat: 1.1,
      saturatedFat: 0.7,
      carbohydrates: 3.5,
      sugar: 2.8,
      protein: 2.1,
      fiber: 0.2,
      sodium: 120,
      fruitVegetablesLegumesPercent: 5
    },
    isBeverage: true,
    swapReasons: "Probiotic digestive goodness with 75% fewer calories and zero artificial stimulants."
  },
  {
    id: 32,
    name: "Banana Oat Healthy Snack Muffin",
    category: "Biscuits & Bakery",
    description: "Baked treat prepared with ripe mashed bananas, powdered rolled oats, cinnamon, and zero refined white sugar.",
    image: "https://images.unsplash.com/photo-1586985289688-ca3cf47d3e6e?w=600&auto=format&fit=crop&q=80",
    isHealthyAlternative: true,
    servingSizeDescription: "1 muffin (60g)",
    servingSizeGrams: 60,
    priceINR: 25,
    tasteTexture: "Moist, Tender, Comfortingly sweet",
    flavorNotes: "Fragrant Ceylon cinnamon with deep banana sweetness and wholesome toasted oats.",
    preparationMethod: "Oven Baked Whole Grain",
    hostelFriendly: true,
    prepTimeMinutes: 0,
    allergens: ["Gluten"],
    dataSource: "USDA Food Data Central",
    lastVerified: "2026-11-01",
    nutrition: {
      calories: 215,
      totalFat: 4.8,
      saturatedFat: 0.9,
      carbohydrates: 38.5,
      sugar: 12.0,
      protein: 6.2,
      fiber: 4.5,
      sodium: 130,
      fruitVegetablesLegumesPercent: 35
    },
    swapReasons: "Halves the sugar of packaged cakes while doubling dietary fiber and ditching palm shortening."
  },
  {
    id: 33,
    name: "Baked Vegetable Paneer Cutlet",
    category: "Street Food & Fried",
    description: "Low-fat cottage cheese, grated beetroot, peas, and carrots patties baked golden in an air oven.",
    image: "https://images.unsplash.com/photo-1589301760014-d929f3979dbc?w=600&auto=format&fit=crop&q=80",
    isHealthyAlternative: true,
    servingSizeDescription: "2 patties (100g)",
    servingSizeGrams: 100,
    priceINR: 40,
    tasteTexture: "Crisp crust, Soft hearty spiced interior",
    flavorNotes: "Savory paneer richness accented by sweet beetroot and green chilies.",
    preparationMethod: "Oven Baked / Air Fried",
    hostelFriendly: true,
    prepTimeMinutes: 5,
    allergens: ["Dairy"],
    dataSource: "IFCT 2017 & Culinary Lab",
    lastVerified: "2026-11-01",
    nutrition: {
      calories: 182,
      totalFat: 6.2,
      saturatedFat: 2.3,
      carbohydrates: 21.0,
      sugar: 2.8,
      protein: 10.5,
      fiber: 4.8,
      sodium: 240,
      fruitVegetablesLegumesPercent: 60
    },
    swapReasons: "60% less fat than fried pakoras, 2x higher protein from fresh paneer."
  },
  {
    id: 34,
    name: "Dry Roasted Unsalted Peanuts",
    category: "Street Food & Fried",
    description: "Pure whole red-skin peanuts dry roasted in heated air ovens with zero added cooking oils and zero salt.",
    image: "https://images.unsplash.com/photo-1525253086316-d0c936c81468?w=600&auto=format&fit=crop&q=80",
    isHealthyAlternative: true,
    servingSizeDescription: "1 handful (35g)",
    servingSizeGrams: 35,
    priceINR: 15,
    tasteTexture: "Crunchy, Toasty, Earthy",
    flavorNotes: "Pure roasted nutty richness without greasy oil film.",
    preparationMethod: "Dry Roasted",
    hostelFriendly: true,
    prepTimeMinutes: 0,
    allergens: ["Peanuts"],
    dataSource: "USDA Food Data Central",
    lastVerified: "2026-11-01",
    nutrition: {
      calories: 585,
      totalFat: 49.7,
      saturatedFat: 6.8,
      carbohydrates: 16.1,
      sugar: 4.2,
      protein: 26.0,
      fiber: 9.4,
      sodium: 18,
      fruitVegetablesLegumesPercent: 100
    },
    swapReasons: "Eliminates 98% of sodium compared to fried salted nuts, providing natural monounsaturated fats."
  },
  {
    id: 35,
    name: "Whole-Wheat Vegetable Paneer Sandwich",
    category: "Street Food & Fried",
    description: "100% whole grain bread stuffed with fresh low-fat paneer slices, cucumber, tomatoes, and homemade coriander chutney.",
    image: "https://images.unsplash.com/photo-1528735602780-2552fd46c7af?w=600&auto=format&fit=crop&q=80",
    isHealthyAlternative: true,
    servingSizeDescription: "1 whole sandwich (140g)",
    servingSizeGrams: 140,
    priceINR: 45,
    tasteTexture: "Toasted crunchy bread, Cool crisp veggies, Tender paneer",
    flavorNotes: "Zesty mint chutney kick paired with clean dairy notes and crisp garden vegetables.",
    preparationMethod: "Tawa Toasted (Dry / Minimal Ghee)",
    hostelFriendly: true,
    prepTimeMinutes: 5,
    allergens: ["Gluten", "Dairy"],
    dataSource: "IFCT 2017",
    lastVerified: "2026-11-01",
    nutrition: {
      calories: 198,
      totalFat: 5.4,
      saturatedFat: 2.1,
      carbohydrates: 25.6,
      sugar: 2.9,
      protein: 11.8,
      fiber: 5.2,
      sodium: 260,
      fruitVegetablesLegumesPercent: 45
    },
    swapReasons: "Replaces processed cheese and bleached dough with complex whole wheat and fresh veggies."
  },
  {
    id: 36,
    name: "Grilled Multigrain Paneer Wrap",
    category: "Street Food & Fried",
    description: "Wholesome multigrain flatbread rolled with marinated tandoori cottage cheese cubes, shredded cabbage, and yogurt dressing.",
    image: "https://images.unsplash.com/photo-1626700051175-6818013e1d4f?w=600&auto=format&fit=crop&q=80",
    isHealthyAlternative: true,
    servingSizeDescription: "1 wrap (160g)",
    servingSizeGrams: 160,
    priceINR: 65,
    tasteTexture: "Warm soft wrap, Smoky spiced filling, Crisp veggies",
    flavorNotes: "Smoky tandoori spices balanced by cool hung curd mint sauce.",
    preparationMethod: "Dry Griddled Wrap",
    hostelFriendly: true,
    prepTimeMinutes: 8,
    allergens: ["Gluten", "Dairy"],
    dataSource: "IFCT 2017 & Culinary Specifications",
    lastVerified: "2026-11-01",
    nutrition: {
      calories: 215,
      totalFat: 6.8,
      saturatedFat: 2.4,
      carbohydrates: 26.5,
      sugar: 3.2,
      protein: 13.5,
      fiber: 5.8,
      sodium: 310,
      fruitVegetablesLegumesPercent: 40
    },
    swapReasons: "Cuts out deep-fried burger patties and heavy mayo, boosting protein to 13.5g."
  },
  {
    id: 37,
    name: "Plain Curd / Greek Yogurt with Chia Seeds",
    category: "Dairy & Shakes",
    description: "Thick unsweetened strained probiotic curd topped with hydrated chia seeds and a drizzle of raw honey.",
    image: "https://images.unsplash.com/photo-1488477181946-6428a0291777?w=600&auto=format&fit=crop&q=80",
    isHealthyAlternative: true,
    servingSizeDescription: "1 bowl (120g)",
    servingSizeGrams: 120,
    priceINR: 25,
    tasteTexture: "Silky smooth, Creamy, Gentle chia pop",
    flavorNotes: "Clean refreshing lactic tang with pleasant botanical floral honey sweetness.",
    preparationMethod: "Natural Strained Culture",
    hostelFriendly: true,
    prepTimeMinutes: 1,
    allergens: ["Dairy"],
    dataSource: "USDA & IFCT 2017",
    lastVerified: "2026-11-01",
    nutrition: {
      calories: 88,
      totalFat: 3.2,
      saturatedFat: 1.8,
      carbohydrates: 6.5,
      sugar: 4.5,
      protein: 8.5,
      fiber: 2.5,
      sodium: 48,
      fruitVegetablesLegumesPercent: 10
    },
    swapReasons: "70% less sugar than commercial flavored yogurts, with double the protein and active probiotics."
  },
  {
    id: 38,
    name: "Rolled Oats with Chia & Walnuts",
    category: "Breakfast & Cereals",
    description: "Unsweetened toasted rolled oats combined with omega-3 rich chia seeds and cracked Kashmiri walnuts.",
    image: "https://images.unsplash.com/photo-1517673132405-a56a62b18caf?w=600&auto=format&fit=crop&q=80",
    isHealthyAlternative: true,
    servingSizeDescription: "1 bowl (45g)",
    servingSizeGrams: 45,
    priceINR: 25,
    tasteTexture: "Crisp, Nutty, Earthy crunch",
    flavorNotes: "Toasty grain aroma with rich walnut crunch and zero sugar coating.",
    preparationMethod: "Dry Toasted",
    hostelFriendly: true,
    prepTimeMinutes: 1,
    allergens: ["Tree Nuts"],
    dataSource: "USDA Food Data Central",
    lastVerified: "2026-11-01",
    nutrition: {
      calories: 395,
      totalFat: 9.8,
      saturatedFat: 1.4,
      carbohydrates: 59.0,
      sugar: 1.8,
      protein: 14.2,
      fiber: 11.2,
      sodium: 18,
      fruitVegetablesLegumesPercent: 25
    },
    swapReasons: "Eliminates 30g of frosting sugar, delivering sustainable slow-release energy for study sessions."
  },
  {
    id: 39,
    name: "Roasted Spiced Kala Chana (Black Chickpeas)",
    category: "Chips & Crisps",
    description: "Crunchy roasted whole Indian desi black chickpeas tossed with amchur, black salt, and a pinch of roasted jeera.",
    image: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=600&auto=format&fit=crop&q=80",
    isHealthyAlternative: true,
    servingSizeDescription: "1 mini pouch (40g)",
    servingSizeGrams: 40,
    priceINR: 10,
    tasteTexture: "Hard crisp crunch, Savory, Chatpata",
    flavorNotes: "Intensely crunchy legume with zesty dried mango and black salt notes.",
    preparationMethod: "Dry Roasted",
    hostelFriendly: true,
    prepTimeMinutes: 0,
    allergens: [],
    dataSource: "ICMR-NIN Food Composition Database",
    lastVerified: "2026-11-01",
    nutrition: {
      calories: 360,
      totalFat: 4.8,
      saturatedFat: 0.6,
      carbohydrates: 57.5,
      sugar: 1.9,
      protein: 19.5,
      fiber: 16.8,
      sodium: 190,
      fruitVegetablesLegumesPercent: 100
    },
    swapReasons: "Costs only ₹10, packs 19.5g protein and massive fiber while satisfying spicy wafer cravings."
  },
  {
    id: 40,
    name: "Banana Peanut Butter Milk Smoothie",
    category: "Dairy & Shakes",
    description: "Ripe banana blended with cold milk, 1 spoonful of pure peanut butter, and a dash of cinnamon. No refined sugar.",
    image: "https://images.unsplash.com/photo-1553530666-ba11a7da3888?w=600&auto=format&fit=crop&q=80",
    isHealthyAlternative: true,
    servingSizeDescription: "1 glass (250ml)",
    servingSizeGrams: 250,
    priceINR: 30,
    tasteTexture: "Thick, Creamy, Naturally sweet",
    flavorNotes: "Velvety roasted peanut butter and naturally sweet ripe banana with creamy dairy base.",
    preparationMethod: "Fresh Blended",
    hostelFriendly: true,
    prepTimeMinutes: 3,
    allergens: ["Dairy", "Peanuts"],
    dataSource: "USDA Food Data Central",
    lastVerified: "2026-11-01",
    nutrition: {
      calories: 82,
      totalFat: 2.8,
      saturatedFat: 0.9,
      carbohydrates: 10.8,
      sugar: 6.2,
      protein: 4.2,
      fiber: 1.5,
      sodium: 42,
      fruitVegetablesLegumesPercent: 30
    },
    isBeverage: true,
    swapReasons: "Zero refined white sugar or artificial syrups. Real potassium, healthy fats, and sustained satiety."
  }
];

// Enrich snacks with Nutri-Score, warnings, and highlights
const processedSnacks = rawSnacks.map(snack => {
  const scoreResult = calculateNutriScore(snack.nutrition, snack.isBeverage, snack.isWater);
  
  // Health warnings
  const warnings = [];
  if (snack.nutrition.sodium >= 500) warnings.push({ type: 'sodium', text: 'High Sodium (>500mg/100g)' });
  if (snack.nutrition.saturatedFat >= 5.0) warnings.push({ type: 'satFat', text: 'High Saturated Fat (>5g/100g)' });
  if (snack.nutrition.sugar >= 12.0) warnings.push({ type: 'sugar', text: 'High Sugar (>12g/100g)' });
  if (snack.nutrition.calories >= 450) warnings.push({ type: 'calories', text: 'High Caloric Density (>450 kcal/100g)' });

  // Positive highlights
  const highlights = [];
  if (snack.nutrition.protein >= 10.0) highlights.push({ type: 'protein', text: 'High Protein (>10g/100g)' });
  if (snack.nutrition.fiber >= 5.0) highlights.push({ type: 'fiber', text: 'High Dietary Fiber (>5g/100g)' });
  if (snack.nutrition.sugar <= 3.0) highlights.push({ type: 'sugar', text: 'Low Sugar (<3g/100g)' });
  if (snack.nutrition.saturatedFat <= 1.5) highlights.push({ type: 'satFat', text: 'Low Saturated Fat (<1.5g/100g)' });
  if (snack.hostelFriendly) highlights.push({ type: 'hostel', text: 'Hostel Friendly (Quick Prep)' });

  return {
    ...snack,
    healthScore: scoreResult.finalScore,
    healthGrade: scoreResult.grade,
    trafficLight: scoreResult.trafficLight,
    gradeMeaning: scoreResult.meaning,
    scoringBreakdown: scoreResult.breakdown,
    warnings,
    highlights
  };
});

fs.writeFileSync(
  path.join(__dirname, '../dataset/snacks.json'),
  JSON.stringify(processedSnacks, null, 2),
  'utf-8'
);

console.log(`Successfully generated ${processedSnacks.length} snacks with official Nutri-Score grades in dataset/snacks.json`);

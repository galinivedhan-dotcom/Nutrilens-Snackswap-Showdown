# 🍎 NutriLens: SnackSwap Showdown

> **"See What's Inside. Swap What's Better."**  
> *A full-stack smart nutrition comparison and taste-matched food swap platform engineered for college students and young professionals.*

---

## 🌟 Hackathon Project Highlights

- **Track / Theme**: HealthTech & AI-Inspired Recommendations
- **Type**: Full-Stack Web Application (Frontend + Backend + Embedded SQLite Database)
- **Status**: Production-ready & fully functional with all **10 major modules** implemented

---

## 📌 The Problem We Solve

1. **Packaged & Street Food Epidemic**: College students and young professionals frequently consume ultra-processed snacks (potato chips, instant fried noodles, samosas, sodas, biscuits).
2. **Deceptive & Intimidating Food Labels**: Serving sizes, percentages, and hidden sugars on food packaging are difficult to decipher without a nutrition degree.
3. **No Direct, Guilt-Free Alternatives**: Generic health advice often tells students to "just eat a salad", ignoring sensory cravings for crispy, crunchy, or savory textures.
4. **Hostel & Budget Constraints**: Most college students have no stove, only a kettle or mug, and a strict daily budget (< ₹30/snack).
5. **Zero Habit Tracking**: There is no easy way to track cumulative calorie and sodium savings over time.

---

## 💡 The NutriLens Solution

NutriLens transforms complex nutrition data into **transparent A–E health grades**, offers **sensory-matched alternatives** (taste, texture, and student budget), delivers **instant side-by-side nutritional diffs**, and gamifies conscious snacking with a **7-Day SnackSwap Challenge** and persistent swap logs.

---

## 🏗️ System Architecture

```mermaid
flowchart TD
    subgraph Frontend ["React 18 + TypeScript + Tailwind CSS"]
        UI[Home Page & Search]
        Explorer[40-Snack Nutrition Explorer]
        Details[Nutrition Facts & Grade Breakdown]
        Recommender[Taste-Matched Swap Engine]
        Comparison[Side-by-Side Diff & Chart.js]
        Dashboard[My Swaps Analytics & Timeline]
        Challenges[7-Day Challenge & Badges]
        HostelHacks[Hostel Room Hacks (< ₹30)]
        Scanner[Barcode Scanner & OFF API]
    end

    subgraph Backend ["Node.js + Express REST API"]
        SnackCtrl[Snack Controller]
        GradingSvc[Nutri-Score Scoring Engine]
        RecSvc[Euclidean Distance & Weighted Ranking]
        DiffSvc[Nutritional Diff & Exercise Equivalency]
        SwapCtrl[Swap Logger & Progress Aggregator]
        ScannerCtrl[Open Food Facts Lookup Service]
    end

    subgraph Database ["SQLite (DatabaseSync)"]
        T1[(snacks)]
        T2[(nutritional_profiles)]
        T3[(scoring_breakdown)]
        T4[(swap_rules)]
        T5[(user_swap_logs)]
        T6[(challenges)]
    end

    UI --> SnackCtrl
    Explorer --> SnackCtrl
    Details --> GradingSvc
    Recommender --> RecSvc
    Comparison --> DiffSvc
    Dashboard --> SwapCtrl
    Challenges --> SwapCtrl
    Scanner --> ScannerCtrl

    SnackCtrl --> T1
    SnackCtrl --> T2
    GradingSvc --> T3
    RecSvc --> T4
    SwapCtrl --> T5
    SwapCtrl --> T6
```

---

## 📦 The 10 Complete Application Modules

| No. | Module | Key Features & Implementation |
|---|---|---|
| **01** | **Home Page** | Interactive search bar, quick popular craving chips, live demo banner (Chips → Makhana), 5-step user journey, and challenge preview. |
| **02** | **Snack Nutrition Lookup** | 40-snack verified dataset (20 junk/craving vs 20 healthy swaps), category filters, sorting by calories/protein/grade, standard vs serving size toggle. |
| **03** | **Health Grading Engine** | Standardized **Nutri-Score** algorithm (Points N negative for energy, sugar, saturated fat, sodium; Points P positive for fiber, protein, fruits/legumes); Grade A–E traffic light system. |
| **04** | **Healthy Snack Recommender** | Vector-based recommendation algorithm factoring in Euclidean distance, taste & texture similarity, student budget (₹), and hostel convenience. |
| **05** | **Side-by-Side Comparison** | Direct head-to-head showdown with net differences (kcal, sat fat, sugar, sodium, protein), percentage reduction calculations, horizontal bar charts, and radar charts. |
| **06** | **Exercise Equivalency** | Translates snack energy into approximate durations for **Walking** (3.7 kcal/min), **Jogging** (9.0 kcal/min), and **Cycling** (6.5 kcal/min), plus workout minutes spared. |
| **07** | **My Snack Swaps Dashboard** | Cumulative analytics: total swaps, kcal avoided, sugar avoided, sodium spared, daily progression charts, category breakdown donut, and full log history (`/my-swaps`). |
| **08** | **Barcode Scanner Module** | Interactive WebRTC camera scanner + manual EAN barcode input + 1-click test barcodes with live **Open Food Facts API** lookup and on-the-fly NutriLens grading. |
| **09** | **Hostel Snack Hacks** | Curated college student recipes (< ₹30, no-cook / kettle only, < 3 min preparation) including Spiced Makhana, Bhuna Chana & Gur, and Kettle Atta Veggie Bowl. |
| **10** | **Weekly Challenge & Gamification** | 7-day swap challenge missions, daily check-in buttons, streak counter, celebratory confetti, and 7 unlockable achievement badges. |

---

## 📊 The 40-Snack Dataset

NutriLens includes 40 scientifically verified Indian and global snacks across 8 major food categories:

### 🍟 20 Commonly Consumed / Craving Snacks
1. **Potato Chips** (Lay's Classic Salted) - Grade D (18 pts)
2. **Samosa** (Deep-Fried Potato & Peas) - Grade D (12 pts)
3. **Cola Soft Drink** (Carbonated Sugary Soda) - Grade E (14 pts)
4. **Cream Biscuits** (Sandwich Cookies) - Grade E (27 pts)
5. **Instant Noodles** (Flash-Fried Spicy Ramen) - Grade E (20 pts)
6. **Fried Namkeen** (Aloo Bhujia / Sev) - Grade E (20 pts)
7. **French Fries** (Deep-Fried Potato Batons) - Grade C (4 pts)
8. **Chocolate Bar** (Milk Chocolate) - Grade E (27 pts)
9. **Glazed Donut** (Deep-Fried Sweet Dough) - Grade D (17 pts)
10. **Candy / Chewy Drops** (Sugar Boiled Confectionery) - Grade D (15 pts)
11. **Energy Drink** (Caffeinated Sugary Beverage) - Grade E (14 pts)
12. **Packaged Fruit Cake** (Refined Loaf Cake) - Grade D (17 pts)
13. **Fried Bread Pakora** (Deep-Fried Besan Toast) - Grade D (11 pts)
14. **Salted Fried Peanuts** (High Sodium Deep-Fried) - Grade C (8 pts)
15. **Fast Food Pizza Slice** (Processed Cheese Crust) - Grade C (6 pts)
16. **Fast Food Burger** (Fried Veg Patty & Mayo) - Grade C (8 pts)
17. **Sweetened Flavored Yogurt** (High Sugar Fruit Curd) - Grade C (4 pts)
18. **Sugary Breakfast Cereal** (Frosted Corn Puffs) - Grade C (10 pts)
19. **Potato Masala Wafers** (Spiced Crisps) - Grade D (18 pts)
20. **Sugary Chocolate Milkshake** (Commercial Processed Shake) - Grade D (7 pts)

### 🥗 20 Nutrient-Dense Alternatives
21. **Roasted Makhana (Fox Nuts)** - Grade A (-10 pts)
22. **Baked Soya Crisps** - Grade A (-4 pts)
23. **Unsweetened Lemon Mint Water (Nimbu Pani)** - Grade C (3 pts)
24. **Plain Rolled Oats with Berries & Almonds** - Grade A (-4 pts)
25. **Vegetable Whole-Wheat Masala Noodles** - Grade A (-2 pts)
26. **Roasted Chana (Bengal Gram)** - Grade A (-10 pts)
27. **Baked Sweet Potato Wedges** - Grade A (-7 pts)
28. **Dark Chocolate Cocoa Bites (75%)** - Grade D (14 pts)
29. **Homemade Oat & Date Energy Bites** - Grade B (2 pts)
30. **Fresh Fruit Chaat Bowl** - Grade A (-5 pts)
31. **Spiced Masala Buttermilk (Chaas)** - Grade B (1 pt)
32. **Banana Oat Healthy Snack Muffin** - Grade B (1 pt)
33. **Baked Vegetable Paneer Cutlet** - Grade A (-5 pts)
34. **Dry Roasted Unsalted Peanuts** - Grade A (-2 pts)
35. **Whole-Wheat Vegetable Paneer Sandwich** - Grade A (-4 pts)
36. **Grilled Multigrain Paneer Wrap** - Grade A (-4 pts)
37. **Plain Curd / Greek Yogurt with Chia Seeds** - Grade A (-3 pts)
38. **Rolled Oats with Chia & Walnuts** - Grade A (-5 pts)
39. **Roasted Spiced Kala Chana** - Grade A (-10 pts)
40. **Banana Peanut Butter Milk Smoothie** - Grade B (0 pts)

*Data Sources: Indian Food Composition Tables (IFCT 2017), ICMR-NIN, and USDA FoodData Central.*

---

## 🚀 Quick Start Guide

### 1. Prerequisites
- **Node.js** (v20+ recommended, works on v26)
- **npm** (v10+)

### 2. Run the Full Stack Application
In the project root directory, run:

```bash
# 1. Start the full-stack server (REST API + SQLite + Frontend static bundle)
npm start
```
The application will launch immediately at:  
👉 **http://localhost:5000**

### 3. Development Mode (Optional)
To run frontend and backend with hot-reloading:

```bash
# In Terminal 1 (Backend API on port 5000):
npm run dev:backend

# In Terminal 2 (Vite Frontend on port 3000):
npm run dev:frontend
```
Open **http://localhost:3000** in your browser.

---

## 🎬 Recommended Hackathon Live Demo Walkthrough

Follow this 5-minute presentation script for maximum judge impact:

1. **The Hook (Home Page - `/`)**:
   - Introduce the platform: *"College students eat packaged food because it's cheap, fast, and accessible. But labels are confusing and generic advice tells them to stop eating altogether."*
   - Type **"Potato Chips"** into the hero search bar.

2. **The Nutritional Diagnosis (Details Page - `/snack/1`)**:
   - Show Potato Chips: **Grade D (18 pts)**.
   - Point to the **Nutri-Score Engine Breakdown**: +8 pts energy, +10 pts saturated fat, +6 pts sodium.
   - Show the **Exercise Equivalency**: eating a pack requires **70 minutes of walking** or **30 minutes of jogging**.

3. **Smart Taste-Matched Recommender (Recommendations - `/recommendations/1`)**:
   - Explain our innovation: *"We don't recommend a plain cucumber for someone craving potato chips. We match taste and texture!"*
   - Show **#1 Roasted Makhana (Fox Nuts)**: ₹25, crispy airy crunch, identical sensory profile, cuts 93% saturated fat!
   - Click **"Compare Side-by-Side"**.

4. **The Head-to-Head Showdown (Compare Page - `/compare/1/21`)**:
   - Highlight the **Instant Net Diff**: **-174 kcal**, **-10.8g saturated fat**, **-385mg sodium**, and **+3.2g protein**.
   - Show the interactive **Grouped Bar Chart** and **Macro Radar Chart**.
   - Show Exercise Equivalency: swapping to Makhana automatically **saves 38 minutes of walking**!
   - Click **"I Swapped This!"** → Celebrate the **Confetti explosion**!

5. **Closing the Loop (Dashboard - `/dashboard`)**:
   - Show real-time SQLite updates: Swaps Logged increases, cumulative kcal saved climbs over 1,000, sugar difference updates, and daily progression chart animates.
   - Show **7-Day Challenge Badges** unlocked.

---

## 🛡️ Hackathon Differentiators

| Feature | NutriLens Innovation |
|---|---|
| **Plain-Language Nutrition** | Converts raw milligram values into clear traffic lights, percentage reductions, and plain English explanations. |
| **Sensory Vector Matching** | Balances crispy/crunchy/savory textures so users stick to healthier swaps without feeling deprived. |
| **Indian Student Database** | Features samosas, makhana, roasted chana, masala chai alternatives, and chaas tailored to campus realities. |
| **Instant Nutritional Diff** | Shows the exact mathematical difference per 100g or per serving. |
| **Personal Swap Tracking** | Persistent local SQLite storage tracking total calories and sodium eliminated over time. |

---

## 📄 License
MIT License. Built for the NutriLens SnackSwap Showdown Hackathon.
